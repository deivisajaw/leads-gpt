import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Import HttpClient
import { ApiConfigService } from './api-config.service';
import { Observable } from 'rxjs'; // Import Observable

export interface Agent {
  id: number
  name: string
  agentType: "voice" | "text"
  agentDirection?: "INBOUND" | "OUTBOUND";
  language: string
  agentSystemName: string
  purpose: string
  description?: string
  instructions?: string
  prompt: string
  voice: string
  openingLine: string
  createDate: string
  updateDate?: string
  processed?: boolean; 

  elevenLabsVoiceId?: string;
  voiceName?: string;
  voiceGender?: string;
  voiceAccent?: string;

  whatsappNumber?: string;
  calToken?: string;       // kept for backward compat - no longer populated from backend
  calEventType?: string;   // kept for backward compat - no longer populated from backend
  companyPhoneNumberId?: number;
  hasCalendarIntegration?: boolean;
  companyPhoneNumberNumber?: string;
  voicemailMessage?: string;
}

export interface Voice {
  id: number;
  name: string;
  elevenLabsVoiceId: string;
  previewUrl: string;
  gender: string;
  accent: string;
}

export interface PhoneNumber {
  id: number;
  companyData: number;
  twilioPhone: string;
  agent?: number;
}

@Injectable({
  providedIn: 'root'
})
export class AgentService {

  constructor(private apiConfig: ApiConfigService, private http: HttpClient) {} // Inject HttpClient

  triggerTestCallWebhook(payload: { agentId: number; contactPhone: string; contactName: string; contactEmail?: string }): Observable<any> {
    const url = this.apiConfig.aiTestCallmeWebhookUrl;
    return this.http.post(url, payload);
  }

  async getAgents(): Promise<Agent[]> {
    const response = await this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:getAgents', {});
    return response.agents || [];
  }

  async getAgentById(id: number): Promise<{ agent: Agent; error: boolean; }> {
    return this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:getAgentDetails', { _id: id });
  }

  async createAgent(agentData: any): Promise<any> {
    return this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:saveAgent', agentData);
  }

  async deleteAgent(agentId: number): Promise<any> {
    return this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:deleteAgent', { _id: agentId });
  }

  async getVoices(): Promise<Voice[]> {
    const response = await this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:getVoices', {});
    return response.voices || []; 
  }

  async getPhoneNumbers(): Promise<PhoneNumber[]> {
    const response = await this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:getPhoneNumbers', {});
    return response.phones || []; 
  }

  async getCalendarIntegrationStatus(agentId: number): Promise<boolean> {
    const response = await this.fetchData('com.ajawmrp3.apps.prospectingai.web.AgentController:getAgentDetails', { _id: agentId });
    return response?.agent?.hasCalendarIntegration ?? false;
  }

  private async fetchData(action: string, data: any): Promise<any> {
    const token = localStorage.getItem('csrfToken');
    if (!token) {
      throw new Error('No authentication token found');
    }

    const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': token
      },
      body: JSON.stringify({ action, data })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
    }

    const result = await response.json();

    if (result.error) {
      throw new Error(result.error.message || 'Unknown error');
    }
    return result.data;
  }
}