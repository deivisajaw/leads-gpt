import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Answer {
  answerText: string | null;
  selectedOption: number | null;
  selectedOptions: number[];
}

@Component({
  selector: 'app-onboarding-wizard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './onboarding-wizard.component.html',
  styleUrls: ['./onboarding-wizard.component.css']
})
export class OnboardingWizardComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {

  @Input() questions: any[] = [];
  @Output() completed = new EventEmitter<any[]>();

  currentStep = 0;
  answers: { [questionId: number]: Answer } = {};

  private canvasAnimationId: number | null = null;

  constructor() { }

  ngOnInit(): void {
    this.initializeAnswers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['questions'] && changes['questions'].currentValue) {
      this.initializeAnswers();
    }
  }

  ngAfterViewInit(): void {
    this.initParticlesNetwork();
  }

  ngOnDestroy(): void {
    if (this.canvasAnimationId) {
      cancelAnimationFrame(this.canvasAnimationId);
    }
  }

  initParticlesNetwork(): void {
    const canvas = document.getElementById('particles-canvas') as HTMLCanvasElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Ajustar tamaño del lienzo al viewport
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Paleta de colores exacta de la imagen (Gris, Azul/Morado, Rosa)
    const colors = [
      'rgba(148, 163, 184, 0.4)', // Gris sutil
      'rgba(99, 102, 241, 0.5)',  // Azul/Morado
      'rgba(244, 63, 94, 0.4)'    // Rosa/Magenta
    ];

    // Configuración de los puntos
    const particleCount = 45; // Cantidad para cubrir bien el fondo sin saturar
    const particles: any[] = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 2.5 + 1.5, // Puntos pequeños y finos
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: (Math.random() - 0.5) * 0.3, // Movimiento sumamente lento y elegante
        vy: (Math.random() - 0.5) * 0.3,
        hasGlow: Math.random() > 0.75 // Solo algunos nodos tienen el resplandor difuminado de fondo
      });
    }

    // Bucle de animación
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Dibujar las líneas de conexión primero (quedan detrás de los nodos)
      for (let i = 0; i < particleCount; i++) {
        for (let j = i + 1; j < particleCount; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          // Si están a menos de X distancia, trazamos la línea interconectada
          if (distance < 180) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            // Opacidad proporcional a la cercanía
            ctx.strokeStyle = `rgba(226, 232, 240, ${0.18 * (1 - distance / 180)})`;
            ctx.lineWidth = 0.75;
            ctx.stroke();
          }
        }
      }

      // 2. Dibujar y actualizar los nodos
      particles.forEach(p => {
        // Si el nodo tiene glow, le aplicamos sombra difuminada nativa de Canvas
        if (p.hasGlow) {
          ctx.save();
          ctx.shadowBlur = 20;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius + 1, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.fill();
          ctx.restore();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.fill();
        }

        // Mover partículas
        p.x += p.vx;
        p.y += p.vy;

        // Rebotar sutilmente en los bordes de la pantalla
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      });

      this.canvasAnimationId = requestAnimationFrame(animate);
    };

    animate();
  }

  initializeAnswers(): void {
    this.answers = {};
    this.questions.forEach(q => {
      this.ensureAnswerObject(q.id);
    });
    console.log(this.questions)
  }

  ensureAnswerObject(questionId: number): void {
    if (!this.answers[questionId]) {
      this.answers[questionId] = {
        answerText: null,
        selectedOption: null,
        selectedOptions: []
      };
    }
  }

  selectOption(questionId: number, optionId: number): void {
    this.ensureAnswerObject(questionId);
    const questionType = this.questions.find(q => q.id === questionId)?.questionType;

    if (questionType === 'SINGLE_SELECT') {
      this.answers[questionId].selectedOption = optionId;
      setTimeout(() => {
        this.nextStep();
      }, 250);
    } else if (questionType === 'MULTI_SELECT') {
      const selectedOptions = this.answers[questionId].selectedOptions;
      const index = selectedOptions.indexOf(optionId);
      if (index > -1) {
        selectedOptions.splice(index, 1);
      } else {
        selectedOptions.push(optionId);
      }
    }
  }

  selectBooleanOption(questionId: number, value: 'true' | 'false'): void {
    this.ensureAnswerObject(questionId);
    this.answers[questionId].answerText = value;
    setTimeout(() => {
      this.nextStep();
    }, 250);
  }

  isOptionSelected(questionId: number, optionId: number): boolean {
    return this.answers[questionId]?.selectedOptions.includes(optionId) || false;
  }

  isCurrentStepValid(): boolean {
    if (!this.questions || this.questions.length === 0) return false;
    const currentQuestion = this.questions[this.currentStep];
    const currentAnswer = this.answers[currentQuestion.id];
    if (!currentAnswer) return false;

    if (currentQuestion.required === false) return true;

    switch (currentQuestion.questionType) {
      case 'TEXT':
      case 'DATE':
      case 'NUMBER_INTEGER':
      case 'NUMBER_DECIMAL':
        return currentAnswer.answerText !== null && currentAnswer.answerText.trim() !== '';
      case 'BOOLEAN':
        return currentAnswer.answerText !== null;
      case 'SINGLE_SELECT':
        return currentAnswer.selectedOption !== null;
      case 'MULTI_SELECT':
        return currentAnswer.selectedOptions.length > 0;
      default:
        return false;
    }
  }

  nextStep(): void {
    if (this.currentStep < this.questions.length - 1) {
      this.currentStep++;
    } else {
      this.finish();
    }
  }

  skipStep(): void {
    // PUNTO 5: Acción operativa de Saltar independiente del estado de requerimiento
    if (this.currentStep < this.questions.length - 1) {
      this.currentStep++;
    } else {
      this.finish();
    }
  }

  previousStep(): void {
    if (this.currentStep > 0) {
      this.currentStep--;
    }
  }

  finish(): void {
    const formattedAnswers = Object.keys(this.answers).map(questionIdStr => {
      const questionId = parseInt(questionIdStr, 10);
      const answer = this.answers[questionId];
      return {
        id: questionId,
        selectedOption: answer.selectedOption,
        answerText: answer.answerText,
        selectedOptions: answer.selectedOptions
      };
    });
    
    this.completed.emit(formattedAnswers);
  }
}