import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { MyListCompanyService, SavedCompany, TagCount } from '../../services/my-list-company.service';
import { ExportService } from '../../services/export.service';

type SavedCompanyRow = SavedCompany & { tagsList: string[] };

@Component({
  selector: 'app-my-list-company',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, TranslateModule],
  templateUrl: './my-list-company.component.html',
  styleUrl: './my-list-company.component.css'
})
export class MyListCompanyComponent implements OnInit {

  companies: SavedCompanyRow[] = [];
  searchQuery = '';
  isLoading = false;
  currentView: 'grid' | 'card' = 'grid';
  currentViewText = 'Grid view';
  currentPage = 1;
  itemsPerPage = 25;
  totalResultsInServer = 0;

  showViewDropdown = false;
  showExportDropdown = false;

  public allTags: TagCount[] = [];
  public selectedTags = new Set<string>();
  public rowsRevealed = false;

  private searchDebounce: any = null;

  constructor(
    private myListCompanyService: MyListCompanyService,
    private router: Router,
    private exportService: ExportService 
  ) {
    document.addEventListener('click', (event) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.dropdown-wrapper')) {
        this.closeAllDropdowns();
      }
    });
  }

  ngOnInit() {
    this.loadTags();
    this.loadCompanies();
  }

  private async loadTags(): Promise<void> {
    const res = await this.myListCompanyService.getMyCompanyTags();
    this.allTags = res.error ? [] : res.tags;
  }

  async loadCompanies(page: number = this.currentPage) {
    this.isLoading = true;
    this.currentPage = page;
    const offset = (this.currentPage - 1) * this.itemsPerPage;

    try {
      const result = await this.myListCompanyService.getMyCompanies(
        offset,
        this.itemsPerPage,
        Array.from(this.selectedTags),
        this.searchQuery.trim()
      );
      if (result.error) {
        console.error('Error loading companies:', result.message);
        this.companies = [];
        this.totalResultsInServer = 0;
      } else {
        
        this.companies = result.companies.map(c => ({
          ...c,
          tagsList: this.splitTags(c.tags),
        }));
        this.totalResultsInServer = result.total ?? result.companies.length;
      }
    } catch (error) {
      console.error('Error loading companies:', error);
      this.companies = [];
      this.totalResultsInServer = 0;
    } finally {
      this.isLoading = false;
      this.rowsRevealed = false;
      setTimeout(() => { this.rowsRevealed = true; }, 0);
    }
  }

  public toggleTagFilter(tag: string): void {
    if (this.selectedTags.has(tag)) this.selectedTags.delete(tag);
    else this.selectedTags.add(tag);
    this.loadCompanies(1);
  }

  public clearTagFilter(): void {
    this.selectedTags.clear();
    this.loadCompanies(1);
  }

  onSearch() {
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => {
      this.loadCompanies(1);
    }, 350);
  }

  changeView(view: 'grid' | 'card') {
    this.currentView = view;
    this.currentViewText = view === 'grid' ? 'Grid view' : 'Card view';
  }

  viewCompanyDetails(companyId: number) {
    this.router.navigate(['/company-details', companyId]);
  }

  refreshList() {
    this.loadTags();
    this.loadCompanies();
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.loadCompanies(page);
    }
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  }

  splitTags(tags?: string): string[] {
    if (!tags) return [];
    return tags.split(',').map(t => t.trim()).filter(Boolean);
  }

  toggleDropdown(dropdownName: string) {
    this.showViewDropdown = false;
    this.showExportDropdown = false;

    switch (dropdownName) {
      case 'view':
        this.showViewDropdown = true;
        break;
      case 'export':
        this.showExportDropdown = true;
        break;
    }
  }

  closeAllDropdowns() {
    this.showViewDropdown = false;
    this.showExportDropdown = false;
  }

  get totalPages(): number {
    return Math.ceil(this.totalResultsInServer / this.itemsPerPage);
  }

  getStartIndex(): number {
    return this.companies.length > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.totalResultsInServer);
  }

  exportToCSV(): void {
    const dataToExport = this.companies.map(({ additionalInfo, address, categoryName, city, countryCode, description, descriptionMd, error, errorDescription, id, neighborhood, openingHours, permanentlyClosed, phoneUnformatted, postalCode, savedOn, state, street, title, website, tags }
      ) => ({
          id,
          title,
          categoryName,
          countryCode,
          city,
          state,
          street,
          address,
          postalCode,
          phoneUnformatted,
          openingHours,
          permanentlyClosed,
          website,
          description,
          descriptionMd,
          error,
          errorDescription,
          neighborhood,
          additionalInfo,
          tags,
          savedOn: this.formatDate(savedOn)
    }));
    this.exportService.exportToCsv(dataToExport, 'my-company-list');
  }
  
  exportToExcel(): void {
    const dataToExport = this.companies.map(({ additionalInfo, address, categoryName, city, countryCode, description, descriptionMd, error, errorDescription, id, neighborhood, openingHours, permanentlyClosed, phoneUnformatted, postalCode, savedOn, state, street, title, website, tags }
      ) => ({
          id,
          title,
          categoryName,
          countryCode,
          city,
          state,
          street,
          address,
          postalCode,
          phoneUnformatted,
          openingHours,
          permanentlyClosed,
          website,
          description,
          descriptionMd,
          error,
          errorDescription,
          neighborhood,
          additionalInfo,
          tags,
          savedOn: this.formatDate(savedOn) 
    }));
    this.exportService.exportToExcel(dataToExport, 'my-company-list');
  }
}