import { Injectable } from '@angular/core';
import { ApiConfigService } from './api-config.service';

export interface SavedPeople {
  id: number
  name: string
  title: string
  link: string
  snippet: string
  image: string
  description: string
  searchResultStatusSelect: number
  fullName: string
  email: string
  phone: string
  education: string
  experiencies: string
  countryCode: string
  location: string
  about: string
  itemSelected: boolean
  // Campos adicionales para la vista
  avatar: string
  verified: boolean
  savedOn: string
  // Tags separados por coma que el usuario asignó al guardar
  tags?: string
}

export interface SavePeopleResponse {
  error: boolean;
  message: string;
  saved?: number;
  creditsRemaining?: number;
}

export interface MyPeopleResponse {
  error: boolean;
  message?: string;
  peoples: SavedPeople[];
  total?: number;
  offset?: number;
  limit?: number;
  fetched?: number;
}

export interface TagCount {
  tag: string;
  count: number;
}

export interface MyPeopleTagsResponse {
  error: boolean;
  message?: string;
  tags: TagCount[];
}

@Injectable({
  providedIn: 'root'
})
export class MyListPeopleService {

  constructor(private apiConfig: ApiConfigService) {}

  async savePeopleResults(ids: number[], tags?: string): Promise<SavePeopleResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:savePeopleResults',
          data: { _ids: ids, tags: tags || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SavePeopleResponse;
    } catch (error) {
      console.error('Error saving people:', error);
      return { error: true, message: 'Error saving people' };
    }
  }

  async getMyPeople(offset = 0, limit = 25, tags: string[] = [], query = ''): Promise<MyPeopleResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMyPeoples',
          data: { offset, limit, tags, query: query || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as MyPeopleResponse;
    } catch (error) {
      console.error('Error loading people:', error);
      return { error: true, message: 'Error loading people', peoples: [] };
    }
  }

  // Tags únicos (con conteo) de TODO lo que el usuario tiene guardado — alimenta la barra
  // de chips filtrables, independiente de la página/paginación actual.
  async getMyPeopleTags(): Promise<MyPeopleTagsResponse> {
    try {
      const token = localStorage.getItem('csrfToken');

      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMyPeopleTags',
          data: {}
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as MyPeopleTagsResponse;
    } catch (error) {
      console.error('Error loading people tags:', error);
      return { error: true, message: 'Error loading people tags', tags: [] };
    }
  }

  async getPeopleDetails(id: number): Promise<any> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getPeopleDetails',
          data: { _id : id }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data;
    } catch (error) {
      console.error('Error loading people details:', error);
      return { error: true, message: 'Error loading people details' };
    }
  }

  async saveAllPeopleResults(searchId: number, tags?: string): Promise<SavePeopleResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:saveAllPeopleResults',
          data: { _searchId: searchId, tags: tags || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SavePeopleResponse;
    } catch (error) {
      console.error('Error saving all people:', error);
      return { error: true, message: 'An error occurred while trying to save all people.' };
    }
  }
}