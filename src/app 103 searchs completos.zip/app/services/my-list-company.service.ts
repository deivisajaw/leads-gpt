import { Injectable } from '@angular/core';
import { ApiConfigService } from './api-config.service';

export interface SavedCompany {
  id: number;
  title: string;
  categoryName: string;
  city: string;
  state: string;
  countryCode: string;
  website?: string;
  openingHours?: string;
  phoneUnformatted?: string;
  savedOn: string;
  additionalInfo?: string;
  address?: string;
  description?: string;
  descriptionMd?: string;
  error?: string;
  errorDescription?: string;
  neighborhood?: string;
  permanentlyClosed?: string;
  postalCode?: string;
  street?: string;
  // Tags separados por coma que el usuario asignó al guardar, ej: "mis arquitectos,prospectos"
  tags?: string;
}

export interface SaveCompanyResponse {
  error: boolean;
  message: string;
  saved?: number;
  creditsRemaining?: number;
}

export interface MyCompaniesResponse {
  error: boolean;
  message?: string;
  companies: SavedCompany[];
  total?: number;
  offset?: number;
  limit?: number;
  fetched?: number;
}

export interface TagCount {
  tag: string;
  count: number;
}

export interface MyCompanyTagsResponse {
  error: boolean;
  message?: string;
  tags: TagCount[];
}

@Injectable({
  providedIn: 'root'
})
export class MyListCompanyService {

  constructor(private apiConfig: ApiConfigService) {}

  async saveCompanyResults(ids: number[], tags?: string): Promise<SaveCompanyResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:saveCompanyResults',
          data: { _ids: ids, tags: tags || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SaveCompanyResponse;
    } catch (error) {
      console.error('Error saving companies:', error);
      return { error: true, message: 'Error saving companies' };
    }
  }

  async getMyCompanies(offset = 0, limit = 25, tags: string[] = [], query = ''): Promise<MyCompaniesResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMyCompanies',
          data: { offset, limit, tags, query: query || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as MyCompaniesResponse;
    } catch (error) {
      console.error('Error loading companies:', error);
      return { error: true, message: 'Error loading companies', companies: [] };
    }
  }

  // Tags únicos (con conteo) de TODO lo que el usuario tiene guardado — alimenta la barra
  // de chips filtrables, independiente de la página/paginación actual.
  async getMyCompanyTags(): Promise<MyCompanyTagsResponse> {
    try {
      const token = localStorage.getItem('csrfToken');

      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMyCompanyTags',
          data: {}
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as MyCompanyTagsResponse;
    } catch (error) {
      console.error('Error loading company tags:', error);
      return { error: true, message: 'Error loading company tags', tags: [] };
    }
  }

  async getCompanyDetails(id: number): Promise<any> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getCompanyDetails',
          data: { _id : id }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log(result.data)
      return result.data;
    } catch (error) {
      console.error('Error loading company details:', error);
      return { error: true, message: 'Error loading company details' };
    }
  }

  async saveAllCompanyResults(searchId: number, tags?: string): Promise<SaveCompanyResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:saveAllCompanyResults',
          data: { _searchId: searchId, tags: tags || undefined }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SaveCompanyResponse;
    } catch (error) {
      console.error('Error saving all companies:', error);
      return { error: true, message: 'An error occurred while trying to save all companies.' };
    }
  }
}