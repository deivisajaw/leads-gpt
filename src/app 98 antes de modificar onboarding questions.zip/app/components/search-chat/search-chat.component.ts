import {
  Component, Input, Output, EventEmitter,
  OnInit, ViewChild, ElementRef, AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiConfigService } from '../../services/api-config.service';
import { AuthService } from '../../services/auth.service';

export interface ChatMessage {
  role: 'assistant' | 'user';
  text: string;
}

export type SearchChatMode = 'people' | 'companies';

@Component({
  selector: 'app-search-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-chat.component.html',
  styleUrl: './search-chat.component.css',
})
export class SearchChatComponent implements OnInit, AfterViewChecked {
  @Input() mode: SearchChatMode = 'people';
  @Output() searchReady = new EventEmitter<string>();

  @ViewChild('messagesEnd') messagesEnd!: ElementRef;

  messages: ChatMessage[] = [];
  userInput = '';
  isLoading = false;
  isIntroLoading = false;
  hasStarted = false;

  private shouldScroll = false;
  private history: { role: 'user' | 'assistant'; content: string }[] = [];

  username: string = '';

  constructor(
    private apiConfig: ApiConfigService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.authService.userProfile$.subscribe(profile => {
      this.username = profile?.username || '';
    });

    this.startConversation();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll) {
      this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
      this.shouldScroll = false;
    }
  }

  get title(): string {
    return `Hola, ${this.username || ''} Listo para encontrar mas clientes?`;
  }

  get subtitle(): string {
    return this.mode === 'people'
      ? 'Describe el perfil ideal con cargo, industria, seniority, ubicación o experiencia clave. Yo te ayudaré a convertirlo en una búsqueda más precisa.'
      : 'Describe la empresa ideal por industria, tamaño, ubicación, etapa o enfoque. Yo te ayudaré a transformar tu idea en una búsqueda clara.';
  }

  get inputPlaceholder(): string {
    return this.mode === 'people'
      ? 'Ej: Busco CTOs en fintech en México con experiencia escalando equipos...'
      : 'Ej: Busco startups SaaS B2B en Colombia con más de 50 empleados...';
  }

  get quickPrompts(): string[] {
    return this.mode === 'people'
      ? [
        'Head of Sales en SaaS B2B en LATAM',
        'CTOs con experiencia en fintech',
        'Recruiters senior con foco en tech'
      ]
      : [
        'Startups fintech en México',
        'Empresas SaaS B2B en Colombia',
        'Compañías logísticas en crecimiento'
      ];
  }

  private async startConversation(): Promise<void> {
    this.isIntroLoading = true;
    const greeting = await this.callAgent([]);
    this.isIntroLoading = false;

    this.messages = [{ role: 'assistant', text: greeting }];
    this.history = [{ role: 'assistant', content: greeting }];
  }

  async send(prefill?: string): Promise<void> {
    const text = (prefill ?? this.userInput).trim();
    if (!text || this.isLoading || this.isIntroLoading) return;

    this.hasStarted = true;
    this.userInput = '';

    this.pushMsg('user', text);
    this.history.push({ role: 'user', content: text });

    this.isLoading = true;
    const reply = await this.callAgent(this.history);
    this.isLoading = false;

    const match = reply.match(/SEARCH_READY::(.+)/);

    if (match) {
      const query = match[1].trim();
      const cleanReply =
        reply.replace(/SEARCH_READY::.+/, '').trim() ||
        'Perfecto. Estoy preparando la búsqueda con los criterios que definimos.';

      this.pushMsg('assistant', cleanReply);
      this.history.push({ role: 'assistant', content: cleanReply });

      setTimeout(() => this.searchReady.emit(query), 900);
    } else {
      this.pushMsg('assistant', reply);
      this.history.push({ role: 'assistant', content: reply });
    }
  }

  usePrompt(prompt: string): void {
    this.send(prompt);
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.send();
    }
  }

  trackByIndex(index: number): number {
    return index;
  }

  private pushMsg(role: 'assistant' | 'user', text: string): void {
    this.messages.push({ role, text });
    this.shouldScroll = true;
  }

  private async callAgent(
    history: { role: 'user' | 'assistant'; content: string }[]
  ): Promise<string> {
    try {
      const response = await fetch(this.apiConfig.chatAgentUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history, mode: this.mode }),
      });

      if (!response.ok) {
        return 'Lo siento, hubo un problema de conexión. Por favor intenta de nuevo.';
      }

      const data = await response.json();
      return data.reply ?? 'No pude procesar tu mensaje.';
    } catch (err) {
      console.error('Chat agent error:', err);
      return 'Error de red. Por favor intenta de nuevo.';
    }
  }
}