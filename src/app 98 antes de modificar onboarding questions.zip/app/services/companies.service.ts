import { Injectable } from "@angular/core"
import { ApiConfigService } from "./api-config.service"

export interface Company {
  id: number
  title: string
  categoryName: string
  address: string
  neighborhood: string
  street: string
  city: string
  postalCode: string
  state: string
  countryCode: string
  phoneUnformatted: string
  permanentlyClosed: boolean
  openingHours: string
  website: string
  additionalInfo: string
  error: string
  errorDescription: string
  description: string
  descriptionMd: string
}

export interface CompanySearchResult {
  notFound: boolean
  searchString: string
  results: Company[]
  searchId?: number
  statusSelect?: number
  resultsNumber?: number
  offset: number
  limit: number
  fetched: number
  sortBy?: string
  message?: string
  error?: boolean,
  creditsRemaining?: number
}

export interface CompanySearchHistoryItem {
  id: number;
  searchString: string;
  statusSelect?: number;
  resultsNumber?: number;
  createdOn: string;
}

export interface CompanySearchHistoryResponse {
  error: boolean;
  message?: string;
  history: CompanySearchHistoryItem[];
  total: number;
  offset: number;
  limit: number;
  fetched: number;
  sortBy?: string;
}

export interface CompanySearchResponse {
  status: 'SEARCH_NOT_FOUND' | 'SEARCH_IN_PROGRESS' | 'SUCCESS' | 'INSUFFICIENT_CREDITS' | 'UNAUTHORIZED' | 'INVALID_INPUT' | 'ERROR';
  message?: string;
  data?: CompanySearchResult;
}

@Injectable({
  providedIn: "root",
})
export class CompaniesService {

  constructor(private apiConfig: ApiConfigService) { }

  async runSearchCompanies(query: string, offset = 0, limit = 25, sortBy = 'title_asc'): Promise<CompanySearchResponse> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:runSearchCompanies",
          data: {
            query: query,
            offset: offset,
            limit: limit,
            sortBy: sortBy,
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json();
      console.log(result)
      // Correctly return the nested data object which matches the CompanySearchResponse interface
      return result.data as CompanySearchResponse;

    } catch (error) {
      console.error("Error in runSearchCompanies:", error)
      return {
        status: 'ERROR',
        message: "Error calling API",
      } as CompanySearchResponse;
    }
  }

  async triggerExternalSearch(query: string): Promise<{ status: number; message: string }> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const userId = localStorage.getItem("userId")

      if (!userId) {
        throw new Error("No userId found")
      }

      console.log("Triggering external search for companies:", query)

      const url = new URL(this.apiConfig.searchCompanyUrl);
      url.searchParams.append("sessionId", userId);
      url.searchParams.append("action", "sendMessage");
      url.searchParams.append("chatInput", query);

      const response = await fetch(url.toString(), {
        method: "GET",
        credentials: "omit",
        headers: {
          "AjawCompanyLeads": "oci=4^Br463sStYm"
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log("Webhook Response:", result);

      if (result?.status === 0 && result?.data?.[0]?.message === "in process") {
        return { status: 0, message: "in process" };
      }

      return {
        status: result.status || -1,
        message: result?.data?.[0]?.message || "Unexpected response"
      };
    } catch (error) {
      console.error("Error triggering webhook search:", error);
      return {
        status: -1,
        message: "Error triggering external search"
      };
    }
  }

  async getSearchStatus(searchId: number): Promise<{ status: string; progress?: number }> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getSearchStatus",
          data: {
            searchId: searchId,
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()

      return {
        status: result.data?.status || "unknown",
        progress: result.data?.progress || 0,
      }
    } catch (error) {
      console.error("Error getting search status:", error)
      return {
        status: "error",
        progress: 0,
      }
    }
  }

  async getMySearchHistoryCompanies(offset = 0, limit = 25, sortBy = 'createdOn_desc'): Promise<CompanySearchHistoryResponse> {
      try {
          const token = localStorage.getItem("csrfToken");
          if (!token) {
              throw new Error("No authentication token found");
          }
  
          const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
              method: "POST",
              credentials: "include",
              headers: {
                  "Content-Type": "application/json",
                  "X-CSRF-Token": token,
              },
              body: JSON.stringify({
                  action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMySearchHistoryCompanies",
                  data: {
                      offset: offset,
                      limit: limit,
                      sortBy: sortBy,
                  },
              }),
          });
  
          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          }
  
          const result = await response.json();
          return result.data as CompanySearchHistoryResponse;
      } catch (error) {
          console.error("Error in getMySearchHistoryCompanies:", error);
          return {
              error: true,
              message: "Error calling API",
              history: [],
              total: 0,
              offset: offset,
              limit: limit,
              fetched: 0,
              sortBy: sortBy,
          } as CompanySearchHistoryResponse;
      }
  }

  async getMySearchHistoryCompanyDetails(searchId: number, offset = 0, limit = 25, sortBy = 'title_asc'): Promise<CompanySearchResult> {
    try {
      const token = localStorage.getItem("csrfToken");
      if (!token) {
        throw new Error("No authentication token found");
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMySearchHistoryCompanyDetails",
          data: {
            searchId: searchId,
            offset: offset,
            limit: limit,
            sortBy: sortBy,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as CompanySearchResult;
    } catch (error) {
      console.error("Error in getMySearchHistoryCompanyDetails:", error);
      return {
        error: true,
        message: "Error calling API",
        notFound: true,
        searchString: "",
        results: [],
        offset: offset,
        limit: limit,
        fetched: 0,
        sortBy: sortBy,
      } as CompanySearchResult;
    }
  }

}