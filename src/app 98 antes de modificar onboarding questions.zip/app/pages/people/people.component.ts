import { Component, OnInit, OnDestroy } from "@angular/core"
import { CommonModule } from "@angular/common"
import { FormsModule } from "@angular/forms"
import { TranslateModule } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { PeopleService, People, PeopleSearchResult, PeopleSearchResponse } from "../../services/people.service"
import { MyListPeopleService } from "../../services/my-list-people.service"
import { ApiConfigService } from "../../services/api-config.service";
import { Subscription } from "rxjs";
import { AuthService } from "../../services/auth.service";
import { NotificationService } from "../../services/notification.service";
import { OnboardingService } from "../../services/onboarding.service";
import { PlansComponent } from "../plans/plans.component";
import { SearchChatComponent } from "../../components/search-chat/search-chat.component";

@Component({
  selector: "app-people",
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule, PlansComponent, SearchChatComponent],
  templateUrl: "./people.component.html",
  styleUrl: "./people.component.css",
})
export class PeopleComponent implements OnInit, OnDestroy {
  searchQuery = ""
  currentQuery = ""
  isLoading = false;
  isAiSearching = false;
  currentView: "grid" | "card" | "default" = "grid"
  currentViewText = "Grid view"
  filteredResults: People[] = []
  currentPage = 1
  itemsPerPage = 25
  selectedPeople: number[] = []
  selectAllChecked = false
  totalResults = 0
  currentSearchId: number | null = null

  totalResultsInServer = 0;
  searchStatus = "";
  searchStatusSelect: number | null = null;
  currentOffset = 0;

  showViewDropdown = false
  showImportDropdown = false
  showWorkflowDropdown = false
  showSortDropdown = false

  public showFilters = false;
  public localFilters = {
    name: '',
    jobTitle: '',
    company: '',
    location: ''
  };
  public displayResults: People[] = [];
  public currentSortOrder: string = 'name_asc';
  private pollingInterval: any;
  private pollTimeout: any;
  public isPolling: boolean = false;
  public creditsRemaining: number = 0;
  private userProfileSubscription!: Subscription;

  public searchError: string | null = null;
  public showPlans: boolean = false;
  public isSaving: boolean = false;
  public isSavingAll: boolean = false;

  constructor(
    private peopleService: PeopleService,
    private myListPeopleService: MyListPeopleService,
    private router: Router,
    private apiConfig: ApiConfigService,
    private authService: AuthService,
    private notificationService: NotificationService,
    private onboardingService: OnboardingService
  ) {
    document.addEventListener("click", (event) => {
      const target = event.target as HTMLElement
      if (!target.closest(".dropdown-wrapper")) {
        this.closeAllDropdowns()
      }
    })
  }

  ngOnInit(): void {
    this.userProfileSubscription = this.authService.userProfile$.subscribe(profile => {
      if (profile && profile.companyProfile) {
        this.creditsRemaining = profile.companyProfile.creditsAllocated ?? 0;
      }
    });
  }

  ngOnDestroy(): void {
    this.stopPolling();
    if (this.userProfileSubscription) {
      this.userProfileSubscription.unsubscribe();
    }
  }

  // ─── Llamado por el chat cuando el agente tiene el query listo ───
  onSearchReady(query: string): void {
    this.searchQuery = query;
    this.onSearch();
  }

  async onSearch() {
    if (!this.searchQuery.trim()) {
      this.resetSearchState();
      return;
    }

    this.stopPolling();
    this.searchError = null;
    this.showPlans = false;
    this.filteredResults = [];
    this.displayResults = [];
    this.currentPage = 1;
    this.currentOffset = 0;
    this.selectedPeople = [];
    this.selectAllChecked = false;
    this.isAiSearching = false;

    this.isLoading = true;
    this.currentQuery = this.searchQuery;

    try {
      const response = await this.peopleService.runSearchPeople(
        this.currentQuery, 0, this.itemsPerPage, this.currentSortOrder
      );
      this.processApiResponse(response);
    } catch (error) {
      console.error("Search error:", error);
      this.searchError = "Ocurrio un error inesperado al buscar.";
      this.isLoading = false;
    }
  }

  private processApiResponse(response: PeopleSearchResponse) {
    this.isLoading = false;
    this.searchError = null;
    this.showPlans = false;

    switch (response.status) {
      case 'SEARCH_NOT_FOUND':
        this.isAiSearching = true;
        this.triggerExternalSearch();
        break;

      case 'SEARCH_IN_PROGRESS':
        this.isAiSearching = false;
        this.updateStateFromData(response.data);
        if (!this.isPolling) {
          this.startPolling();
        }
        break;

      case 'SUCCESS':
        this.isAiSearching = false;
        this.stopPolling();
        this.updateStateFromData(response.data);
        this.onboardingService.completeOnboardingStepByKey('FIND_LEADS');
        break;

      case 'INSUFFICIENT_CREDITS':
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = response.message || "No tienes creditos suficientes.";
        this.showPlans = true;
        break;

      case 'UNAUTHORIZED':
      case 'INVALID_INPUT':
      case 'ERROR':
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = response.message || "Ocurrio un error.";
        break;

      default:
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = "Respuesta desconocida del servidor.";
        break;
    }
  }

  private async triggerExternalSearch() {
    if (this.creditsRemaining < 2) {
      this.searchError = "No tienes creditos suficientes (minimo 2) para una nueva busqueda.";
      this.showPlans = true;
      this.isAiSearching = false;
      return;
    }

    try {
      const externalResult = await this.peopleService.triggerExternalSearch(this.currentQuery);
      if (externalResult.status === 0) {
        this.startPolling();
        this.onboardingService.completeOnboardingStepByKey('FIND_LEADS');
      } else {
        this.searchError = "Error al iniciar la busqueda externa.";
        this.isAiSearching = false;
      }
    } catch (error) {
      this.searchError = "Error de red al iniciar la busqueda externa.";
      this.isAiSearching = false;
    }
  }

  private updateStateFromData(data: PeopleSearchResult | undefined) {
    if (!data) return;

    const safeResults = Array.isArray(data.results) ? data.results : [];
    this.filteredResults = safeResults.map(people => {
      const mainParts = people.title.split(' | ');
      const nameAndTitleParts = mainParts[0].split(' - ');
      const jobTitle = nameAndTitleParts.length > 1 ? nameAndTitleParts.slice(1).join(' - ').trim() : 'N/A';
      const company = mainParts[1] ? mainParts[1].trim() : 'N/A';

      return {
        ...people,
        jobTitle: jobTitle,
        company: company,
        avatar: people.image || `https://ui-avatars.com/api/?name=${encodeURIComponent(people.name)}&background=5b4fe5&color=fff&size=40`,
        verified: !!people.email
      };
    });

    this.totalResultsInServer = data.resultsNumber || 0;
    this.currentSearchId = data.searchId || null;
    this.searchStatusSelect = data.statusSelect || null;
    this.currentOffset = data.offset;
    this.currentSortOrder = data.sortBy || 'name_asc';
    this.searchStatus = this.getStatusText();

    if (data.creditsRemaining !== undefined) {
      this.authService.updateCurrentUserCredits(data.creditsRemaining);
    }

    this.applyLocalFilters();
  }

  private startPolling() {
    if (this.isPolling) return;

    this.isPolling = true;

    this.pollTimeout = setTimeout(() => {
      if (this.isPolling) {
        this.stopPolling();
        this.searchStatus = "La busqueda ha tardado demasiado. Intentalo de nuevo.";
      }
    }, 120000);

    this.pollingInterval = setInterval(async () => {
      if (!this.currentQuery) {
        this.stopPolling();
        return;
      }
      try {
        const response = await this.peopleService.runSearchPeople(
          this.currentQuery, this.currentOffset, this.itemsPerPage, this.currentSortOrder
        );
        this.processApiResponse(response);
      } catch (error) {
        this.searchError = "Error durante el sondeo: " + error;
        this.stopPolling();
      }
    }, 5000);
  }

  private stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.pollTimeout) {
      clearTimeout(this.pollTimeout);
      this.pollTimeout = null;
    }
    this.isPolling = false;
  }

  private resetSearchState() {
    this.stopPolling();
    this.currentQuery = "";
    this.searchQuery = "";
    this.filteredResults = [];
    this.displayResults = [];
    this.selectedPeople = [];
    this.currentSearchId = null;
    this.totalResultsInServer = 0;
    this.searchStatusSelect = null;
    this.currentOffset = 0;
    this.searchStatus = "";
    this.searchError = null;
    this.showPlans = false;
    this.isLoading = false;
    this.isAiSearching = false;
  }

  private getStatusText(): string {
    switch (this.searchStatusSelect) {
      case 1: return "Busqueda IA en progreso";
      case 2: return "Busqueda IA completada";
      case 3: return "Busqueda finalizada sin resultados";
      default: return this.isPolling ? "Iniciando busqueda..." : "";
    }
  }

  async goToPage(page: number) {
    if (page < 1 || !this.currentQuery || this.isLoading) return;

    const newOffset = (page - 1) * this.itemsPerPage;
    if (newOffset >= this.totalResultsInServer && this.totalResultsInServer > 0) {
      return;
    }

    this.isLoading = true;
    this.currentPage = page;
    this.currentOffset = newOffset;

    try {
      const response = await this.peopleService.runSearchPeople(
        this.currentQuery, newOffset, this.itemsPerPage, this.currentSortOrder
      );
      this.processApiResponse(response);
    } catch (error) {
      console.error("Error loading page:", error);
      this.searchError = "Error al cargar la pagina.";
      this.isLoading = false;
    }
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === "Enter") {
      this.onSearch()
    }
  }

  get showSelectionBar(): boolean {
    return this.selectedPeople.length > 0
  }

  changeView(view: "grid" | "card" | "default") {
    this.currentView = view
    switch (view) {
      case "grid": this.currentViewText = "Grid view"; break;
      case "card": this.currentViewText = "Card view"; break;
      case "default": this.currentViewText = "Default view"; break;
    }
  }

  toggleSelectAll() {
    this.selectAllChecked = !this.selectAllChecked
    this.selectedPeople = this.selectAllChecked ? this.displayResults.map(p => p.id) : [];
  }

  togglePeopleSelection(peopleId: number) {
    const index = this.selectedPeople.indexOf(peopleId)
    if (index > -1) {
      this.selectedPeople.splice(index, 1)
    } else {
      this.selectedPeople.push(peopleId)
    }
    this.selectAllChecked = this.displayResults.length > 0 && this.selectedPeople.length === this.displayResults.length;
  }

  async addToMyList() {
    const creditsNeeded = this.selectedPeople.length;
    if (this.selectedPeople.length === 0) {
      this.notificationService.showError("No people selected")
      return
    }
    if (this.creditsRemaining < creditsNeeded) {
      this.notificationService.showError(`No tienes créditos suficientes. Necesitas ${creditsNeeded} y tienes ${this.creditsRemaining}.`);
      return;
    }
    this.isSaving = true;
    try {
      const result = await this.myListPeopleService.savePeopleResults(this.selectedPeople)
      if (result.error) {
        this.notificationService.showError(result.message || "Error saving people")
      } else {
        if (result.creditsRemaining !== undefined) {
          this.authService.updateCurrentUserCredits(result.creditsRemaining);
        }

        this.onboardingService.completeOnboardingStepByKey('SAVE_LEAD');

        const searchId = this.currentSearchId;

        if (searchId === null) {
          this.notificationService.showError("No se pudo iniciar el scraping: ID de búsqueda no disponible.");
          return;
        }

        try {
          const response = await fetch(this.apiConfig.scrapingPeopleUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "AjawCompanyLeads": "oci=4^Br463sStYm"
            },
            body: JSON.stringify({ searchId })
          });

          if (!response.ok) throw new Error(`HTTP error ${response.status}`);

          const scrapeResult = await response.json();
          const status = scrapeResult?.status;
          const message = scrapeResult?.data?.[0]?.message;

          if (status === 0 && message === "in process") {
            this.notificationService.showSuccess("People added to your list.");
          } else {
            this.notificationService.showInfo("The people were added, but the scraping could not be started.");
          }
          this.selectedPeople = [];
          this.selectAllChecked = false;
        } catch (scrapeError) {
          console.error("Error calling scrape service:", scrapeError);
        }
      }
    } catch (error) {
      console.error("Error adding people to list:", error)
      this.notificationService.showError("Error adding people to list")
    } finally {
      this.isSaving = false;
    }
  }

  async addAllToMyList() {
    if (!this.currentSearchId || this.totalResultsInServer === 0) {
      this.notificationService.showError("No hay una busqueda activa o la busqueda no arrojo resultados.");
      return;
    }
    const creditsNeeded = this.totalResultsInServer;
    if (this.creditsRemaining < creditsNeeded) {
      this.notificationService.showError(`No tienes creditos suficientes. Necesitas ${creditsNeeded} y tienes ${this.creditsRemaining}.`);
      return;
    }
    this.isSavingAll = true;
    try {
      const result = await this.myListPeopleService.saveAllPeopleResults(this.currentSearchId);
      if (result && result.error === false && typeof result.saved === 'number') {
        if (result.creditsRemaining !== undefined) {
          this.authService.updateCurrentUserCredits(result.creditsRemaining);
        }

        const searchId = this.currentSearchId;
        if (searchId === null) {
          this.notificationService.showError("No se pudo iniciar el scraping: ID de búsqueda no disponible.");
          return;
        }

        try {
          const response = await fetch(this.apiConfig.scrapingPeopleUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "AjawCompanyLeads": "oci=4^Br463sStYm"
            },
            body: JSON.stringify({ searchId })
          });

          if (!response.ok) throw new Error(`HTTP error ${response.status}`);

          const scrapeResult = await response.json();
          const status = scrapeResult?.status;
          const message = scrapeResult?.data?.[0]?.message;

          if (status === 0 && message === "in process") {
            this.notificationService.showSuccess("People added to your list.");
          } else {
            this.notificationService.showInfo("The people were added, but the scraping could not be started.");
          }

          this.notificationService.showSuccess(`${result.saved} nuevas personas anadidas a tu lista.`);
          this.selectedPeople = [];
          this.selectAllChecked = false;
        } catch (scrapeError) {
          console.error("Error calling scrape service:", scrapeError);
        }
      } else {
        const errorMessage = result?.message || "Ocurrio un error en el servidor. Por favor, intentalo de nuevo.";
        this.notificationService.showError(errorMessage);
      }
    } catch (error) {
      console.error("Error adding all people to list:", error);
      this.notificationService.showError("Error de conexion al guardar todas las personas.");
    } finally {
      this.isSavingAll = false;
    }
  }

  downloadSelected() {
    this.notificationService.showError(`Downloading ${this.selectedPeople.length} selected people`)
  }

  viewSelected() {
    this.notificationService.showError(`Viewing ${this.selectedPeople.length} selected people`)
  }

  closeSelectionBar() {
    this.selectedPeople = []
    this.selectAllChecked = false
  }

  get totalPages(): number {
    return Math.ceil(this.totalResultsInServer / this.itemsPerPage)
  }

  getStartIndex(): number {
    return this.displayResults.length > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.totalResultsInServer);
  }

  getFormattedTotal(): string {
    return this.totalResultsInServer.toLocaleString()
  }

  toggleDropdown(dropdownName: string) {
    this.showViewDropdown = dropdownName === 'view' ? !this.showViewDropdown : false;
    this.showImportDropdown = dropdownName === 'import' ? !this.showImportDropdown : false;
    this.showWorkflowDropdown = dropdownName === 'workflow' ? !this.showWorkflowDropdown : false;
    this.showSortDropdown = dropdownName === 'sort' ? !this.showSortDropdown : false;
  }

  closeAllDropdowns() {
    this.showViewDropdown = false
    this.showImportDropdown = false
    this.showWorkflowDropdown = false
    this.showSortDropdown = false
  }

  getStatusClass(status: number): string {
    switch (status) {
      case 1: return 'status-orange';
      case 2: return 'status-green';
      case 3: return 'status-red';
      default: return '';
    }
  }

  goToUpgradePlan(): void {
    this.router.navigate(['/upgrade-plan']);
  }

  public applyLocalFilters(): void {
    let results = [...this.filteredResults];
    if (this.localFilters.name) {
      results = results.filter(p => p.name && p.name.toLowerCase().includes(this.localFilters.name.toLowerCase()));
    }
    if (this.localFilters.jobTitle) {
      results = results.filter(p => p.jobTitle && p.jobTitle.toLowerCase().includes(this.localFilters.jobTitle.toLowerCase()));
    }
    if (this.localFilters.company) {
      results = results.filter(p => p.company && p.company.toLowerCase().includes(this.localFilters.company.toLowerCase()));
    }
    if (this.localFilters.location) {
      results = results.filter(p => p.location && p.location.toLowerCase().includes(this.localFilters.location.toLowerCase()));
    }
    this.displayResults = results;
  }

  public onFilterChange(): void {
    this.currentPage = 1;
    this.applyLocalFilters();
  }

  public toggleFilters(): void {
    this.showFilters = !this.showFilters;
    if (!this.showFilters) {
      this.currentPage = 1;
      this.localFilters = { name: '', jobTitle: '', company: '', location: '' };
      this.applyLocalFilters();
    }
  }

  public onSortChange(sortBy: string): void {
    this.currentSortOrder = sortBy;
    this.goToPage(1);
    this.closeAllDropdowns();
  }
}
