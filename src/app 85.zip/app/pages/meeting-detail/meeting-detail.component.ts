import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MeetingService, CalBooking } from '../../services/meeting.service';

@Component({
  selector: 'app-meeting-detail',
  standalone: true,
  imports: [CommonModule, TranslateModule, RouterModule],
  templateUrl: './meeting-detail.component.html',
  styleUrl: './meeting-detail.component.css'
})
export class MeetingDetailComponent implements OnInit {

  private route     = inject(ActivatedRoute);
  private router    = inject(Router);
  private translate = inject(TranslateService);
  public  svc       = inject(MeetingService);

  meeting:  CalBooking | null = null;
  isLoading = true;
  error: string | null = null;

  async ngOnInit() {
    const uid = this.route.snapshot.paramMap.get('uid');
    if (!uid) {
      this.error     = this.translate.instant('MEETINGS.DETAIL.ERROR.NO_UID');
      this.isLoading = false;
      return;
    }
    await this.load(uid);
  }

  async load(uid: string) {
    this.isLoading = true;
    this.error     = null;
    try {
      this.meeting = await this.svc.getBookingByUid(uid);
      if (!this.meeting) {
        this.error = this.translate.instant('MEETINGS.DETAIL.ERROR.NOT_FOUND');
      }
    } catch (e: any) {
      this.error = e.message || this.translate.instant('MEETINGS.DETAIL.ERROR.LOAD');
    } finally {
      this.isLoading = false;
    }
  }

  goBack(): void {
    this.router.navigate(['/meetings']);
  }

  getInitials(name: string): string {
    return name.split(' ').slice(0, 2).map(n => n[0] ?? '').join('').toUpperCase();
  }

  avatarColor(name: string): string {
    const palette = ['#5b4fe5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return palette[Math.abs(hash) % palette.length];
  }

  statusKey(status: string): string {
    const map: Record<string, string> = {
      ACCEPTED:  'MEETINGS.STATUS.ACCEPTED',
      PENDING:   'MEETINGS.STATUS.PENDING',
      CANCELLED: 'MEETINGS.STATUS.CANCELLED',
      REJECTED:  'MEETINGS.STATUS.REJECTED'
    };
    return map[status] ?? status;
  }

  attendeeStatusKey(status?: string): string {
    const map: Record<string, string> = {
      accepted:  'MEETINGS.DETAIL.ATTENDEE_STATUS.ACCEPTED',
      pending:   'MEETINGS.DETAIL.ATTENDEE_STATUS.PENDING',
      declined:  'MEETINGS.DETAIL.ATTENDEE_STATUS.DECLINED',
      tentative: 'MEETINGS.DETAIL.ATTENDEE_STATUS.TENTATIVE'
    };
    return map[status ?? ''] ?? 'MEETINGS.DETAIL.ATTENDEE_STATUS.PENDING';
  }
}
