import { Injectable } from '@angular/core';
import { AgentService } from './agent.service';

export interface CalBooking {
  id: number;
  uid: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  updatedAt?: string;
  status: 'ACCEPTED' | 'PENDING' | 'CANCELLED' | 'REJECTED';
  location?: string;
  meetingUrl?: string;
  timeZone?: string;
  attendees: CalAttendee[];
  organizer: { name: string; email: string };
  agentId?: number;
  agentName?: string;
  calToken?: string;
}

export interface CalAttendee {
  name: string;
  email: string;
  timeZone?: string;
  attendeeStatus?: 'accepted' | 'pending' | 'declined' | 'tentative';
  role?: 'owner' | 'attendee';
}

export interface MeetingGroup {
  label: string;
  tag: 'today' | 'tomorrow' | 'upcoming';
  meetings: CalBooking[];
}

@Injectable({
  providedIn: 'root'
})
export class MeetingService {

  private readonly CAL_API_BASE = 'https://api.cal.com/v1';

  private cache: CalBooking[] = [];

  constructor(private agentService: AgentService) {}

  async getAllMeetings(): Promise<CalBooking[]> {
    const agents = await this.agentService.getAgents();
    const agentsWithToken = agents.filter(a => a.calToken);
    if (agentsWithToken.length === 0) return [];

    const allBookings: CalBooking[] = [];

    await Promise.all(
      agentsWithToken.map(async (agent) => {
        try {
          const bookings = await this.fetchBookingsForAgent(agent.calToken!, agent.id, agent.name);
          allBookings.push(...bookings);
        } catch (err) {
          console.error(`Error fetching bookings for agent "${agent.name}":`, err);
        }
      })
    );

    const seen = new Set<string>();
    const unique = allBookings.filter(b => {
      if (seen.has(b.uid)) return false;
      seen.add(b.uid);
      return true;
    });

    unique.sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
    this.cache = unique;
    return unique;
  }

  async getBookingByUid(uid: string): Promise<CalBooking | null> {
    const cached = this.cache.find(b => b.uid === uid);
    if (cached) return cached;

    const agents = await this.agentService.getAgents();
    const agentsWithToken = agents.filter(a => a.calToken);

    for (const agent of agentsWithToken) {
      try {
        const bookings = await this.fetchBookingsForAgent(agent.calToken!, agent.id, agent.name);
        const found = bookings.find(b => b.uid === uid);
        if (found) return found;
      } catch (err) {
        console.error(`Error searching booking in agent "${agent.name}":`, err);
      }
    }
    return null;
  }

  private async fetchBookingsForAgent(
    calToken: string,
    agentId: number,
    agentName: string
  ): Promise<CalBooking[]> {
    const url = `${this.CAL_API_BASE}/bookings?apiKey=${calToken}&status=upcoming`;
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`Cal.com API error ${response.status} for agent "${agentName}"`);
    }

    const data = await response.json();
    const bookings: any[] = data.bookings || [];

    return bookings.map((b: any): CalBooking => {
      const meetingUrl =
        b.videoCallData?.url ||
        b.metadata?.videoCallUrl ||
        (typeof b.location === 'string' && b.location.startsWith('http') ? b.location : undefined);

      const attendees: CalAttendee[] = (b.attendees || []).map((att: any) => ({
        name:           att.name,
        email:          att.email,
        timeZone:       att.timeZone,
        attendeeStatus: att.noShow ? 'declined' : 'accepted',
        role:           'attendee' as const
      }));

      if (b.user) {
        const ownerIdx = attendees.findIndex(a => a.email === b.user.email);
        if (ownerIdx === -1) {
          attendees.unshift({
            name: b.user.name, email: b.user.email,
            attendeeStatus: 'accepted', role: 'owner'
          });
        } else {
          attendees[ownerIdx].role = 'owner';
        }
      }

      return {
        id: b.id, uid: b.uid, title: b.title,
        description: b.description,
        startTime: b.startTime, endTime: b.endTime,
        updatedAt: b.updatedAt,
        status: b.status,
        location: typeof b.location === 'string' && !b.location.startsWith('http')
          ? b.location : undefined,
        meetingUrl,
        timeZone: b.attendees?.[0]?.timeZone,
        attendees,
        organizer: b.user || { name: agentName, email: '' },
        agentId, agentName, calToken
      };
    });
  }

  groupMeetings(meetings: CalBooking[]): MeetingGroup[] {
    const { todayStart, tomorrowStart, dayAfterTomorrow } = this.getDateBoundaries();
    const groups: MeetingGroup[] = [];
    const today    = meetings.filter(m => { const s = new Date(m.startTime); return s >= todayStart    && s < tomorrowStart;    });
    const tomorrow = meetings.filter(m => { const s = new Date(m.startTime); return s >= tomorrowStart && s < dayAfterTomorrow; });
    const upcoming = meetings.filter(m => new Date(m.startTime) >= dayAfterTomorrow);
    if (today.length)    groups.push({ label: 'Hoy',      tag: 'today',    meetings: today    });
    if (tomorrow.length) groups.push({ label: 'Mañana',   tag: 'tomorrow', meetings: tomorrow });
    if (upcoming.length) groups.push({ label: 'Próximas', tag: 'upcoming', meetings: upcoming });
    return groups;
  }

  getUpcomingMeetings(meetings: CalBooking[]): CalBooking[] {
    const { todayStart, dayAfterTomorrow } = this.getDateBoundaries();
    return meetings.filter(m => {
      const s = new Date(m.startTime);
      return s >= todayStart && s < dayAfterTomorrow;
    });
  }

  isHappeningNow(m: CalBooking): boolean {
    const now = Date.now();
    return new Date(m.startTime).getTime() <= now && now <= new Date(m.endTime).getTime();
  }

  isSoon(m: CalBooking): boolean {
    const mins = this.minutesUntil(m.startTime);
    return mins > 0 && mins <= 30;
  }

  minutesUntil(dateStr: string): number {
    return Math.round((new Date(dateStr).getTime() - Date.now()) / 60000);
  }

  getDuration(start: string, end: string): string {
    const diff = Math.round((new Date(end).getTime() - new Date(start).getTime()) / 60000);
    if (diff >= 60) {
      const h = Math.floor(diff / 60);
      const m = diff % 60;
      return m > 0 ? `${h}h ${m}min` : `${h}h`;
    }
    return `${diff} min`;
  }

  formatTime(dateStr: string): string {
    return new Date(dateStr).toLocaleTimeString('es-CO', {
      hour: '2-digit', minute: '2-digit', hour12: true
    });
  }

  formatShortDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-CO', {
      weekday: 'short', day: 'numeric', month: 'short'
    });
  }

  formatFullDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-CO', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  }

  formatLongDateTime(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-CO', {
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true
    });
  }

  private getDateBoundaries() {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrowStart = new Date(todayStart); tomorrowStart.setDate(tomorrowStart.getDate() + 1);
    const dayAfterTomorrow = new Date(tomorrowStart); dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 1);
    return { todayStart, tomorrowStart, dayAfterTomorrow };
  }
}
