import {
  Component, Input, Output, EventEmitter,
  OnInit, ViewChild, ElementRef, AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiConfigService } from '../../services/api-config.service';

export interface ChatMessage {
  role: 'assistant' | 'user';
  text: string;
}

export interface QuickPrompt {
  label: string;
  query: string;
}

export type SearchChatMode = 'people' | 'companies';

@Component({
  selector: 'app-search-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-chat.component.html',
  styleUrl: './search-chat.component.css',
})
export class SearchChatComponent implements OnInit, AfterViewChecked {
  @Input() mode: SearchChatMode = 'people';
  @Output() searchReady = new EventEmitter<string>();

  @ViewChild('messagesEnd') messagesEnd!: ElementRef;

  messages: ChatMessage[] = [];
  userInput = '';
  isLoading = false;
  isIntroLoading = false;
  hasStarted = false;

  private shouldScroll = false;
  private history: { role: 'user' | 'assistant'; content: string }[] = [];

  greeting = '';
  title = '¿A quién quieres encontrar hoy?';
  subtitle = 'Encuentra al tomador de decisión correcto en cualquier empresa de Latinoamérica — cada búsqueda llena tu mapa de leads.';
  inputPlaceholder = 'Busca por nombre, cargo o empresa…';

  // IMPORTANTE: quickPrompts se calcula UNA sola vez (ngOnInit) y se guarda como propiedad
  // estable, no como getter. Un getter usado en *ngFor crea un array (y objetos) nuevos en
  // cada ciclo de change detection —Angular no puede saber que son "los mismos" chips porque
  // cambian de identidad todo el tiempo, así que destruye y vuelve a crear ese DOM en cada
  // ciclo. Como Angular dispara change detection en cada evento (incluido mousemove), eso
  // termina congelando la pestaña con solo mover el mouse. Con una propiedad fija esto no pasa.
  quickPrompts: QuickPrompt[] = [];

  constructor(
    private apiConfig: ApiConfigService
  ) { }

  ngOnInit(): void {
    this.greeting = this.computeGreeting();
    this.quickPrompts = this.buildQuickPrompts();
    this.startConversation();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll) {
      this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
      this.shouldScroll = false;
    }
  }

  private computeGreeting(): string {
    const hour = new Date().getHours();
    const label = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches';
    return `${label} 👋`;
  }

  private buildQuickPrompts(): QuickPrompt[] {
    return this.mode === 'people'
      ? [
        { label: 'CEOs · Bogotá', query: 'CEOs y dueños de empresas en Bogotá' },
        { label: 'Gerentes de ventas', query: 'Gerentes de ventas en Colombia' },
        { label: 'Fundadores · Medellín', query: 'Fundadores de empresas en Medellín' },
        { label: 'Directores de marketing', query: 'Directores de marketing en Colombia con anuncios activos' },
      ]
      : [
        { label: 'Startups · fintech MX', query: 'Startups fintech en México' },
        { label: 'SaaS B2B · Colombia', query: 'Empresas SaaS B2B en Colombia con más de 50 empleados' },
        { label: 'Logística en crecimiento', query: 'Compañías logísticas en crecimiento en Latinoamérica' },
        { label: 'Salud · Medellín', query: 'Clínicas y centros de salud en Medellín' },
      ];
  }

  private async startConversation(): Promise<void> {
    this.isIntroLoading = true;
    const greeting = await this.callAgent([]);
    this.isIntroLoading = false;

    this.messages = [{ role: 'assistant', text: greeting }];
    this.history = [{ role: 'assistant', content: greeting }];
  }

  async send(prefill?: string): Promise<void> {
    const text = (prefill ?? this.userInput).trim();
    if (!text || this.isLoading || this.isIntroLoading) return;

    this.hasStarted = true;
    this.userInput = '';

    this.pushMsg('user', text);
    this.history.push({ role: 'user', content: text });

    this.isLoading = true;
    const reply = await this.callAgent(this.history);
    this.isLoading = false;

    const match = reply.match(/SEARCH_READY::(.+)/);

    if (match) {
      const query = match[1].trim();
      const cleanReply =
        reply.replace(/SEARCH_READY::.+/, '').trim() ||
        'Perfecto. Estoy preparando la búsqueda con los criterios que definimos.';

      this.pushMsg('assistant', cleanReply);
      this.history.push({ role: 'assistant', content: cleanReply });

      setTimeout(() => this.searchReady.emit(query), 900);
    } else {
      this.pushMsg('assistant', reply);
      this.history.push({ role: 'assistant', content: reply });
    }
  }

  usePrompt(prompt: QuickPrompt): void {
    this.send(prompt.query);
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.send();
    }
  }

  trackByIndex(index: number): number {
    return index;
  }

  private pushMsg(role: 'assistant' | 'user', text: string): void {
    this.messages.push({ role, text });
    this.shouldScroll = true;
  }

  private async callAgent(
    history: { role: 'user' | 'assistant'; content: string }[]
  ): Promise<string> {
    try {
      const response = await fetch(this.apiConfig.chatAgentUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history, mode: this.mode }),
      });

      if (!response.ok) {
        return 'Lo siento, hubo un problema de conexión. Por favor intenta de nuevo.';
      }

      const data = await response.json();
      return data.reply ?? 'No pude procesar tu mensaje.';
    } catch (err) {
      console.error('Chat agent error:', err);
      return 'Error de red. Por favor intenta de nuevo.';
    }
  }
}