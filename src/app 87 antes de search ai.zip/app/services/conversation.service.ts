import { Injectable, inject } from '@angular/core';
import { ApiConfigService } from './api-config.service';

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACES
// ─────────────────────────────────────────────────────────────────────────────

export interface ConversationParticipant {
  name: string;
  email?: string;
  speakingPercent?: number;
  speakingMinutes?: number;
}

export interface TranscriptSegment {
  speakerName: string;
  text: string;
  timestampSeconds: number;
}

export interface NextStep {
  ownerName: string;
  items: string[];
}

export interface Conversation {
  id: string;
  title: string;
  date: string;
  durationSeconds: number;
  status: 'completed' | 'processing' | 'failed';
  participants: ConversationParticipant[];
  recordingUrl?: string;
  thumbnailUrl?: string;
  hostName?: string;
  agentName?: string;
  summary?: string;
  nextSteps?: NextStep[];
  transcript?: TranscriptSegment[];
  tags?: string[];
  meetProvider?: 'google_meet' | 'zoom' | 'other';
  meetUrl?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// SERVICE
// ─────────────────────────────────────────────────────────────────────────────

interface CalendarEntry {
  calendarId: string;
  accessToken: string;
  agentName: string | null;
}

@Injectable({ providedIn: 'root' })
export class ConversationService {

  private apiConfig = inject(ApiConfigService);

  // ══════════════════════════════════════════════════════════════════════════
  // PUBLIC API
  // ══════════════════════════════════════════════════════════════════════════

  async getConversations(dateFrom?: string, dateTo?: string): Promise<Conversation[]> {
    const today = this.todayIso();
    const from  = dateFrom ?? today;
    const to    = dateTo   ?? today;

    // 1. Get calendar list from backend
    const calendars = await this.getCalendarsFromBackend();
    if (calendars.length === 0) return [];

    // 2. For each calendar: refresh token → get fresh token → fetch Google events
    const results = await Promise.allSettled(
      calendars.map(cal => this.fetchEventsForCalendar(cal, from, to))
    );

    // 3. Flatten fulfilled results, sort by date descending
    const conversations: Conversation[] = [];
    for (const result of results) {
      if (result.status === 'fulfilled') conversations.push(...result.value);
    }
    conversations.sort((a, b) => b.date.localeCompare(a.date));
    return conversations;
  }

  async getConversationById(id: string): Promise<Conversation | null> {
    const now  = new Date();
    const from = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
    const all  = await this.getConversations(from, this.todayIso());
    return all.find(c => c.id === id) ?? null;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PRIVATE — orchestration
  // ══════════════════════════════════════════════════════════════════════════

  private async fetchEventsForCalendar(
    cal: CalendarEntry,
    dateFrom: string,
    dateTo: string
  ): Promise<Conversation[]> {

    const refreshUrl = `${this.apiConfig.refreshCalendarTokenUrl}?calendarId=${cal.calendarId}`;
    const refreshResp = await fetch(refreshUrl, { method: 'GET' });
    const refreshData = await refreshResp.json();

    if (!refreshData.success || refreshData.success === 'false' || refreshData.success === false) {
      console.warn(`Calendar refresh skipped for ${cal.calendarId}:`, refreshData.error);
      return [];
    }

    const freshCal = await this.getCalendarByIdFromBackend(cal.calendarId);
    if (!freshCal) return [];

    return this.fetchGoogleCalendarEvents(freshCal, dateFrom, dateTo);
  }

  private async getCalendarsFromBackend(): Promise<CalendarEntry[]> {
    const response = await this.fetchData(
      'com.ajawmrp3.apps.prospectingai.web.ConversationController:getCalendars', {}
    );
    return (response?.calendars ?? []) as CalendarEntry[];
  }

  private async getCalendarByIdFromBackend(calendarId: string): Promise<CalendarEntry | null> {
    const response = await this.fetchData(
      'com.ajawmrp3.apps.prospectingai.web.ConversationController:getCalendarById',
      { _calendarId: calendarId }
    );
    if (!response || response.error) return null;
    return {
      calendarId:  response.calendarId,
      accessToken: response.accessToken,
      agentName:   response.agentName ?? null,
    };
  }

  private async fetchGoogleCalendarEvents(
    cal: CalendarEntry,
    dateFrom: string,
    dateTo: string
  ): Promise<Conversation[]> {
    const params = new URLSearchParams({
      timeMin:      `${dateFrom}T00:00:00.000Z`,
      timeMax:      `${dateTo}T23:59:59.000Z`,
      singleEvents: 'true',
      orderBy:      'startTime',
      maxResults:   '100',
    });

    const url = `${this.apiConfig.googleCalendarEventsUrl.replace('{calendarId}', encodeURIComponent(cal.calendarId))}?${params}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: { Authorization: `Bearer ${cal.accessToken}` },
    });

    if (!response.ok) return [];

    const data = await response.json();
    return (data.items ?? [])
      .filter((e: any) => e.status !== 'cancelled')
      .map((e: any) => this.mapGoogleEventToConversation(e, cal.agentName));
  }

  private mapGoogleEventToConversation(event: any, agentName: string | null): Conversation {
    const date        = event.start?.dateTime ?? (event.start?.date + 'T00:00:00.000Z');
    const endDate     = event.end?.dateTime   ?? (event.end?.date   + 'T00:00:00.000Z');
    const durationSeconds = Math.max(
      0, Math.round((new Date(endDate).getTime() - new Date(date).getTime()) / 1000)
    );
    const entryPoints: any[] = event.conferenceData?.entryPoints ?? [];
    const videoEntry  = entryPoints.find((ep: any) => ep.entryPointType === 'video');
    const meetUrl     = videoEntry?.uri ?? event.hangoutLink ?? undefined;

    return {
      id:             event.id,
      title:          event.summary ?? '(Sin título)',
      date,
      durationSeconds,
      status:         'completed',
      participants:   (event.attendees ?? []).map((a: any) => ({
        name:  a.displayName || a.email || 'Invitado',
        email: a.email ?? undefined,
      })),
      hostName:       event.organizer?.displayName || event.organizer?.email || undefined,
      agentName:      agentName ?? undefined,
      summary:        event.description ?? undefined,
      meetUrl,
      meetProvider:   'google_meet',
    };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════════════════════

  formatDuration(seconds: number): string {
    if (!seconds || seconds <= 0) return '—';
    if (seconds < 60) return `${seconds}s`;
    const m = Math.floor(seconds / 60);
    const h = Math.floor(m / 60);
    return h > 0 ? `${h}h ${m % 60}m` : `${m}m`;
  }

  formatDate(iso: string): string {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    });
  }

  formatShortDate(iso: string): string {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit', month: 'short', year: 'numeric',
    });
  }

  formatTimestamp(seconds: number): string {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  getInitials(name: string): string {
    return name.split(' ').slice(0, 2).map(n => n[0] ?? '').join('').toUpperCase();
  }

  avatarColor(name: string): string {
    const palette = ['#5b4fe5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return palette[Math.abs(hash) % palette.length];
  }

  private todayIso(): string {
    return new Date().toISOString().slice(0, 10);
  }

  private async fetchData(action: string, data: any): Promise<any> {
    const token = localStorage.getItem('csrfToken');
    if (!token) throw new Error('No authentication token found');

    const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
      body: JSON.stringify({ action, data }),
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const result = await response.json();
    if (result.error) throw new Error(result.error.message || 'Unknown error');
    return result.data;
  }
}