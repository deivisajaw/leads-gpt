import { Component, OnInit, inject, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import {
  ConversationService,
  ChatwootAgent,
  ChatwootMessage,
  ContactConversationGroup
} from '../../services/conversation.service';

@Component({
  selector: 'app-conversations',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule],
  templateUrl: './conversations.component.html',
  styleUrl: './conversations.component.css'
})
export class ConversationsComponent implements OnInit {

  @ViewChild('agentScroll') agentScrollRef!: ElementRef<HTMLDivElement>;

  public svc = inject(ConversationService);

  // ── State ─────────────────────────────────────────────────────────────────
  isLoadingAgents = true;
  isLoadingConvs  = false;
  isLoadingMsgs   = false;
  agentError:  string | null = null;
  convError:   string | null = null;

  agents:        ChatwootAgent[]           = [];
  selectedAgent: ChatwootAgent | null      = null;

  contactGroups:    ContactConversationGroup[] = [];
  filteredGroups:   ContactConversationGroup[] = [];
  selectedGroup:    ContactConversationGroup | null = null;

  messages:  ChatwootMessage[] = [];

  searchQuery  = '';
  statusFilter: 'all' | 'open' | 'resolved' | 'pending' = 'all';

  // ── Init ──────────────────────────────────────────────────────────────────
  async ngOnInit() {
    await this.loadAgents();
  }

  // ── Agents ────────────────────────────────────────────────────────────────
  async loadAgents() {
    this.isLoadingAgents = true;
    this.agentError = null;
    try {
      this.agents = await this.svc.getAgentsWithChatwoot();
      if (this.agents.length === 1) await this.selectAgent(this.agents[0]);
    } catch (e: any) {
      this.agentError = e.message || 'Error al cargar agentes';
    } finally {
      this.isLoadingAgents = false;
    }
  }

  scrollAgents(dir: 'left' | 'right') {
    const el = this.agentScrollRef?.nativeElement;
    if (el) el.scrollBy({ left: dir === 'right' ? 200 : -200, behavior: 'smooth' });
  }

  async selectAgent(agent: ChatwootAgent) {
    if (this.selectedAgent?.id === agent.id) return;
    this.selectedAgent  = agent;
    this.selectedGroup  = null;
    this.messages       = [];
    this.searchQuery    = '';
    // Limpiar grupos antes de cargar nuevos — fix del bug de estado compartido
    this.contactGroups  = [];
    this.filteredGroups = [];
    await this.loadConversations();
  }

  // ── Conversations ─────────────────────────────────────────────────────────
  async loadConversations() {
    if (!this.selectedAgent) return;
    this.isLoadingConvs = true;
    this.convError = null;
    // Resetear siempre antes de cargar
    this.contactGroups  = [];
    this.filteredGroups = [];
    this.selectedGroup  = null;
    this.messages       = [];
    try {
      this.contactGroups = await this.svc.getConversationsGroupedByContact(
        this.selectedAgent, this.statusFilter
      );
      this.applyFilter();
    } catch (e: any) {
      this.convError = e.message || 'Error al cargar conversaciones';
    } finally {
      this.isLoadingConvs = false;
    }
  }

  onStatusChange(status: 'all' | 'open' | 'resolved' | 'pending') {
    this.statusFilter = status;
    this.loadConversations();
  }

  onSearch(event: Event) {
    this.searchQuery = (event.target as HTMLInputElement).value;
    this.applyFilter();
  }

  applyFilter() {
    if (!this.searchQuery.trim()) {
      this.filteredGroups = [...this.contactGroups];
      return;
    }
    const q = this.searchQuery.toLowerCase();
    this.filteredGroups = this.contactGroups.filter(g =>
      g.contact.name.toLowerCase().includes(q) ||
      (g.contact.email ?? '').toLowerCase().includes(q) ||
      (g.contact.phone_number ?? '').toLowerCase().includes(q) ||
      g.conversations.some(c => c.last_message?.content?.toLowerCase().includes(q))
    );
  }

  // ── Contact selection → load messages ────────────────────────────────────
  async selectGroup(group: ContactConversationGroup) {
    this.selectedGroup = group;
    this.messages = [];
    if (!this.selectedAgent) return;
    this.isLoadingMsgs = true;
    try {
      this.messages = await this.svc.getMessagesForContact(this.selectedAgent, group);
    } catch (e: any) {
      console.error('Error loading messages:', e);
    } finally {
      this.isLoadingMsgs = false;
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  totalConversations(): number {
    return this.contactGroups.reduce((s, g) => s + g.conversations.length, 0);
  }

  totalUnread(): number {
    return this.contactGroups.reduce((s, g) => s + g.totalUnread, 0);
  }

  hasUnread(group: ContactConversationGroup): boolean {
    return group.totalUnread > 0;
  }

  getLastMessagePreview(group: ContactConversationGroup): string {
    const last = [...group.conversations].sort((a, b) => b.updated_at - a.updated_at)[0];
    return last?.last_message?.content || 'Sin mensajes';
  }

  getFirstStatus(group: ContactConversationGroup): string {
    const open = group.conversations.find(c => c.status === 'open');
    return open?.status ?? group.conversations[0]?.status ?? 'open';
  }

  getConvStatusSummary(group: ContactConversationGroup): string {
    const counts: Record<string, number> = {};
    group.conversations.forEach(c => counts[c.status] = (counts[c.status] || 0) + 1);
    return Object.entries(counts).map(([s, n]) => `${n} ${this.svc.statusLabel(s)}`).join(' · ');
  }
}