import {
  Component, Input, Output, EventEmitter,
  OnInit, ViewChild, ElementRef, AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiConfigService } from '../../services/api-config.service';

export interface ChatMessage {
  role: 'assistant' | 'user';
  text: string;
}

export type SearchChatMode = 'people' | 'companies';

@Component({
  selector: 'app-search-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-chat.component.html',
  styleUrl: './search-chat.component.css',
})
export class SearchChatComponent implements OnInit, AfterViewChecked {

  @Input() mode: SearchChatMode = 'people';
  @Output() searchReady = new EventEmitter<string>();

  @ViewChild('messagesEnd') messagesEnd!: ElementRef;

  messages: ChatMessage[] = [];
  userInput = '';
  isLoading = false;
  private shouldScroll = false;

  private history: { role: 'user' | 'assistant'; content: string }[] = [];

  constructor(private apiConfig: ApiConfigService) {}

  ngOnInit(): void {
    this.startConversation();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll) {
      this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
      this.shouldScroll = false;
    }
  }

  private async startConversation(): Promise<void> {
    this.isLoading = true;
    const greeting = await this.callAgent([]);
    this.isLoading = false;
    this.pushMsg('assistant', greeting);
    this.history.push({ role: 'assistant', content: greeting });
  }

  async send(): Promise<void> {
    const text = this.userInput.trim();
    if (!text || this.isLoading) return;

    this.userInput = '';
    this.pushMsg('user', text);
    this.history.push({ role: 'user', content: text });

    this.isLoading = true;
    const reply = await this.callAgent(this.history);
    this.isLoading = false;

    const match = reply.match(/SEARCH_READY::(.+)/);
    if (match) {
      const query = match[1].trim();
      const cleanReply = reply.replace(/SEARCH_READY::.+/, '').trim()
        || '¡Perfecto! Lanzando la búsqueda...';
      this.pushMsg('assistant', cleanReply);
      this.history.push({ role: 'assistant', content: cleanReply });
      setTimeout(() => this.searchReady.emit(query), 1200);
    } else {
      this.pushMsg('assistant', reply);
      this.history.push({ role: 'assistant', content: reply });
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.send();
    }
  }

  private pushMsg(role: 'assistant' | 'user', text: string): void {
    this.messages.push({ role, text });
    this.shouldScroll = true;
  }

  private async callAgent(
    history: { role: 'user' | 'assistant'; content: string }[]
  ): Promise<string> {
    try {
      const response = await fetch(this.apiConfig.chatAgentUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history, mode: this.mode }),
      });
      if (!response.ok) {
        return 'Lo siento, hubo un problema de conexión. Por favor intenta de nuevo.';
      }
      const data = await response.json();
      return data.reply ?? 'No pude procesar tu mensaje.';
    } catch (err) {
      console.error('Chat agent error:', err);
      return 'Error de red. Por favor intenta de nuevo.';
    }
  }
}
