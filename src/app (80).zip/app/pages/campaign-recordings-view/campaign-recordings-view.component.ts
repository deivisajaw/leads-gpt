import { Component, OnInit, inject, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CampaignService, Campaign, CallOutcome } from '../../services/campaign.service'; 
import { SafeHtmlPipe } from '../../pipes/safe-html.pipe';
import { TranslateModule } from '@ngx-translate/core';

export interface Recording {
  id: number;
  dateTime: string; 
  contactName: string; 
  contactPhone: string; 
  type: 'inbound' | 'outbound'; 
  agentName: string; 
  companyPhoneNumber: string; 
  outcome: CallOutcome; 
  duration: string; 
  
  // Campos para el panel lateral
  recordingUrl?: string;
  transcription?: string;
  summary?: string;
  calLink?: string;
  appointmentDate?: string;
}

@Component({
  selector: 'app-campaign-recordings-view',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, DatePipe, SafeHtmlPipe, TranslateModule],
  templateUrl: './campaign-recordings-view.component.html',
  styleUrl: './campaign-recordings-view.component.css'
})
export class CampaignRecordingsViewComponent implements OnInit, AfterViewInit {
  @ViewChild('waveformCanvas') waveformCanvas: ElementRef<HTMLCanvasElement> | undefined;

  private campaignService = inject(CampaignService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  campaignId: number | null = null;
  campaignName: string = 'Campaña'; 
  isLoading: boolean = true;
  errorMessage: string | null = null;

  recordings: Recording[] = [];
  filteredRecordings: Recording[] = [];

  filterContact: string = '';
  filterOutcome: string = '';
  filterType: string = '';

  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;

  // --- Propiedades para el Panel Lateral ---
  isPanelOpen: boolean = false;
  selectedRecording: Recording | null = null;
  activeTab: string = 'overview'; // 'overview' o 'transcript'

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.campaignId = +id;
        this.loadCampaignDetails(this.campaignId);
        this.loadRecordings(this.campaignId);
      } else {
        this.errorMessage = 'ID de campaña no proporcionado.';
        this.isLoading = false;
      }
    });
  }

  ngAfterViewInit(): void {
    if (this.isPanelOpen) {
      this.initWaveform();
    }
  }

  async loadCampaignDetails(id: number): Promise<void> {
    try {
      const campaign = await this.campaignService.getCampaignDetails(id);
      this.campaignName = campaign.name;
    } catch (error) {
      console.error('Error loading campaign details:', error);
      this.errorMessage = 'No se pudo cargar el nombre de la campaña.';
    }
  }

  async loadRecordings(campaignId: number): Promise<void> {
    this.isLoading = true;
    this.errorMessage = null;
    try {
      const calls = await this.campaignService.getCallsByCampaign(campaignId);
      this.recordings = calls.map((call: any) => ({
        id: call.id,
        dateTime: this.formatDateTime(call.startedAt),
        contactName: call.customerName || 'N/A',
        contactPhone: call.customerPhone || 'N/A',
        type: call.direction?.toLowerCase() === 'outbound' ? 'outbound' : 'inbound',
        agentName: call.agentName || 'AJAW AI',
        companyPhoneNumber: call.companyPhoneNumber || 'N/A',
        outcome: call.outcome || 'ANSWERED_NO_OUTCOME',
        duration: this.formatDuration(call.durationMs),
        
        // Campos para el panel
        recordingUrl: call.recordingUrl,
        transcription: call.transcription,
        summary: call.summary,
        calLink: call.calLink,
        appointmentDate: call.appointmentDate ? this.formatDateTime(call.appointmentDate) : undefined,
      }));
      this.applyFiltersAndPagination();
    } catch (error) {
      console.error('Error loading recordings:', error);
      this.errorMessage = 'No se pudieron cargar las grabaciones de la campaña.';
      this.recordings = [];
      this.filteredRecordings = [];
    } finally {
      this.isLoading = false;
    }
  }

  applyFiltersAndPagination(): void {
    let tempRecordings = [...this.recordings];

    if (this.filterContact) {
      tempRecordings = tempRecordings.filter(rec =>
        rec.contactName.toLowerCase().includes(this.filterContact.toLowerCase()) ||
        rec.contactPhone.includes(this.filterContact)
      );
    }
    if (this.filterOutcome) {
      tempRecordings = tempRecordings.filter(rec => rec.outcome === this.filterOutcome);
    }
    if (this.filterType) {
      tempRecordings = tempRecordings.filter(rec => rec.type === this.filterType);
    }

    this.totalPages = Math.ceil(tempRecordings.length / this.itemsPerPage);
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.filteredRecordings = tempRecordings.slice(startIndex, endIndex);
  }

  onFilterChange(): void {
    this.currentPage = 1; 
    this.applyFiltersAndPagination();
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.applyFiltersAndPagination();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.applyFiltersAndPagination();
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.applyFiltersAndPagination();
    }
  }

  goBackToCampaign(): void {
    this.router.navigate(['/campaigns', this.campaignId]);
  }

  openPanel(recording: Recording): void {
    this.selectedRecording = recording;
    this.isPanelOpen = true;
    this.activeTab = 'overview';
    setTimeout(() => this.initWaveform(), 0);
  }

  closePanel(): void {
    this.isPanelOpen = false;
    this.selectedRecording = null;
  }

  private formatDuration(ms: number): string {
    if (isNaN(ms) || ms < 0) {
      return '00:00';
    }
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  private formatDateTime(isoString: string): string {
    if (!isoString) return 'N/A';
    try {
      const date = new Date(isoString);
      // Formato: 16/12/2025, 06:08 AM/PM
      return new DatePipe('en-US').transform(date, 'dd/MM/yyyy, hh:mm a') || 'N/A';
    } catch (e) {
      return 'N/A';
    }
  }

  getOutcomeBadgeClass(outcome: CallOutcome): string {
    switch (outcome) {
      case 'APPOINTMENT_SET': return 'badge-success';
      case 'INTERESTED': return 'badge-primary';
      case 'CALLBACK_REQUESTED': return 'badge-info';
      case 'VOICEMAIL': return 'badge-info-light';
      case 'ANSWERED_NO_OUTCOME': return 'badge-secondary';
      case 'NO_ANSWER': return 'badge-warning';
      case 'BUSY': return 'badge-warning-light';
      case 'NOT_INTERESTED': return 'badge-danger';
      case 'DO_NOT_CALL': return 'badge-danger-dark';
      case 'WRONG_NUMBER': return 'badge-danger-light';
      case 'TECHNICAL_ERROR': return 'badge-danger-light';
      case 'CALL_DROPPED': return 'badge-danger-light';
      case 'LANGUAGE_NOT_SUPPORTED': return 'badge-warning';
      default: return 'badge-secondary';
    }
  }

  getOutcomeDisplayText(outcome: CallOutcome): string {
    // Devuelve una clave para ser usada por un pipe de traducción
    return `outcomes.${outcome.toLowerCase()}`;
  }

  // --- Métodos para el nuevo panel ---

  setActiveTab(tabName: string): void {
    this.activeTab = tabName;
  }

  copyToClipboard(text: string): void {
    navigator.clipboard.writeText(text).then(() => {
      console.log('ID copiado!');
    });
  }

  togglePlay(): void {
    console.log('togglePlay triggered');
  }

  rewind(): void {
    console.log('rewind triggered');
  }

  forward(): void {
    console.log('forward triggered');
  }

  downloadAudio(): void {
    console.log('downloadAudio triggered');
  }

  rateConversation(rating: 'up' | 'down'): void {
    console.log(`rateConversation triggered with: ${rating}`);
  }

  initWaveform(): void {
    if (!this.waveformCanvas) return;
    const canvas = this.waveformCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    const barCount = 100;
    const barWidth = width / barCount;
    const centerY = height / 2;
    
    ctx.fillStyle = '#b0bec5';
    
    for (let i = 0; i < barCount; i++) {
      const heightVariation = Math.random() * 0.7 + 0.3;
      const barHeight = (height * 0.6 * heightVariation);
      const x = i * barWidth;
      const y = centerY - barHeight / 2;
      
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    }
  }
}

