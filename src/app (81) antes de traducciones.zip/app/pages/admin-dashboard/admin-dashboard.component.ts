import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { AdminDashboardService, AdminDashboardData } from '../../services/admin-dashboard.service';
import { TranslateModule } from '@ngx-translate/core';

// Imports para graficos
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartData, ChartType } from 'chart.js';
import { Chart, CategoryScale, LinearScale, BarController, BarElement, Tooltip, Legend } from 'chart.js';

// Registrar componentes de Chart.js
Chart.register(
  CategoryScale,
  LinearScale,
  BarController,
  BarElement,
  Tooltip,
  Legend
);

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, TranslateModule, BaseChartDirective], // Anadir BaseChartDirective
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  
  public dashboardData$: Observable<AdminDashboardData | null>;
  public totalDealsWonValue: number = 0; // Added for type conversion

  // --- Propiedades para el grafico de barras ---
  public barChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: { stacked: true },
      y: { stacked: true, beginAtZero: true }
    },
    plugins: {
      legend: { display: true, position: 'bottom' },
      tooltip: { mode: 'index', intersect: false }
    }
  };
  public barChartLabels: string[] = [];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartData: ChartData<'bar'> = {
    labels: [],
    datasets: []
  };
  // --- Fin Propiedades para el grafico de barras ---

  constructor(private adminDashboardService: AdminDashboardService) {
    this.dashboardData$ = this.adminDashboardService.getAdminDashboardMetrics();

    // Populate chart data and convert totalValueDealsWon when dashboardData$ emits
    this.dashboardData$.subscribe(data => {
      if (data) {
        // Update chart data with actual backend fields
        this.barChartLabels = ['Actividad del Equipo'];
        this.barChartData = {
          labels: this.barChartLabels,
          datasets: [
            { data: [data.newUsersLast30Days], label: 'Nuevos Usuarios (30D)', backgroundColor: 'rgba(56, 189, 248, 0.85)' },
            { data: [data.dealsCreatedFromPlatform], label: 'Deals Creados (30D)', backgroundColor: 'rgba(236, 72, 153, 0.85)' },
            { data: [data.companyCreditsSpentLast30Days], label: 'Creditos Gastados (30D)', backgroundColor: 'rgba(250, 204, 21, 0.85)' }
          ]
        };

        // Convert totalValueDealsWon from string to number
        this.totalDealsWonValue = parseFloat(data.totalValueDealsWon || '0');
      }
    });
  }

  ngOnInit(): void {
    // Data is fetched automatically via the async pipe in the template
  }
}
