import { Component, OnInit, inject, OnDestroy, ElementRef, ViewChild, NgZone } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CampaignService, CallOutcome } from '../../services/campaign.service'; 
import { SafeHtmlPipe } from '../../pipes/safe-html.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { FormatTimePipe } from '../../pipes/format-time.pipe';

export interface Recording {
  id: number;
  dateTime: string; 
  contactName: string; 
  contactPhone: string; 
  type: 'inbound' | 'outbound'; 
  agentName: string; 
  companyPhoneNumber: string; 
  outcome: CallOutcome; 
  duration: string; 
  
  // Campos para el panel lateral
  recordingUrl?: string;
  transcription?: string;
  summary?: string;
  calLink?: string;
  appointmentDate?: string;
  companyName?:string;
  campaignName?:string;
}

@Component({
  selector: 'app-calls',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, SafeHtmlPipe, TranslateModule, FormatTimePipe],
  templateUrl: './calls.component.html',
  styleUrl: './calls.component.css'
})
export class CallsComponent implements OnInit, OnDestroy {
  @ViewChild('waveformCanvas') waveformCanvasRef!: ElementRef<HTMLCanvasElement>;
  
  @ViewChild('audioPlayer')
  set audioPlayerRef(ref: ElementRef<HTMLAudioElement> | undefined) {
    if (ref) {
      this.audioPlayer = ref.nativeElement;
      this.initializePlayer();
    }
  }

  private campaignService = inject(CampaignService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private ngZone = inject(NgZone);

  companyName: string = 'Company'; 
  isLoading: boolean = true;
  errorMessage: string | null = null;

  recordings: Recording[] = [];
  filteredRecordings: Recording[] = [];

  filterContact: string = '';
  filterOutcome: string = '';
  filterType: string = '';

  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;

  isPanelOpen: boolean = false;
  selectedRecording: Recording | null = null;
  activeTab: string = 'overview'; 

  // Audio Player Properties
  private audioPlayer!: HTMLAudioElement;
  private isPlayerInitialized = false;
  isPlaying = false;
  duration = 0;
  currentTime = 0;

  // Waveform Properties
  private waveformBars: number[] = [];
  private animationFrameId: number | null = null;

  ngOnInit(): void {
    this.loadRecordings();
  }

  ngOnDestroy(): void {
    this.stopWaveformAnimation();
    if (this.audioPlayer && this.isPlayerInitialized) {
      this.audioPlayer.removeEventListener('timeupdate', this.onTimeUpdate.bind(this));
      this.audioPlayer.removeEventListener('loadedmetadata', this.onLoadedMetadata.bind(this));
      this.audioPlayer.removeEventListener('ended', this.onEnded.bind(this));
      this.audioPlayer.removeEventListener('play', this.onPlayPause.bind(this));
      this.audioPlayer.removeEventListener('pause', this.onPlayPause.bind(this));
    }
  }

  initializePlayer(): void {
    if (this.isPlayerInitialized || !this.audioPlayer) {
      return;
    }
    this.audioPlayer.addEventListener('timeupdate', this.onTimeUpdate.bind(this));
    this.audioPlayer.addEventListener('loadedmetadata', this.onLoadedMetadata.bind(this));
    this.audioPlayer.addEventListener('ended', this.onEnded.bind(this));
    this.audioPlayer.addEventListener('play', this.onPlayPause.bind(this));
    this.audioPlayer.addEventListener('pause', this.onPlayPause.bind(this));
    this.isPlayerInitialized = true;
  }

  async loadRecordings(): Promise<void> {
    this.isLoading = true;
    this.errorMessage = null;
    try {
      const response = await this.campaignService.getCallsByCompany();
      this.companyName = response.companyName || 'Company';
      const calls = response.calls || [];
      this.recordings = calls.map((call: any) => ({
        id: call.id,
        dateTime: this.formatDateTime(call.startedAt),
        contactName: call.customerName || 'N/A',
        contactPhone: call.customerPhone || 'N/A',
        type: call.direction?.toLowerCase() === 'outbound' ? 'outbound' : 'inbound',
        agentName: call.agentName || 'AJAW AI',
        companyPhoneNumber: call.companyPhoneNumber || 'N/A',
        outcome: call.outcome || 'ANSWERED_NO_OUTCOME',
        duration: this.formatDuration(call.durationMs),
        recordingUrl: call.recordingUrl,
        transcription: call.transcription,
        summary: call.summary,
        calLink: call.calLink,
        campaignName: call.campaignName,
        appointmentDate: call.appointmentDate ? this.formatDateTime(call.appointmentDate) : undefined
      }));
      this.applyFiltersAndPagination();
    } catch (error) {
      console.error('Error loading recordings:', error);
      this.errorMessage = 'No se pudieron cargar las grabaciones de la company.';
      this.recordings = [];
      this.filteredRecordings = [];
    } finally {
      this.isLoading = false;
    }
  }

  applyFiltersAndPagination(): void {
    let tempRecordings = [...this.recordings];
    if (this.filterContact) {
      tempRecordings = tempRecordings.filter(rec =>
        rec.contactName.toLowerCase().includes(this.filterContact.toLowerCase()) ||
        rec.contactPhone.includes(this.filterContact)
      );
    }
    if (this.filterOutcome) {
      tempRecordings = tempRecordings.filter(rec => rec.outcome === this.filterOutcome);
    }
    if (this.filterType) {
      tempRecordings = tempRecordings.filter(rec => rec.type === this.filterType);
    }
    this.totalPages = Math.ceil(tempRecordings.length / this.itemsPerPage);
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    this.filteredRecordings = tempRecordings.slice(startIndex, this.itemsPerPage);
  }

  onFilterChange(): void {
    this.currentPage = 1; 
    this.applyFiltersAndPagination();
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.applyFiltersAndPagination();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.applyFiltersAndPagination();
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.applyFiltersAndPagination();
    }
  }

  openPanel(recording: Recording): void {
    this.selectedRecording = recording;
    this.isPanelOpen = true;
    this.activeTab = 'overview';
    setTimeout(() => {
      if (this.audioPlayer && this.selectedRecording?.recordingUrl) {
        this.audioPlayer.src = this.selectedRecording.recordingUrl;
        this.audioPlayer.load();
        this.generateWaveform();
      }
    }, 0);
  }

  closePanel(): void {
    this.isPanelOpen = false;
    this.selectedRecording = null;
    this.stopWaveformAnimation();
    if (this.audioPlayer) {
      this.audioPlayer.pause();
      this.audioPlayer.currentTime = 0;
      this.audioPlayer.src = '';
      this.isPlaying = false;
      this.currentTime = 0;
      this.duration = 0;
    }
  }

  async togglePlayPause() {
    if (!this.audioPlayer || !this.isPlayerInitialized) return;
    if (!this.audioPlayer.src) return;

    if (this.isPlaying) {
      this.audioPlayer.pause();
    } else {
      try {
        await this.audioPlayer.play();
      } catch (err) {
        console.error('Error playing audio:', err);
      }
    }
  }

  private onTimeUpdate(): void {
    this.ngZone.run(() => {
      this.currentTime = this.audioPlayer.currentTime;
    });
  }

  private onLoadedMetadata(): void {
    this.ngZone.run(() => {
      this.duration = this.audioPlayer.duration;
      this.drawWaveform(); // Draw once metadata is loaded
    });
  }

  private onEnded(): void {
    this.ngZone.run(() => {
      this.audioPlayer.currentTime = 0;
      this.drawWaveform();
    });
  }
  
  private onPlayPause(): void {
    this.ngZone.run(() => {
      this.isPlaying = !this.audioPlayer.paused;
      if (this.isPlaying) {
        this.startWaveformAnimation();
      } else {
        this.stopWaveformAnimation();
      }
    });
  }

  rewind(): void {
    if (this.audioPlayer) this.audioPlayer.currentTime = Math.max(0, this.audioPlayer.currentTime - 5);
  }

  forward(): void {
    if (this.audioPlayer) this.audioPlayer.currentTime = Math.min(this.duration, this.audioPlayer.currentTime + 5);
  }

  // --- Waveform Methods ---
  generateWaveform(): void {
    if (!this.waveformCanvasRef) return;
    const barCount = 100;
    this.waveformBars = [];
    for (let i = 0; i < barCount; i++) {
      this.waveformBars.push(Math.random() * 0.7 + 0.3);
    }
    this.drawWaveform();
  }

  drawWaveform(): void {
    if (!this.waveformCanvasRef) return;
    const canvas = this.waveformCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);
    
    const barCount = this.waveformBars.length;
    const barWidth = width / barCount;
    const centerY = height / 2;
    
    const playedColor = '#007bff';
    const unplayedColor = '#b0bec5';

    const progress = (this.duration > 0) ? (this.currentTime / this.duration) : 0;
    const playedBars = Math.floor(barCount * progress);

    this.waveformBars.forEach((heightVariation, i) => {
      const barHeight = (height * 0.6 * heightVariation);
      const x = i * barWidth;
      const y = centerY - barHeight / 2;
      
      ctx.fillStyle = i < playedBars ? playedColor : unplayedColor;
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    });
  }

  startWaveformAnimation(): void {
    if (this.animationFrameId) return;
    const animate = () => {
      this.drawWaveform();
      this.animationFrameId = requestAnimationFrame(animate);
    };
    this.animationFrameId = requestAnimationFrame(animate);
  }

  stopWaveformAnimation(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  // --- Helper & Display Methods ---
  private formatDuration(ms: number): string {
    if (isNaN(ms) || ms < 0) return '00:00';
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  private formatDateTime(isoString: string): string {
    if (!isoString) return 'N/A';
    try {
      const date = new Date(isoString);
      return new DatePipe('en-US').transform(date, 'dd/MM/yyyy, hh:mm a') || 'N/A';
    } catch (e) {
      return 'N/A';
    }
  }

  getOutcomeBadgeClass(outcome: CallOutcome): string {
    switch (outcome) {
      case 'APPOINTMENT_SET': return 'badge-success';
      case 'INTERESTED': return 'badge-primary';
      case 'CALLBACK_REQUESTED': return 'badge-info';
      case 'VOICEMAIL': return 'badge-info-light';
      case 'ANSWERED_NO_OUTCOME': return 'badge-secondary';
      case 'NO_ANSWER': return 'badge-warning';
      case 'BUSY': return 'badge-warning-light';
      case 'NOT_INTERESTED': return 'badge-danger';
      case 'DO_NOT_CALL': return 'badge-danger-dark';
      case 'WRONG_NUMBER': return 'badge-danger-light';
      case 'TECHNICAL_ERROR': return 'badge-danger-light';
      case 'CALL_DROPPED': return 'badge-danger-light';
      case 'LANGUAGE_NOT_SUPPORTED': return 'badge-warning';
      default: return 'badge-secondary';
    }
  }

  getOutcomeDisplayText(outcome: CallOutcome): string {
    return `outcomes.${outcome.toLowerCase()}`;
  }

  setActiveTab(tabName: string): void {
    this.activeTab = tabName;
  }

  copyToClipboard(text: string): void {
    navigator.clipboard.writeText(text).then(() => {
      console.log('ID copiado!');
    });
  }

  downloadAudio(): void {
    console.log('downloadAudio triggered');
  }

  rateConversation(rating: 'up' | 'down'): void {
    console.log(`rateConversation triggered with: ${rating}`);
  }
}

