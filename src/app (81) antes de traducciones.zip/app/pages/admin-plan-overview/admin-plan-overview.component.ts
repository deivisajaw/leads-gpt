import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-plan-overview',
  standalone: true,
  imports: [],
  templateUrl: './admin-plan-overview.component.html',
  styleUrl: './admin-plan-overview.component.css'
})
export class AdminPlanOverviewComponent {

}
