import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-qr-code-modal',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './qr-code-modal.component.html',
    styleUrls: ['./qr-code-modal.component.css']
})
export class QrCodeModalComponent {
    @Input() showModal = false;
    @Input() imageUrl = '';
    @Input() message = 'Escanea este código QR con tu WhatsApp para enlazar la cuenta.';
    @Output() close = new EventEmitter<void>();

    closeModal() {
        this.close.emit();
    }
}