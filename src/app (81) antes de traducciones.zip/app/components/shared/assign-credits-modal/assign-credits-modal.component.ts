import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { CompanyMember } from '../../../services/company-data.service'; 

@Component({
  selector: 'app-assign-credits-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule],
  templateUrl: './assign-credits-modal.component.html',
  styleUrls: ['./assign-credits-modal.component.css']
})
export class AssignCreditsModalComponent {
  @Input() showModal: boolean = false;
  @Input() member: CompanyMember | null = null; // For single user assignment
  @Input() memberCount: number = 0; // For bulk assignment
  @Input() maxCredits: number = 0; // Max credits available from company
  @Input() initialCredits: number = 0; // AÑADIDO: Para pre-llenar el input
  @Input() titleKey: string = ''; // AÑADIDO: Clave de traducción para el título
  @Input() messageKey: string = ''; // AÑADIDO: Clave de traducción para el mensaje
  @Output() close = new EventEmitter<void>();
  @Output() assign = new EventEmitter<number>();

  creditsToAssign: number = 0;
  errorMessage: string | null = null;
  isLoading: boolean = false;

  constructor() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['maxCredits']) {
    }
    
    if (changes['showModal'] && changes['showModal'].currentValue === true) {
      this.creditsToAssign = this.initialCredits; // Solo al abrir el modal
      this.errorMessage = null; // Limpiar errores al abrir
    } else if (changes['initialCredits']) {
      this.creditsToAssign = changes['initialCredits'].currentValue; // Si initialCredits cambia mientras está abierto
    }
  }

  onAssign(): void {
    this.errorMessage = null; // Clear previous errors
    
    if (this.creditsToAssign === null || isNaN(this.creditsToAssign)) {
      this.errorMessage = 'Por favor, introduce una cantidad válida de créditos.'; // TODO: Translate
      return;
    }

    if (!Number.isInteger(this.creditsToAssign)) {
      this.errorMessage = 'La cantidad de créditos debe ser un número entero.'; // TODO: Translate
      return;
    }

    if (this.creditsToAssign <= 0) {
      this.errorMessage = 'La cantidad de créditos debe ser mayor que cero.'; // TODO: Translate
      return;
    }

    if (this.creditsToAssign > this.maxCredits) {
      this.errorMessage = `No puedes asignar más créditos de los disponibles en la compañía (${this.maxCredits}).`; // TODO: Translate
      return;
    }

    this.assign.emit(this.creditsToAssign);
  }

  onClose(): void {
    this.creditsToAssign = 0; // Reset input on close
    this.errorMessage = null; // Clear error on close
    this.isLoading = false; // Reset loading on close
    this.close.emit();
  }

  // Method to set loading state from parent
  setLoading(loading: boolean): void {
    this.isLoading = loading;
  }

  // Method to set error message from parent
  setErrorMessage(message: string | null): void {
    this.errorMessage = message;
  }
}
