import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { CompanyDataService } from '../../../services/company-data.service';
import { LoadingModalComponent } from '../loading-modal/loading-modal.component'; // Import LoadingModalComponent

@Component({
  selector: 'app-edit-company-info-modal',
  standalone: true,
  imports: [CommonModule, TranslateModule, ReactiveFormsModule, LoadingModalComponent],
  templateUrl: './edit-company-info-modal.component.html',
  styleUrls: ['./edit-company-info-modal.component.css']
})
export class EditCompanyInfoModalComponent implements OnInit {
  @Input() showModal: boolean = false;
  @Input() companyId: number | null = null;
  @Input() currentCompanyName: string = '';
  @Input() currentCreditDistributionMode: string = '';
  @Input() currentMinCreditsGuaranteed: number | null | undefined = undefined; // New Input

  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<any>(); // Emits updated company data

  companyForm!: FormGroup;
  creditDistributionModes: string[] = ['MANUAL', 'AUTO_EQUITABLE', 'AUTO_RULE_BASED'];
  errorMessage: string | null = null;
  isLoading: boolean = false;

  constructor(private companyDataService: CompanyDataService) {}

  ngOnInit(): void {
    this.companyForm = new FormGroup({
      companyName: new FormControl(this.currentCompanyName, Validators.required),
      creditDistributionMode: new FormControl(this.currentCreditDistributionMode, Validators.required),
      minCreditsGuaranteed: new FormControl(this.currentMinCreditsGuaranteed, [Validators.min(0)]) // Removed Validators.required here
    });

    // Subscribe to changes in creditDistributionMode to apply conditional validation
    this.companyForm.get('creditDistributionMode')?.valueChanges.subscribe(mode => {
      this.updateMinCreditsGuaranteedValidation(mode);
    });

    // Set initial validation state
    this.updateMinCreditsGuaranteedValidation(this.currentCreditDistributionMode);
  }

  // Update form values if inputs change after initialization (e.g., modal reused)
  ngOnChanges(): void {
    if (this.companyForm) {
      this.companyForm.patchValue({
        companyName: this.currentCompanyName,
        creditDistributionMode: this.currentCreditDistributionMode,
        minCreditsGuaranteed: this.currentMinCreditsGuaranteed // Patch new value
      });
      // Re-apply validation based on potentially new currentCreditDistributionMode
      this.updateMinCreditsGuaranteedValidation(this.currentCreditDistributionMode);
    }
  }

  private updateMinCreditsGuaranteedValidation(mode: string): void {
    const minCreditsControl = this.companyForm.get('minCreditsGuaranteed');
    if (minCreditsControl) {
      if (mode === 'AUTO_RULE_BASED') {
        minCreditsControl.setValidators([Validators.required, Validators.min(0)]);
        minCreditsControl.enable(); // Ensure it's enabled for input
      } else {
        minCreditsControl.clearValidators();
        minCreditsControl.disable(); // Disable the control
        minCreditsControl.setValue(0); // Set to 0 or null when not required
      }
      minCreditsControl.updateValueAndValidity();
    }
  }

  async onSave(): Promise<void> {
    this.errorMessage = null;
    if (this.companyForm.invalid) {
      this.errorMessage = 'Please fill in all required fields.'; // TODO: Translate this
      return;
    }

    if (this.companyId === null) {
      this.errorMessage = 'Company ID is missing.'; // TODO: Translate this
      return;
    }

    this.isLoading = true;
    try {
      const formValue = this.companyForm.getRawValue();
      // Defensively ensure minCreditsGuaranteed is a number, defaulting to 0 if null/undefined.
      const minCredits = formValue.minCreditsGuaranteed ?? 0;

      const updatedCompanyData = await this.companyDataService.updateCompanyData(
        this.companyId,
        formValue.companyName,
        formValue.creditDistributionMode,
        minCredits // Send the guaranteed number
      );

      this.save.emit(updatedCompanyData); // Emit the updated data
      this.close.emit(); // Close modal on success
    } catch (error: any) {
      // Asignar el mensaje de error que viene del backend para ser mostrado en el HTML.
      this.errorMessage = error.message || 'An unexpected error occurred during save.'; // TODO: Translate this
    } finally {
      this.isLoading = false;
    }
  }

  onClose(): void {
    this.close.emit();
    this.errorMessage = null; // Clear error on close
    this.companyForm.reset(); // Reset form on close
  }
}