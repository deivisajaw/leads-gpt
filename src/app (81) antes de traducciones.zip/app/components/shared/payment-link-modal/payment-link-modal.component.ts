import { Component, Input, Output, EventEmitter } from '@angular/core'; // Añadir Input y Output
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-payment-link-modal',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  templateUrl: './payment-link-modal.component.html',
  styleUrls: ['./payment-link-modal.component.css']
})
export class PaymentLinkModalComponent {

  @Input() paymentUrl: string = ''; // Input para recibir el enlace
  @Output() close = new EventEmitter<void>(); // Output para emitir el evento de cierre

  constructor() {}

  openPaymentLink(): void {
        window.open(this.paymentUrl, '_blank');
        this.close.emit(); // Emit close event
      }

      closeModal(): void {
        this.close.emit(); // Emit close event
      }
    }
