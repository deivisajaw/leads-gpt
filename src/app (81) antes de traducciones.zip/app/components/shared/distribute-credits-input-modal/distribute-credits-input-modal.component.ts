import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-distribute-credits-input-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule],
  templateUrl: './distribute-credits-input-modal.component.html',
  styleUrls: ['./distribute-credits-input-modal.component.css']
})
export class DistributeCreditsInputModalComponent implements OnChanges {
  @Input() showModal = false;
  @Input() maxCredits = 0;
  @Input() distributionMode: 'equitable' | 'rule-based' = 'equitable';
  @Input() serverError: string | null = null;
  @Input() isLoading = false; // Now an Input
  @Output() close = new EventEmitter<void>();
  @Output() distribute = new EventEmitter<number>();

  creditsToDistribute: number = 0;
  errorMessage: string | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['serverError'] && changes['serverError'].currentValue) {
      this.errorMessage = this.serverError;
    }
    // Reset component state when it's opened
    if (changes['showModal'] && changes['showModal'].currentValue === true) {
      this.creditsToDistribute = this.maxCredits;
      this.errorMessage = null; 
    }
  }

  onDistribute(): void {
    this.errorMessage = null;
    if (this.creditsToDistribute <= 0) {
      this.errorMessage = 'Amount must be greater than 0.'; // TODO: Translate
      return;
    }
    if (this.creditsToDistribute > this.maxCredits) {
      this.errorMessage = `Amount cannot exceed available credits (${this.maxCredits}).`; // TODO: Translate
      return;
    }
    // No longer sets isLoading here. Emits event for parent to handle.
    this.distribute.emit(this.creditsToDistribute);
  }

  onClose(): void {
    this.close.emit();
  }
}

