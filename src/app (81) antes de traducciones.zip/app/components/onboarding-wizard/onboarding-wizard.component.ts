import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OnboardingQuestion } from '../../services/auth.service';

interface Answer {
  answerText: string | null;
  selectedOption: number | null;
  selectedOptions: number[];
}

@Component({
  selector: 'app-onboarding-wizard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './onboarding-wizard.component.html',
  styleUrls: ['./onboarding-wizard.component.css']
})
export class OnboardingWizardComponent implements OnInit, OnChanges {

  @Input() questions: OnboardingQuestion[] = [];
  @Output() completed = new EventEmitter<any[]>();

  currentStep = 0;
  answers: { [questionId: number]: Answer } = {};

  constructor() { }

  ngOnInit(): void {
    this.initializeAnswers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['questions'] && changes['questions'].currentValue) {
      this.initializeAnswers();
    }
  }

  initializeAnswers(): void {
    this.answers = {};
    this.questions.forEach(q => {
      this.ensureAnswerObject(q.id);
    });
  }

  ensureAnswerObject(questionId: number): void {
    if (!this.answers[questionId]) {
      this.answers[questionId] = {
        answerText: null,
        selectedOption: null,
        selectedOptions: []
      };
    }
  }

  selectOption(questionId: number, optionId: number): void {
    this.ensureAnswerObject(questionId);
    const questionType = this.questions.find(q => q.id === questionId)?.questionType;

    if (questionType === 'SINGLE_SELECT') {
      this.answers[questionId].selectedOption = optionId;
    } else if (questionType === 'MULTI_SELECT') {
      const selectedOptions = this.answers[questionId].selectedOptions;
      const index = selectedOptions.indexOf(optionId);
      if (index > -1) {
        selectedOptions.splice(index, 1); // Unselect
      } else {
        selectedOptions.push(optionId); // Select
      }
    }
  }

  selectBooleanOption(questionId: number, value: 'true' | 'false'): void {
    this.ensureAnswerObject(questionId);
    this.answers[questionId].answerText = value;
  }

  isOptionSelected(questionId: number, optionId: number): boolean {
    return this.answers[questionId]?.selectedOptions.includes(optionId) || false;
  }

  isCurrentStepValid(): boolean {
    if (!this.questions || this.questions.length === 0) {
      return false;
    }
    const currentQuestion = this.questions[this.currentStep];
    const currentAnswer = this.answers[currentQuestion.id];

    if (!currentAnswer) {
      return false;
    }

    switch (currentQuestion.questionType) {
      case 'TEXT':
      case 'DATE':
      case 'NUMBER_INTEGER':
      case 'NUMBER_DECIMAL':
        return currentAnswer.answerText !== null && currentAnswer.answerText.trim() !== '';
      case 'BOOLEAN':
        return currentAnswer.answerText !== null; // 'true' or 'false'
      case 'SINGLE_SELECT':
        return currentAnswer.selectedOption !== null;
      case 'MULTI_SELECT':
        return currentAnswer.selectedOptions.length > 0;
      default:
        return false;
    }
  }

  nextStep(): void {
    if (!this.isCurrentStepValid()) return;
    if (this.currentStep < this.questions.length - 1) {
      this.currentStep++;
    }
  }

  previousStep(): void {
    if (this.currentStep > 0) {
      this.currentStep--;
    }
  }

  finish(): void {
    if (!this.isCurrentStepValid()) return;

    const formattedAnswers = Object.keys(this.answers).map(questionIdStr => {
      const questionId = parseInt(questionIdStr, 10);
      const answer = this.answers[questionId];
      return {
        id: questionId,
        selectedOption: answer.selectedOption,
        answerText: answer.answerText,
        selectedOptions: answer.selectedOptions
      };
    });
    
    console.log('Wizard finished. Emitting answers:', formattedAnswers);
    this.completed.emit(formattedAnswers);
  }
}
