
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Deal, DealNote } from '../../services/deals.service';
import { DealsService } from '../../services/deals.service';
import { NotificationService } from '../../services/notification.service'; // Importar NotificationService

@Component({
  selector: 'app-deal-detail-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './deal-detail-modal.component.html',
  styleUrls: ['./deal-detail-modal.component.css'],
})
export class DealDetailModalComponent {
  @Input() deal: Deal | null = null;
  @Output() closeModal = new EventEmitter<void>();

  noteForm: FormGroup;
  isSubmitting = false;

  constructor(private fb: FormBuilder, private dealsService: DealsService, private notificationService: NotificationService) { // Inyectar NotificationService
    this.noteForm = this.fb.group({
      noteText: ['', Validators.required],
    });
  }

  onClose() {
    this.closeModal.emit();
  }

  addNote() {
    if (this.noteForm.invalid || !this.deal) {
      return;
    }

    this.isSubmitting = true;
    const noteText = this.noteForm.value.noteText;

    this.dealsService.addNote(this.deal.id, noteText).subscribe({
      next: (newNote) => {
        if (newNote && this.deal) {
          this.deal.notes.unshift(newNote); // Añadir la nueva nota al principio de la lista
          this.notificationService.showSuccess('Nota añadida correctamente.');
        }
        this.noteForm.reset();
        this.isSubmitting = false;
      },
      error: (err) => {
        this.isSubmitting = false;
        console.error('Error al añadir la nota:', err);
        this.notificationService.showError('Error al añadir la nota: ' + (err.message || ''));
      },
    });
  }
}
