import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { Observable, map, Subscription, filter } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';
import { OnboardingStepStatus } from '../../models/user-profile.model';

@Component({
  selector: 'app-onboarding-widget',
  standalone: true,
  imports: [CommonModule, RouterModule, TranslateModule],
  templateUrl: './onboarding-widget.component.html',
  styleUrls: ['./onboarding-widget.component.css']
})
export class OnboardingWidgetComponent implements OnInit, OnDestroy {

  @ViewChild('stepsContainer') stepsContainerRef!: ElementRef;

  public onboardingStatus$: Observable<OnboardingStepStatus[] | undefined>;
  public progress$: Observable<number>;
  public allStepsCompleted$: Observable<boolean>;

  public currentSlideIndex: number = 0;
  public isPlaying: boolean = true;
  private carouselInterval: any;
  private stepsSubscription!: Subscription;
  public steps: OnboardingStepStatus[] = []; 

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService
  ) {
    this.onboardingStatus$ = this.authService.userProfile$.pipe(
      map(profile => profile?.onboardingStatus ?? [])
    );

    this.progress$ = this.authService.userProfile$.pipe(
      map(profile => {
        const steps = profile?.onboardingStatus;
        if (!steps || steps.length === 0) return 0;
        const completedSteps = steps.filter(step => step.isCompleted).length;
        return Math.round((completedSteps / steps.length) * 100);
      })
    );

    this.allStepsCompleted$ = this.authService.userProfile$.pipe(
      map(profile => {
        const steps = profile?.onboardingStatus;
        return steps ? steps.length > 0 && steps.every(step => step.isCompleted) : false;
      })
    );
  }

  ngOnInit(): void {
    this.stepsSubscription = this.onboardingStatus$
      .pipe(filter(steps => !!steps && steps.length > 0)) // Solo iniciar si hay pasos incompletos
      .subscribe(steps => {
        this.steps = steps as OnboardingStepStatus[];
        this.currentSlideIndex = 0; // Reiniciar al primer slide cuando los pasos cambian
        this.startCarousel();
      });
  }

  ngOnDestroy(): void {
    this.stopCarousel();
    if (this.stepsSubscription) {
      this.stepsSubscription.unsubscribe();
    }
  }

  startCarousel(): void {
    this.stopCarousel(); // Limpiar cualquier intervalo existente
    // Auto-play si hay más pasos que los que caben en la vista actual
    if (this.steps.length > this.getVisibleCardsCount() && this.isPlaying) {
      this.carouselInterval = setInterval(() => {
        this.nextSlide();
      }, 5000); // Cambiar slide cada 5 segundos
    }
  }

  stopCarousel(): void {
    if (this.carouselInterval) {
      clearInterval(this.carouselInterval);
      this.carouselInterval = null;
    }
  }

  togglePlayPause(): void {
    this.isPlaying = !this.isPlaying;
    if (this.isPlaying) {
      this.startCarousel();
    } else {
      this.stopCarousel();
    }
  }

  nextSlide(): void {
    if (this.steps.length === 0 || !this.stepsContainerRef) return;

    const container = this.stepsContainerRef.nativeElement;
    const firstCard = container.querySelector('.step-card');
    if (!firstCard) return;

    const cardWidth = firstCard.offsetWidth; // Ancho real de una tarjeta
    const gap = 15; // Definido en CSS
    const scrollAmount = cardWidth + gap;

    // Calcular el máximo scroll posible para evitar scroll excesivo
    const maxScrollLeft = container.scrollWidth - container.clientWidth;
    const tolerance = 2; // Tolerancia para posibles decimales en los cálculos de ancho

    // Si ya estamos al final del recorrido (o muy cerca), volvemos al principio.
    if (container.scrollLeft >= maxScrollLeft - tolerance) {
      container.scrollTo({ left: 0, behavior: 'smooth' });
      this.currentSlideIndex = 0;
    } else {
      // De lo contrario, simplemente avanzamos. El scroll-snap se encargará del ajuste.
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      this.currentSlideIndex++;
    }

    if (this.isPlaying) { // Reiniciar intervalo en navegación manual si está en reproducción
      this.startCarousel();
    }
  }

  prevSlide(): void {
    if (this.steps.length === 0 || !this.stepsContainerRef) return;

    const container = this.stepsContainerRef.nativeElement;
    const firstCard = container.querySelector('.step-card');
    if (!firstCard) return;

    const cardWidth = firstCard.offsetWidth; // Ancho real de una tarjeta
    const gap = 15; // Definido en CSS
    const scrollAmount = cardWidth + gap;

    if (container.scrollLeft - scrollAmount <= 0) {
      // Si estamos cerca del principio, ir al final
      container.scrollTo({ left: container.scrollWidth, behavior: 'smooth' });
      this.currentSlideIndex = this.steps.length - 1; // Esto es aproximado, el scroll-snap lo ajustará
    } else {
      container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      this.currentSlideIndex--;
    }

    if (this.isPlaying) { // Reiniciar intervalo en navegación manual si está en reproducción
      this.startCarousel();
    }
  }

  // Helper para determinar cuántas tarjetas son visibles según el tamaño de la pantalla
  getVisibleCardsCount(): number {
    const width = window.innerWidth;
    if (width >= 1200) return 4;
    if (width >= 992) return 3;
    if (width >= 768) return 2;
    return 1; // Móvil
  }

  navigateToStep(step: OnboardingStepStatus): void {
    if (step.actionRoute) {
      this.router.navigate([step.actionRoute]);
    } else {
      this.notificationService.showInfo('This step does not have a specific action route.');
    }
  }
}