import {
  Component,
  OnInit,
  OnDestroy,
  NgZone,
  ElementRef,
  Renderer2,
  HostListener,
  ChangeDetectorRef,
  ViewChild,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { Subject } from 'rxjs';
import { filter, takeUntil, take } from 'rxjs/operators';
import { AuthService } from '../../services/auth.service';
import { AsideEventsService } from '../../services/aside-events.service';
import { UserProfile } from '../../models/user-profile.model';

interface OnboardingStep {
  stepKey: string;
  isCompleted: boolean;
  completedAt?: Date;
}

interface OnboardingStepConfig {
  overlay: {
    elementSelector: string;
    message: string;
    tooltipPosition: 'right' | 'left' | 'top' | 'bottom';
    parentSelector?: string;
    parentMessage?: string;
    tooltipOffsetY?: number; 
  };
  inPage: {
    message: string;
  };
  actionRoute: string;
}

@Component({
  selector: 'app-onboarding-guide',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './onboarding-guide.component.html',
  styleUrls: ['./onboarding-guide.component.css'],
})
export class OnboardingGuideComponent implements OnInit, OnDestroy {
 
  @ViewChild('overlayTooltip') overlayTooltipRef!: ElementRef<HTMLDivElement>;
  @ViewChild('inPageTooltip') inPageTooltipRef!: ElementRef<HTMLDivElement>;

  showOverlay = false;
  showInPageTooltip = false;

  overlayTooltipMessage = '';
  inPageTooltipMessage = '';
  styleOverlayTooltip: any = {};
  styleInPageTooltip: any = {};
  styleOverlayArrow: any = {};
  styleInPageArrow: any = {};

  styleTop: any = {};
  styleBottom: any = {};
  styleLeft: any = {};
  styleRight: any = {};

  private destroy$ = new Subject<void>();
  private stepConfigs = new Map<string, OnboardingStepConfig>();
  private currentStep: OnboardingStep | null = null;
  private targetElement: HTMLElement | null = null;
  private originalTargetStyles: { zIndex: string; pointerEvents: string; position: string; } | null = null;

  constructor(
    private authService: AuthService,
    private router: Router,
    private ngZone: NgZone,
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef,
    private asideEventsService: AsideEventsService
  ) {}

  ngOnInit(): void {
    this.initializeStepConfigs();

    this.authService.userProfile$
      .pipe(takeUntil(this.destroy$))
      .subscribe((profile) => {
        if (profile) {
          this.evaluateOnboardingState(profile);
        }
      });

    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        if (this.authService.currentUserProfile) {
          this.evaluateOnboardingState(this.authService.currentUserProfile);
        }
      });

    this.asideEventsService.submenuToggled$
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        if (this.authService.currentUserProfile) {
          this.evaluateOnboardingState(this.authService.currentUserProfile);
        }
      });
  }

  private initializeStepConfigs(): void {
    this.stepConfigs.set('CONFIGURE_PROFILE', {
      overlay: {
        elementSelector: '[data-stepKey="CONFIGURE_PROFILE"]',
        message: '¡Bienvenido! Configura tu perfil para empezar. Haz clic aquí.',
        tooltipPosition: 'right',
        tooltipOffsetY: -100,
      },
      inPage: {
        message: 'Ahora, guarda tus cambios para completar este paso. El botón "Guardar" se encuentra al final de la página.',
      },
      actionRoute: '/userconfig',
    });
    
    this.stepConfigs.set('ASSIGN_CREDITS', {
      overlay: {
        elementSelector: '[data-stepKey="ASSIGN_CREDITS"]', 
        message: 'Asigna créditos a tus usuarios para que puedan empezar a usar el sistema.',
        tooltipPosition: 'right',
        parentSelector: '[data-stepKey="OPEN_SUBSCRIPTION_SETTINGS"]', 
        parentMessage: 'Haz clic aquí para abrir la configuración de suscripción.', 
        tooltipOffsetY: -10, 
      },
      inPage: {
        message: 'Selecciona un usuario, asigna los créditos y guarda los cambios. El botón "Guardar" se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/admin-users',
    });
    
    this.stepConfigs.set('FIND_LEADS-SAVE_LEAD', {
      overlay: {
        elementSelector: '[data-stepKey="FIND_LEADS-SAVE_LEAD"]', 
        message: 'El siguiente paso es encontrar y guardar prospectos. Haz clic aquí para ir a la página de búsqueda.',
        tooltipPosition: 'right',
        tooltipOffsetY: -15, 
      },
      inPage: { 
        message: 'Navega a la página de prospectos.',
      },
      actionRoute: '/people',
    });

    this.stepConfigs.set('FIND_LEADS', {
      overlay: { 
        elementSelector: '[data-stepKey="FIND_LEADS-SAVE_LEAD"]', 
        message: 'El siguiente paso es encontrar prospectos. Haz clic aquí para ir a la página de búsqueda.',
        tooltipPosition: 'right',
        tooltipOffsetY: 45,
      },
      inPage: {
        message: 'Usa los filtros para buscar prospectos. El botón para buscar se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/people',
    });

    this.stepConfigs.set('SAVE_LEAD', {
      overlay: { 
        elementSelector: '[data-stepKey="FIND_LEADS-SAVE_LEAD"]', 
        message: 'Ya has encontrado prospectos. Ahora, haz clic aquí para ir a la página y guardar uno.',
        tooltipPosition: 'right',
        tooltipOffsetY: 45, 
      },
      inPage: {
        message: 'Guarda el prospecto seleccionado. El botón para guardar se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/people',
    });
     this.stepConfigs.set('CREATE_CAMPAIGN', {
      overlay: {
        elementSelector: '[data-stepKey="CREATE_CAMPAIGN"]',
        message: 'Crea tu primera campaña de llamadas desde aquí.',
        tooltipPosition: 'right',
        tooltipOffsetY: -15, 
      },
      inPage: {
        message: 'Define los detalles de tu campaña y guárdala. El botón "Guardar" se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/campaigns/new',
    });
    this.stepConfigs.set('REQUEST_PHONE_NUMBER', {
      overlay: {
        elementSelector: '[data-stepKey="REQUEST_PHONE_NUMBER"]',
        message: 'Necesitas un número de teléfono para hacer llamadas. Consigue uno aquí.',
        tooltipPosition: 'right',
        tooltipOffsetY: -15, 
      },
      inPage: {
        message: 'Busca y selecciona un número de la lista de disponibles. El botón para buscar y seleccionar se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/phone-numbers',
    });
     this.stepConfigs.set('CREATE_AGENT', {
      overlay: {
        elementSelector: '[data-stepKey="CREATE_AGENT"]',
        message: 'Los agentes de IA realizarán las llamadas. Crea tu primer agente.',
        tooltipPosition: 'right',
        tooltipOffsetY: -15,
      },
      inPage: {
        message: 'Configura la personalidad y el objetivo de tu agente, y luego guárdalo. El botón "Guardar" se encuentra en la parte inferior de la página.',
      },
      actionRoute: '/agents/new',
    });
  }

  private evaluateOnboardingState(profile: UserProfile): void {
    const incompleteStep = (profile.onboardingStatus ?? []).find(
      (step) => !step.isCompleted
    );
    this.currentStep = incompleteStep || null;

    if (!this.currentStep) {
      this.hideGuide();
      return;
    }

    let config: OnboardingStepConfig | undefined;
    let configForOverlay: OnboardingStepConfig | undefined;

    if (this.currentStep.stepKey === 'FIND_LEADS' || this.currentStep.stepKey === 'SAVE_LEAD') {
      config = this.stepConfigs.get(this.currentStep.stepKey);
      configForOverlay = this.stepConfigs.get('FIND_LEADS-SAVE_LEAD'); 
    } else {
      config = this.stepConfigs.get(this.currentStep.stepKey);
      configForOverlay = config; 
    }

    if (!config || !configForOverlay) {
      this.hideGuide();
      return;
    }

    const isOnActionRoute = this.router.url.startsWith(config.actionRoute);

    if (isOnActionRoute) {
      this.showInPageGuide(config); 
    } else {
      this.showOverlayGuide(configForOverlay); 
    }
  }

  private showOverlayGuide(config: OnboardingStepConfig): void {

  this.hideGuide();

  this.ngZone.onStable.pipe(take(1)).subscribe(() => {
    let targetElementToHighlight: HTMLElement | null = null;
    let messageToDisplay: string = config.overlay.message;
    let tooltipPosition: 'right' | 'left' | 'top' | 'bottom' = config.overlay.tooltipPosition;

    const actualTargetElement = document.querySelector<HTMLElement>(config.overlay.elementSelector);

    let isActualTargetAccessible = false;
    if (actualTargetElement) {
        const parentSubmenuLi = actualTargetElement.closest('.nav-item.has-submenu');
        if (parentSubmenuLi) {
            isActualTargetAccessible = parentSubmenuLi.classList.contains('open');
        } else {
            isActualTargetAccessible = true;
        }
    }

    if (isActualTargetAccessible) {
      targetElementToHighlight = actualTargetElement;
    } else if (config.overlay.parentSelector) {
      const parentElement = document.querySelector<HTMLElement>(config.overlay.parentSelector);
      if (parentElement) {
        targetElementToHighlight = parentElement;
        messageToDisplay = config.overlay.parentMessage || config.overlay.message;
      }
    }

    if (targetElementToHighlight) {
      this.targetElement = targetElementToHighlight;
      this.overlayTooltipMessage = messageToDisplay;
      this.cdr.detectChanges(); 

      setTimeout(() => {
        if (this.targetElement) {
          const currentTooltipOffsetY = config.overlay.tooltipOffsetY || 0; 
          this.calculateOverlayPositions(this.targetElement, tooltipPosition, currentTooltipOffsetY); 
          this.showOverlay = true;
          this.cdr.detectChanges(); 
        }
      }, 50); 
    } else {
      this.hideGuide();
    }
  });
}

  private showInPageGuide(config: OnboardingStepConfig): void {
    this.hideGuide();
    this.inPageTooltipMessage = config.inPage.message;
    this.styleInPageTooltip = {
      position: 'fixed',
      bottom: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      opacity: 1,
    };
    this.styleInPageArrow = { display: 'none' };
    this.showInPageTooltip = true;
    this.cdr.detectChanges();
  }

  private calculateOverlayPositions(target: HTMLElement, tooltipPosition: string, tooltipOffsetY: number = 0): void {
  
    this.ngZone.onStable.pipe(take(1)).subscribe(() => {
      requestAnimationFrame(() => {
        const rect = target.getBoundingClientRect();

        this.styleTop = { top: '0', left: '0', width: '100vw', height: `${rect.top}px` };
        this.styleBottom = { top: `${rect.bottom}px`, left: '0', width: '100vw', height: `calc(100vh - ${rect.bottom}px)` };
        this.styleLeft = { top: `${rect.top}px`, left: '0', width: `${rect.left}px`, height: `${rect.height}px` };
        this.styleRight = { top: `${rect.top}px`, left: `${rect.right}px`, width: `calc(100vw - ${rect.right}px)`, height: `${rect.height}px` };

        if (!this.overlayTooltipRef) return;
        const tooltipRect = this.overlayTooltipRef.nativeElement.getBoundingClientRect();
        const gap = 15;
        const arrowSize = 12;
        let tooltipTop = 0, tooltipLeft = 0;

        if (tooltipPosition === 'right') {
            tooltipLeft = rect.right + gap;
            tooltipTop = rect.top + rect.height / 2 - tooltipRect.height / 2 + 45 + tooltipOffsetY; 
            this.styleOverlayArrow = { top: '50%', left: `-${arrowSize / 2}px`, transform: 'translateY(-50%) rotate(45deg)' };
        }
        this.styleOverlayTooltip = { top: `${tooltipTop}px`, left: `${tooltipLeft}px`, opacity: 1 };
        this.cdr.detectChanges();
      });
    });
  }

  private hideGuide(): void {
    if (this.targetElement && this.originalTargetStyles) {
      this.renderer.setStyle(this.targetElement, 'z-index', this.originalTargetStyles.zIndex);
      this.renderer.setStyle(this.targetElement, 'pointer-events', this.originalTargetStyles.pointerEvents);
      this.renderer.setStyle(this.targetElement, 'position', this.originalTargetStyles.position);
      this.targetElement = null;
      this.originalTargetStyles = null;
    }
    if (this.showOverlay || this.showInPageTooltip) {
      this.showOverlay = false;
      this.showInPageTooltip = false;
      this.styleOverlayTooltip = {};
      this.styleInPageTooltip = {};
      this.styleOverlayArrow = {};
      this.styleInPageArrow = {};
      this.cdr.detectChanges();
    }
  }

  @HostListener('window:resize')
  onResize(): void {
    if (this.showOverlay && this.targetElement && this.currentStep) {
      const config = this.stepConfigs.get(this.currentStep.stepKey);
      if (config) {
        this.calculateOverlayPositions(this.targetElement, config.overlay.tooltipPosition);
      }
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.hideGuide();
  }
}