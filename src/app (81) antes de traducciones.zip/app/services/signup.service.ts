import { Injectable } from '@angular/core';
import { ApiConfigService } from './api-config.service';
import { SignupPayload, SignupResponse } from '../models/signup.model';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private apiConfig: ApiConfigService) { }

  async register(payload: SignupPayload): Promise<SignupResponse> {
    const response = await fetch(this.apiConfig.signupUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'signupauth': 'UIh-9k88vY57L>f=7hF<'
      },
      body: JSON.stringify(payload)
    });

    const responseData: SignupResponse = await response.json();
    
    if (!response.ok) {
      throw new Error(responseData.error || 'An unknown error occurred during signup.');
    }

    return responseData;
  }
}
