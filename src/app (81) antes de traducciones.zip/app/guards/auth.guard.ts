import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // El guardián ahora solo necesita llamar a este método.
  // La lógica compleja está centralizada en el servicio.
  return authService.ensureProfileLoaded().then(isAuthenticated => {
    if (isAuthenticated) {
      return true; // Si está autenticado, permite el acceso.
    } else {
      // Si no, redirige a login.
      router.navigate(['/login']);
      return false;
    }
  });
};
