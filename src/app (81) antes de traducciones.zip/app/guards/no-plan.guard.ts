import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { map } from 'rxjs/operators';

export const noPlanGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  return authService.userProfile$.pipe(
    map(userProfile => {
      const hasSubscription = !!userProfile?.companyProfile?.subscription;
      if (!hasSubscription) {
        // User does NOT have a subscription, allow access to redeem code page
        return true;
      } else {
        // User HAS a subscription, redirect to dashboard or plans page
        return router.createUrlTree(['/dashboard']); // Or '/plans' if you want them to manage existing plan
      }
    })
  );
};