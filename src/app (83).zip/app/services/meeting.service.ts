import { Injectable } from '@angular/core';
import { AgentService } from './agent.service';

export interface CalBooking {
  id: number;
  uid: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  status: 'ACCEPTED' | 'PENDING' | 'CANCELLED' | 'REJECTED';
  location?: string;
  meetingUrl?: string;
  attendees: CalAttendee[];
  organizer: { name: string; email: string };
  agentId?: number;
  agentName?: string;
}

export interface CalAttendee {
  name: string;
  email: string;
  timeZone?: string;
}

export interface MeetingGroup {
  label: string;
  tag: 'today' | 'tomorrow' | 'upcoming';
  meetings: CalBooking[];
}

@Injectable({
  providedIn: 'root'
})
export class MeetingService {

  private readonly CAL_API_BASE = 'https://api.cal.com/v1';

  constructor(private agentService: AgentService) {}

  async getAllMeetings(): Promise<CalBooking[]> {
    const agents = await this.agentService.getAgents();
    const agentsWithToken = agents.filter(a => a.calToken);

    if (agentsWithToken.length === 0) return [];

    const allBookings: CalBooking[] = [];

    await Promise.all(
      agentsWithToken.map(async (agent) => {
        try {
          const bookings = await this.fetchBookingsForAgent(agent.calToken!, agent.id, agent.name);
          allBookings.push(...bookings);
        } catch (err) {
          console.error(`Error fetching bookings for agent "${agent.name}":`, err);
        }
      })
    );

    // Deduplicar por uid: si dos agentes tienen el mismo calToken traerán los mismos bookings
    const seen = new Set<string>();
    const unique = allBookings.filter(b => {
      if (seen.has(b.uid)) return false;
      seen.add(b.uid);
      return true;
    });

    unique.sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
    return unique;
  }

  private async fetchBookingsForAgent(
    calToken: string,
    agentId: number,
    agentName: string
  ): Promise<CalBooking[]> {
    const url = `${this.CAL_API_BASE}/bookings?apiKey=${calToken}&status=upcoming`;
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`Cal.com API error ${response.status} for agent "${agentName}"`);
    }

    const data = await response.json();
    const bookings: any[] = data.bookings || [];

    return bookings.map((b: any): CalBooking => {
      // Cal.com puede devolver la URL de la videollamada en varios lugares
      const meetingUrl =
        b.videoCallData?.url ||           // Google Meet / Zoom via integración
        b.metadata?.videoCallUrl ||        // Algunos tipos de evento lo ponen aquí
        (typeof b.location === 'string' && b.location.startsWith('http') ? b.location : undefined);

      // Deduplicar: si este booking ya existe (mismo uid) no lo agregamos
      return {
        id: b.id,
        uid: b.uid,
        title: b.title,
        description: b.description,
        startTime: b.startTime,
        endTime: b.endTime,
        status: b.status,
        // location como texto legible (presencial, Zoom sin URL, etc.)
        location: typeof b.location === 'string' ? b.location : undefined,
        meetingUrl,
        attendees: b.attendees || [],
        organizer: b.user || { name: agentName, email: '' },
        agentId,
        agentName
      };
    });
  }

  groupMeetings(meetings: CalBooking[]): MeetingGroup[] {
    const { todayStart, tomorrowStart, dayAfterTomorrow } = this.getDateBoundaries();
    const groups: MeetingGroup[] = [];

    const today    = meetings.filter(m => { const s = new Date(m.startTime); return s >= todayStart    && s < tomorrowStart;    });
    const tomorrow = meetings.filter(m => { const s = new Date(m.startTime); return s >= tomorrowStart && s < dayAfterTomorrow; });
    const upcoming = meetings.filter(m => new Date(m.startTime) >= dayAfterTomorrow);

    if (today.length)    groups.push({ label: 'Hoy',      tag: 'today',    meetings: today    });
    if (tomorrow.length) groups.push({ label: 'Mañana',   tag: 'tomorrow', meetings: tomorrow });
    if (upcoming.length) groups.push({ label: 'Próximas', tag: 'upcoming', meetings: upcoming });

    return groups;
  }

  getUpcomingMeetings(meetings: CalBooking[]): CalBooking[] {
    const { todayStart, dayAfterTomorrow } = this.getDateBoundaries();
    return meetings.filter(m => {
      const s = new Date(m.startTime);
      return s >= todayStart && s < dayAfterTomorrow;
    });
  }

  isHappeningNow(m: CalBooking): boolean {
    const now = Date.now();
    return new Date(m.startTime).getTime() <= now && now <= new Date(m.endTime).getTime();
  }

  isSoon(m: CalBooking): boolean {
    const mins = this.minutesUntil(m.startTime);
    return mins > 0 && mins <= 30;
  }

  minutesUntil(dateStr: string): number {
    return Math.round((new Date(dateStr).getTime() - Date.now()) / 60000);
  }

  getDuration(start: string, end: string): string {
    const diff = Math.round((new Date(end).getTime() - new Date(start).getTime()) / 60000);
    if (diff >= 60) {
      const h = Math.floor(diff / 60);
      const m = diff % 60;
      return m > 0 ? `${h}h ${m}min` : `${h}h`;
    }
    return `${diff} min`;
  }

  formatTime(dateStr: string): string {
    return new Date(dateStr).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true });
  }

  formatShortDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short' });
  }

  formatFullDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-CO', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  }

  private getDateBoundaries() {
    const now = new Date();
    const todayStart       = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrowStart    = new Date(todayStart); tomorrowStart.setDate(tomorrowStart.getDate() + 1);
    const dayAfterTomorrow = new Date(tomorrowStart); dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 1);
    return { todayStart, tomorrowStart, dayAfterTomorrow };
  }
}
