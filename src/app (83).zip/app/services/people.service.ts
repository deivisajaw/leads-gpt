import { Injectable } from "@angular/core"
import { ApiConfigService } from "./api-config.service"

export interface People {
  id: number
  name: string
  title: string
  link: string
  snippet: string
  image: string
  description: string
  searchResultStatusSelect: number
  fullName: string
  email: string
  phone: string
  education: string
  experiencies: string
  countryCode: string
  location: string
  about: string
  itemSelected: boolean
  // Campos adicionales para la vista
  avatar: string
  verified: boolean,
  jobTitle: string,
  company: string
}

export interface PeopleSearchResult {
  notFound: boolean
  searchString: string
  results: People[]
  searchId?: number
  statusSelect?: number
  resultsNumber?: number
  offset: number
  limit: number
  fetched: number
  sortBy?: string
  message?: string
  error?: boolean,
  creditsRemaining?: number
}

export interface PeopleSearchHistoryItem {
  id: number;
  searchString: string;
  statusSelect?: number;
  resultsNumber?: number;
  createdOn: string;
}

export interface PeopleSearchHistoryResponse {
  error: boolean;
  message?: string;
  history: PeopleSearchHistoryItem[];
  total: number;
  offset: number;
  limit: number;
  fetched: number;
  sortBy?: string;
}

export interface PeopleSearchResponse {
  status: 'SEARCH_NOT_FOUND' | 'SEARCH_IN_PROGRESS' | 'SUCCESS' | 'INSUFFICIENT_CREDITS' | 'UNAUTHORIZED' | 'INVALID_INPUT' | 'ERROR';
  message?: string;
  data?: PeopleSearchResult;
}

@Injectable({
  providedIn: "root",
})
export class PeopleService {

  constructor(private apiConfig: ApiConfigService) { }

  async runSearchPeople(query: string, offset = 0, limit = 25,
  sortBy = 'name_asc'): Promise<PeopleSearchResponse> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:runSearchPeople",
          data: {
            query: query,
            offset: offset,
            limit: limit,
            sortBy: sortBy,
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()

      return result.data as PeopleSearchResponse
    } catch (error) {
      console.error("Error in runSearchPeople:", error)
      return {
        status: 'ERROR',
        message: "Error calling API",
      } as PeopleSearchResponse
    }
  }

  async triggerExternalSearch(query: string): Promise<{ status: number; message: string }> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const userId = localStorage.getItem("userId")

      if (!userId) {
        throw new Error("No userId found")
      }

      console.log("Triggering external search for people:", query)

      const url = new URL(this.apiConfig.searchPeopleUrl);
      url.searchParams.append("sessionId", userId);
      url.searchParams.append("action", "sendMessage");
      url.searchParams.append("chatInput", query);

      const response = await fetch(url.toString(), {
        method: "GET",
        credentials: "omit",
        headers: {
          "AjawCompanyLeads": "oci=4^Br463sStYm"
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log("Webhook Response:", result);

      if (result?.status === 0 && result?.data?.[0]?.message === "in process") {
        return { status: 0, message: "in process" };
      }

      return {
        status: result.status || -1,
        message: result?.data?.[0]?.message || "Unexpected response"
      };
    } catch (error) {
      console.error("Error triggering webhook search:", error);
      return {
        status: -1,
        message: "Error triggering external search"
      };
    }
  }

  async getSearchStatus(searchId: number): Promise<{ status: string; progress?: number }> {
    try {
      const token = localStorage.getItem("csrfToken")

      if (!token) {
        throw new Error("No authentication token found")
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getSearchStatus",
          data: {
            searchId: searchId,
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()

      return {
        status: result.data?.status || "unknown",
        progress: result.data?.progress || 0,
      }
    } catch (error) {
      console.error("Error getting search status:", error)
      return {
        status: "error",
        progress: 0,
      }
    }
  }

  async getMySearchHistoryPeoples(offset = 0, limit = 25, sortBy = 'createdOn_desc'): Promise<PeopleSearchHistoryResponse> {
    try {
        const token = localStorage.getItem("csrfToken");
        if (!token) {
            throw new Error("No authentication token found");
        }

        const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-Token": token,
            },
            body: JSON.stringify({
                action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMySearchHistoryPeoples",
                data: {
                    offset: offset,
                    limit: limit,
                    sortBy: sortBy,
                },
            }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        return result.data as PeopleSearchHistoryResponse;
    } catch (error) {
        console.error("Error in getMySearchHistoryPeoples:", error);
        return {
            error: true,
            message: "Error calling API",
            history: [],
            total: 0,
            offset: offset,
            limit: limit,
            fetched: 0,
            sortBy: sortBy,
        } as PeopleSearchHistoryResponse;
    }
  }

  async getMySearchHistoryPeopleDetails(searchId: number, offset = 0, limit = 25, sortBy = 'name_asc'): Promise<PeopleSearchResult> {
    try {
      const token = localStorage.getItem("csrfToken");
      if (!token) {
        throw new Error("No authentication token found");
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": token,
        },
        body: JSON.stringify({
          action: "com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMySearchHistoryPeopleDetails",
          data: {
            searchId: searchId,
            offset: offset,
            limit: limit,
            sortBy: sortBy,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as PeopleSearchResult;
    } catch (error) {
      console.error("Error in getMySearchHistoryPeopleDetails:", error);
      return {
        error: true,
        message: "Error calling API",
        notFound: true,
        searchString: "",
        results: [],
        offset: offset,
        limit: limit,
        fetched: 0,
        sortBy: sortBy,
      } as PeopleSearchResult;
    }
  }
}