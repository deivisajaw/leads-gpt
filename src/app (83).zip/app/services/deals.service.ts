import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import { ApiConfigService } from './api-config.service';
import { catchError, map } from 'rxjs/operators';


export enum ContactType {
  PEOPLE = 'PEOPLE',
  COMPANY = 'COMPANY',
}

export enum ContactSource {
  MANUAL = 'MANUAL',
  LINKEDIN = 'LINKEDIN_SEARCH',
  AI = 'AI_SEARCH',
}

export interface Contact {
  id: number;
  contactType: ContactType;
  displayName: string;
  jobTitle?: string;
  email?: string;
  phone?: string;
  website?: string;
  address?: string;
  associatedCompany?: string;
  source: ContactSource;
  campaignId?: number;
  campaignName?: string;
  companyDataId?: number; 
  linkedinSearchResultId?: number; 
  aiSearchResultId?: number;
}

export enum DealStage {
  NEW = 'NEW',
  CONTACTED = 'CONTACTED',
  PROPOSAL_SENT = 'PROPOSAL_SENT',
  MEETING_SCHEDULED = 'MEETING_SCHEDULED',
  NEGOTIATION = 'NEGOTIATION',
  WON = 'WON',
  LOST = 'LOST',
}

export interface DealNote {
  id: number;
  author: string;
  note: string;
  date: Date;
}

export interface Deal {
  id: number;
  name: string;
  description?: string;
  amount: number;
  stage: DealStage;
  ownerUserId: number;
  ownerUserFullName: string;
  contact: Contact;
  campaignId?: number; 
  campaignName?: string; 
  expectedCloseDate: Date;
  notes: DealNote[];
  companyDataId?: number; 
}

@Injectable({
  providedIn: 'root',
})
export class DealsService {
  constructor(private http: HttpClient, private apiConfig: ApiConfigService) {}

  private getCsrfToken(): string {
    const token = localStorage.getItem('csrfToken');
    if (!token) {
      console.error('CSRF token not found');
      throw new Error('CSRF token not found');
    }
    return token;
  }

  getDeals(): Observable<Deal[]> {
    const token = this.getCsrfToken();
    const action = 'com.ajawmrp3.apps.prospectingai.service.DealService:getDeals';
    const body = { action, data: {} };

    return this.http.post<any>(`${this.apiConfig.baseUrl}/ws/action`, body, {
      headers: { 'X-CSRF-Token': token },
      withCredentials: true,
    }).pipe(
      map(response => {
        if (response.data && !response.data.error) {
          return response.data as Deal[];
        } else {
          console.error('Backend error in getDeals:', response.data?.message);
          return [];
        }
      }),
      catchError(error => {
        console.error('HTTP error in getDeals:', error);
        return of([]);
      })
    );
  }

  updateDealStage(dealId: number, newStage: DealStage): Observable<any> {
    const token = this.getCsrfToken();
    const action = 'com.ajawmrp3.apps.prospectingai.service.DealService:updateDealStage';
    const body = { action, data: { _dealId: dealId, _newStage: newStage } };

    return this.http.post<any>(`${this.apiConfig.baseUrl}/ws/action`, body, {
      headers: { 'X-CSRF-Token': token },
      withCredentials: true,
    }).pipe(
      map(response => {
        if (response.data && !response.data.error) {
          return response.data;
        } else {
          console.error('Backend error in updateDealStage:', response.data?.message);
          throw new Error(response.data?.message || 'Error al actualizar la etapa del deal');
        }
      }),
      catchError(error => {
        console.error('HTTP error in updateDealStage:', error);
        throw error;
      })
    );
  }

  addNote(dealId: number, noteText: string): Observable<DealNote | null> {
    const token = this.getCsrfToken();
    const action = 'com.ajawmrp3.apps.prospectingai.service.DealService:addDealNote';
    const body = { action, data: { _dealId: dealId, _noteText: noteText } };

    return this.http.post<any>(`${this.apiConfig.baseUrl}/ws/action`, body, {
      headers: { 'X-CSRF-Token': token },
      withCredentials: true,
    }).pipe(
      map(response => {
        if (response.data && !response.data.error) {
          return response.data as DealNote;
        } else {
          console.error('Backend error in addNote:', response.data?.message);
          throw new Error(response.data?.message || 'Error al añadir la nota');
        }
      }),
      catchError(error => {
        console.error('HTTP error in addNote:', error);
        throw error;
      })
    );
  }

  createDeal(dealData: any): Observable<Deal> {
    const token = this.getCsrfToken();
    const action = 'com.ajawmrp3.apps.prospectingai.service.DealService:createDeal';
    const body = { action, data: { _dealData: dealData } };

    return this.http.post<any>(`${this.apiConfig.baseUrl}/ws/action`, body, {
      headers: { 'X-CSRF-Token': token },
      withCredentials: true,
    }).pipe(
      map(response => {
        if (response.data && !response.data.error) {
          return response.data as Deal;
        } else {
          console.error('Backend error in createDeal:', response.data?.message);
          throw new Error(response.data?.message || 'Error al crear el deal');
        }
      }),
      catchError(error => {
        console.error('HTTP error in createDeal:', error);
        throw error;
      })
    );
  }
}
