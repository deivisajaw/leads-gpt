import { Injectable } from '@angular/core';
import { ApiConfigService } from './api-config.service';

export interface SavedCompany {
  id: number;
  title: string;
  categoryName: string;
  city: string;
  state: string;
  countryCode: string;
  website?: string;
  openingHours?: string;
  phoneUnformatted?: string;
  savedOn: string;
  additionalInfo?: string;
  address?: string;
  description?: string;
  descriptionMd?: string;
  error?: string;
  errorDescription?: string;
  neighborhood?: string;
  permanentlyClosed?: string;
  postalCode?: string;
  street?: string; 
}

export interface SaveCompanyResponse {
  error: boolean;
  message: string;
  saved?: number;
  creditsRemaining?: number;
}

export interface MyCompaniesResponse {
  error: boolean;
  message?: string;
  companies: SavedCompany[];
}

@Injectable({
  providedIn: 'root'
})
export class MyListCompanyService {

  constructor(private apiConfig: ApiConfigService) {}

  async saveCompanyResults(ids: number[]): Promise<SaveCompanyResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:saveCompanyResults',
          data: { _ids: ids }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SaveCompanyResponse;
    } catch (error) {
      console.error('Error saving companies:', error);
      return { error: true, message: 'Error saving companies' };
    }
  }

  async getMyCompanies(): Promise<MyCompaniesResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getMyCompanies',
          data: {}
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as MyCompaniesResponse;
    } catch (error) {
      console.error('Error loading companies:', error);
      return { error: true, message: 'Error loading companies', companies: [] };
    }
  }

  async getCompanyDetails(id: number): Promise<any> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:getCompanyDetails',
          data: { _id : id }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log(result.data)
      return result.data;
    } catch (error) {
      console.error('Error loading company details:', error);
      return { error: true, message: 'Error loading company details' };
    }
  }

  async saveAllCompanyResults(searchId: number): Promise<SaveCompanyResponse> {
    try {
      const token = localStorage.getItem('csrfToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': token
        },
        body: JSON.stringify({
          action: 'com.ajawmrp3.apps.prospectingai.web.AiSearchController:saveAllCompanyResults',
          data: { _searchId: searchId }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.data as SaveCompanyResponse;
    } catch (error) {
      console.error('Error saving all companies:', error);
      return { error: true, message: 'An error occurred while trying to save all companies.' };
    }
  }
}