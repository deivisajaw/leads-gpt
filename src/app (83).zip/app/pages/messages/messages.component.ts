import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

// --- INTERFACES ---
export interface Agent {
  id: number;
  name: string; // e.g., 'Agente de Ventas'
  agentSystemName: string; // e.g., 'Luisa'
  avatarUrl: string;
  processed: boolean; // This is the status
  agentType: 'TEXT';
  agentDirection: 'INBOUND';
  language: string;
  purpose: string;
  description: string;
}

export interface Conversation {
  id: number;
  agentId: number;
  customerName: string;
  customerEmail: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
  avatarUrl: string; // Will be a generic icon
}

export interface Message {
  id: number;
  conversationId: number;
  sender: 'agent' | 'customer';
  text: string;
  timestamp: string;
  avatarUrl: string;
}

@Component({
  selector: 'app-messages',
  standalone: true,
  imports: [CommonModule, TranslateModule, FormsModule],
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  @ViewChild('agentListContainer') agentListContainer!: ElementRef<HTMLDivElement>;

  // --- DATA ARRAYS ---
  allAgents: Agent[] = [];
  allConversations: Conversation[] = [];
  allMessages: Message[] = [];

  // --- STATE PROPERTIES ---
  selectedAgent: Agent | null = null;
  selectedConversation: Conversation | null = null;
  
  filteredConversations: Conversation[] = [];
  currentMessages: Message[] = [];
  conversationSearchText: string = '';

  isPurposeCollapsed = true;
  isDescriptionCollapsed = true;
  isInfoPanelCollapsed = false;
  
  // --- CONSTANTS ---
  ANONYMOUS_AVATAR = 'data:image/svg+xml,%3csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cccccc"%3e%3cpath d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/%3e%3c/svg%3e'; // A generic user icon

  constructor() { }

  ngOnInit(): void {
    this.allAgents = this.getFakeAgents();
    this.allConversations = this.getFakeConversations();
    this.allMessages = this.getFakeMessages();
  }

  // --- EVENT HANDLERS ---

  selectAgent(agent: Agent): void {
    this.selectedAgent = agent;
    this.selectedConversation = null;
    this.currentMessages = [];
    this.conversationSearchText = '';
    this.isPurposeCollapsed = true;
    this.isDescriptionCollapsed = true;
    this.onFilterConversations();
  }

  selectConversation(conversation: Conversation): void {
    this.selectedConversation = conversation;
    this.currentMessages = this.allMessages.filter(m => m.conversationId === conversation.id);
    conversation.unreadCount = 0;
  }

  onFilterConversations(): void {
    if (!this.selectedAgent) {
      this.filteredConversations = [];
      return;
    }
    
    let conversations = this.allConversations.filter(c => c.agentId === this.selectedAgent!.id);

    if (this.conversationSearchText) {
      const lowercasedFilter = this.conversationSearchText.toLowerCase();
      conversations = conversations.filter(c => 
        c.customerName.toLowerCase().includes(lowercasedFilter) ||
        c.customerEmail.toLowerCase().includes(lowercasedFilter) ||
        c.lastMessage.toLowerCase().includes(lowercasedFilter)
      );
    }
    
    this.filteredConversations = conversations;
  }

  scrollAgents(direction: 'left' | 'right'): void {
    const container = this.agentListContainer.nativeElement;
    const scrollAmount = 300; // Amount to scroll in pixels
    if (direction === 'left') {
      container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  }

  toggleInfoPanel(): void {
    this.isInfoPanelCollapsed = !this.isInfoPanelCollapsed;
  }

  // --- FAKE DATA GENERATORS ---

  getFakeAgents(): Agent[] {
    return [
      { id: 1, name: 'Agente de Soporte Técnico', agentSystemName: 'Luisa', avatarUrl: 'https://i.pravatar.cc/150?img=1', processed: true, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Español', purpose: 'El propósito principal de este agente es resolver dudas técnicas de primer nivel, como problemas de acceso, configuración inicial de la cuenta y preguntas frecuentes sobre el uso de la plataforma.', description: 'Asistente virtual diseñado para guiar a los usuarios a través de problemas técnicos comunes. Utiliza una base de conocimientos para ofrecer soluciones paso a paso y puede escalar la conversación a un agente humano si el problema es demasiado complejo.' },
      { id: 2, name: 'Asistente de Ventas', agentSystemName: 'Carlos', avatarUrl: 'https://i.pravatar.cc/150?img=2', processed: true, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Español', purpose: 'Calificar leads entrantes y agendar demostraciones de producto con el equipo de ventas.', description: 'Este agente interactúa con los visitantes del sitio web para entender sus necesidades, proveer información inicial de productos y servicios, y determinar si son un buen prospecto para una demostración.' },
      { id: 3, name: 'Guía de Onboarding', agentSystemName: 'Ana', avatarUrl: 'https://i.pravatar.cc/150?img=3', processed: false, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Inglés', purpose: 'Ayudar a nuevos usuarios a configurar su cuenta y a realizar las primeras acciones clave dentro de la aplicación.', description: 'Un guía interactivo que se activa para los nuevos registros. Ofrece un tour por la interfaz, explica las funcionalidades principales y se asegura de que el usuario complete su perfil y configuraciones iniciales.' },
      { id: 4, name: 'Recepción General', agentSystemName: 'Sofía', avatarUrl: 'https://i.pravatar.cc/150?img=4', processed: true, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Español', purpose: 'Servir como el primer punto de contacto y dirigir a los usuarios al departamento o agente correcto.', description: 'Este agente actúa como un recepcionista virtual. Analiza la consulta inicial del usuario y lo transfiere al agente especializado más adecuado, ya sea de soporte, ventas o facturación.' },
      { id: 5, name: 'Especialista de Producto', agentSystemName: 'David', avatarUrl: 'https://i.pravatar.cc/150?img=5', processed: true, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Portugués', purpose: 'Responder preguntas avanzadas y técnicas sobre las funcionalidades específicas del producto.', description: 'Un experto virtual en las características y casos de uso del producto. Ideal para usuarios que ya conocen lo básico y tienen dudas sobre integraciones, API o configuraciones avanzadas.' },
      { id: 6, name: 'Agente de Feedback', agentSystemName: 'Eva', avatarUrl: 'https://i.pravatar.cc/150?img=6', processed: false, agentType: 'TEXT', agentDirection: 'INBOUND', language: 'Español', purpose: 'Recolectar de forma proactiva opiniones, sugerencias y feedback general de los usuarios sobre su experiencia.', description: 'Este agente inicia conversaciones con usuarios activos para preguntarles sobre su experiencia, qué les gusta, qué no les gusta y qué funcionalidades les gustaría ver en el futuro. La información se usa para mejorar el producto.' },
    ];
  }

  getFakeConversations(): Conversation[] {
    return [
      { id: 101, agentId: 1, customerName: 'John Doe', customerEmail: 'john.d@example.com', lastMessage: 'Perfecto, gracias por la ayuda.', timestamp: '10:30 AM', unreadCount: 0, avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 102, agentId: 1, customerName: 'Jane Smith', customerEmail: 'jane.s@example.com', lastMessage: '¿Podrías verificar el estado de mi pedido?', timestamp: '10:25 AM', unreadCount: 2, avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 201, agentId: 2, customerName: 'Peter Jones', customerEmail: 'peter.j@example.com', lastMessage: 'Necesito información de precios.', timestamp: 'Yesterday', unreadCount: 0, avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 301, agentId: 3, customerName: 'Mary Williams', customerEmail: 'mary.w@example.com', lastMessage: 'Gracias, muy amable.', timestamp: '9:15 AM', unreadCount: 0, avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 302, agentId: 3, customerName: 'David Brown', customerEmail: 'david.b@example.com', lastMessage: 'No estoy seguro de entender.', timestamp: '9:05 AM', unreadCount: 0, avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 401, agentId: 4, customerName: 'Susan Garcia', customerEmail: 'susan.g@example.com', lastMessage: 'Ok, lo revisaré.', timestamp: 'Yesterday', unreadCount: 1, avatarUrl: this.ANONYMOUS_AVATAR },
    ];
  }

  getFakeMessages(): Message[] {
    return [
      { id: 1011, conversationId: 101, sender: 'customer', text: 'Hola, tengo una pregunta sobre mi factura.', timestamp: '10:28 AM', avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 1012, conversationId: 101, sender: 'agent', text: 'Claro, ¿en qué puedo ayudarte?', timestamp: '10:29 AM', avatarUrl: 'https://i.pravatar.cc/150?img=1' },
      { id: 1013, conversationId: 101, sender: 'customer', text: 'Veo un cargo que no reconozco.', timestamp: '10:29 AM', avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 1014, conversationId: 101, sender: 'agent', text: 'Permíteme un momento para revisarlo... Ya veo, corresponde a la suscripción premium. ¿Deseas cancelarla?', timestamp: '10:30 AM', avatarUrl: 'https://i.pravatar.cc/150?img=1' },
      { id: 1015, conversationId: 101, sender: 'customer', text: 'No, está bien. Solo quería asegurarme. Perfecto, gracias por la ayuda.', timestamp: '10:30 AM', avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 1021, conversationId: 102, sender: 'customer', text: '¿Podrías verificar el estado de mi pedido?', timestamp: '10:25 AM', avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 3011, conversationId: 301, sender: 'customer', text: 'Excelente servicio.', timestamp: '9:14 AM', avatarUrl: this.ANONYMOUS_AVATAR },
      { id: 3012, conversationId: 301, sender: 'agent', text: 'Estamos para servirle. Gracias, muy amable.', timestamp: '9:15 AM', avatarUrl: 'https://i.pravatar.cc/150?img=3' },
    ];
  }
}
