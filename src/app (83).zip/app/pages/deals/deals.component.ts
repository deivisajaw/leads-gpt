
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
  CdkDropListGroup,
  CdkDropList,
  CdkDrag,
} from '@angular/cdk/drag-drop';
import { DealsService, Deal, DealStage } from '../../services/deals.service';
import { DealDetailModalComponent } from '../../components/deal-detail-modal/deal-detail-modal.component';
import { NotificationService } from '../../services/notification.service'; // Importar NotificationService

@Component({
  selector: 'app-deals',
  standalone: true,
  imports: [
    CommonModule,
    CdkDropListGroup,
    CdkDropList,
    CdkDrag,
    TranslateModule,
    DealDetailModalComponent, 
  ],
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.css'],
})
export class DealsComponent implements OnInit {
  public columns: DealStage[] = Object.values(DealStage);
  public board: Record<DealStage, Deal[]> = {
    [DealStage.NEW]: [],
    [DealStage.CONTACTED]: [],
    [DealStage.PROPOSAL_SENT]: [],
    [DealStage.MEETING_SCHEDULED]: [],
    [DealStage.NEGOTIATION]: [],
    [DealStage.WON]: [],
    [DealStage.LOST]: [],
  };

  public selectedDeal: Deal | null = null;
  public isUpdatingStage: boolean = false; // Bandera para el estado de carga

  constructor(private dealsService: DealsService, private notificationService: NotificationService) {} // Inyectar NotificationService

  ngOnInit(): void {
    this.dealsService.getDeals().subscribe((deals) => {
      deals.forEach((deal) => {
        if (this.board[deal.stage]) {
          this.board[deal.stage].push(deal);
        }
      });
    });
  }

  drop(event: CdkDragDrop<Deal[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      const deal = event.previousContainer.data[event.previousIndex];
      const oldStage = deal.stage; // Guardar la etapa anterior para posible rollback
      const newStage = event.container.id as DealStage;

      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );

      this.isUpdatingStage = true; // Activar el indicador de carga

      this.dealsService.updateDealStage(deal.id, newStage).subscribe({
        next: () => {
          deal.stage = newStage; // Actualizar el estado del deal solo si el backend confirma
          this.notificationService.showSuccess('Etapa del deal actualizada correctamente.');
          this.isUpdatingStage = false; // Desactivar el indicador de carga en exito
        },
        error: (err) => {
          console.error('Error al actualizar la etapa del deal:', err);
          this.notificationService.showError('Error al actualizar la etapa del deal: ' + (err.message || ''));
          // Si falla, revertir el movimiento visual
          transferArrayItem(
            event.container.data,
            event.previousContainer.data,
            event.currentIndex,
            event.previousIndex
          );
          deal.stage = oldStage; // Revertir el estado del deal
          this.isUpdatingStage = false; // Desactivar el indicador de carga en error
        }
      });
    }
  }

  getConnectedList(): string[] {
    return this.columns;
  }

  // --- Métodos para el Modal ---

  openDealModal(deal: Deal): void {
    this.selectedDeal = deal;
  }

  onModalClose(): void {
    this.selectedDeal = null;
  }
}

