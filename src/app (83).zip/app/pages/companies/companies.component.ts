import { Component, OnInit, OnDestroy } from "@angular/core"
import { CommonModule } from "@angular/common"
import { FormsModule } from "@angular/forms"
import { TranslateModule } from '@ngx-translate/core';
import { Router } from "@angular/router"
import { CompaniesService, Company, CompanySearchResult, CompanySearchResponse } from "../../services/companies.service"
import { MyListCompanyService } from "../../services/my-list-company.service"
import { AuthService } from "../../services/auth.service";
import { Subscription } from "rxjs";
import { NotificationService } from "../../services/notification.service";
import { PlansComponent } from '../plans/plans.component';
import { OnboardingService } from "../../services/onboarding.service";

@Component({
  selector: "app-companies",
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule, PlansComponent],
  templateUrl: "./companies.component.html",
  styleUrl: "./companies.component.css",
})
export class CompaniesComponent implements OnInit, OnDestroy {
  searchQuery = ""
  currentQuery = ""
  isLoading = false;
  isAiSearching = false;
  currentView: "grid" | "card" | "default" = "grid"
  currentViewText = "Grid view"
  filteredResults: Company[] = []
  currentPage = 1
  itemsPerPage = 25
  selectedCompanies: number[] = []
  selectAllChecked = false
  totalResults = 0
  currentSearchId: number | null = null

  placeholderTexts: string[] = [
    "Ejemplo: Empresas de tecnologia en Colombia",
    "Ejemplo: Empresas de comercio electronico",
    "Ejemplo: Empresas de la industria dental",
    "Ejemplo: Restaurantes en Cali"
  ];
  currentPlaceholder = this.placeholderTexts[0];
  private placeholderInterval: any;

  totalResultsInServer = 0;
  searchStatus = "";
  searchStatusSelect: number | null = null;
  currentOffset = 0;

  showViewDropdown = false
  showImportDropdown = false
  showWorkflowDropdown = false
  showSortDropdown = false

  public showFilters = false;
  public localFilters = {
    title: '',
    categoryName: '',
    city: '',
    state: '',
    countryCode: ''
  };
  public displayResults: Company[] = [];
  public currentSortOrder: string = 'title_asc';
  private pollingInterval: any;
  private pollTimeout: any;
  public isPolling: boolean = false;

  public creditsRemaining: number = 0;
  private userProfileSubscription!: Subscription;

  public searchError: string | null = null;
  public showPlans: boolean = false;
  public isSaving: boolean = false;
  public isSavingAll: boolean = false;

  constructor(
    private companiesService: CompaniesService,
    private myListCompanyService: MyListCompanyService,
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService,
    private onboardingService: OnboardingService
  ) {
    document.addEventListener("click", (event) => {
      const target = event.target as HTMLElement
      if (!target.closest(".dropdown-wrapper")) {
        this.closeAllDropdowns()
      }
    })
  }

  ngOnInit(): void {
    this.userProfileSubscription = this.authService.userProfile$.subscribe(profile => {
      if (profile && profile.companyProfile) {
        this.creditsRemaining = profile.companyProfile.creditsAllocated ?? 0;
      }
    });
    this.startTypingEffect();
  }

  ngOnDestroy(): void {
    this.stopPolling();
    if (this.placeholderInterval) {
      clearTimeout(this.placeholderInterval);
    }
    if (this.userProfileSubscription) {
      this.userProfileSubscription.unsubscribe();
    }
  }

  private startTypingEffect(): void {
    let textIndex = 0;
    let charIndex = 0;
    const typeSpeed = 100;
    const pauseTime = 2000;

    const type = () => {
      if (charIndex < this.placeholderTexts[textIndex].length) {
        this.currentPlaceholder = this.placeholderTexts[textIndex].substring(0, charIndex + 1);
        charIndex++;
        this.placeholderInterval = setTimeout(type, typeSpeed);
      } else {
        this.placeholderInterval = setTimeout(erase, pauseTime);
      }
    }

    const erase = () => {
      if (charIndex > 0) {
        this.currentPlaceholder = this.placeholderTexts[textIndex].substring(0, charIndex - 1);
        charIndex--;
        this.placeholderInterval = setTimeout(erase, typeSpeed / 2);
      } else {
        textIndex = (textIndex + 1) % this.placeholderTexts.length;
        this.placeholderInterval = setTimeout(type, typeSpeed);
      }
    }
    type();
  }

  async onSearch() {
    if (!this.searchQuery.trim()) {
      this.resetSearchState();
      return;
    }

    this.stopPolling();
    this.searchError = null;
    this.showPlans = false;
    this.filteredResults = [];
    this.displayResults = [];
    this.currentPage = 1;
    this.currentOffset = 0;
    this.selectedCompanies = [];
    this.selectAllChecked = false;
    this.isAiSearching = false;

    this.isLoading = true;
    this.currentQuery = this.searchQuery;

    try {
      const response = await this.companiesService.runSearchCompanies(
        this.currentQuery, 0, this.itemsPerPage, this.currentSortOrder
      );
      this.processApiResponse(response);
    } catch (error) {
      console.error("Search error:", error);
      this.searchError = "Ocurrio un error inesperado al buscar.";
      this.isLoading = false;
    }
  }

  private processApiResponse(response: CompanySearchResponse) {
    this.isLoading = false;
    this.searchError = null;
    this.showPlans = false;

    switch (response.status) {
      case 'SEARCH_NOT_FOUND':
        this.isAiSearching = true;
        this.triggerExternalSearch();
        break;

      case 'SEARCH_IN_PROGRESS':
        this.isAiSearching = false;
        this.updateStateFromData(response.data);
        if (!this.isPolling) {
          this.startPolling();
        }
        break;

      case 'SUCCESS':
        this.isAiSearching = false;
        this.stopPolling();
        this.updateStateFromData(response.data);
        this.onboardingService.completeOnboardingStepByKey('FIND_LEADS');
        break;

      case 'INSUFFICIENT_CREDITS':
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = response.message || "No tienes creditos suficientes.";
        this.showPlans = true;
        break;

      case 'UNAUTHORIZED':
      case 'INVALID_INPUT':
      case 'ERROR':
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = response.message || "Ocurrio un error.";
        break;

      default:
        this.isAiSearching = false;
        this.stopPolling();
        this.searchError = "Respuesta desconocida del servidor.";
        break;
    }
  }

  private async triggerExternalSearch() {
    if (this.creditsRemaining < 2) {
      this.searchError = "No tienes creditos suficientes (minimo 2) para una nueva busqueda.";
      this.showPlans = true;
      this.isAiSearching = false;
      return;
    }

    try {
      const externalResult = await this.companiesService.triggerExternalSearch(this.currentQuery);
      if (externalResult.status === 0) {
        this.startPolling();
        this.onboardingService.completeOnboardingStepByKey('FIND_LEADS');
      } else {
        this.searchError = "Error al iniciar la busqueda externa.";
        this.isAiSearching = false;
      }
    } catch (error) {
      this.searchError = "Error de red al iniciar la busqueda externa.";
      this.isAiSearching = false;
    }
  }

  private updateStateFromData(data: CompanySearchResult | undefined) {
    if (!data) return;

    this.filteredResults = data.results ?? [];
    this.totalResultsInServer = data.resultsNumber || 0;
    this.currentSearchId = data.searchId || null;
    this.searchStatusSelect = data.statusSelect || null;
    this.currentOffset = data.offset;
    this.currentSortOrder = data.sortBy || 'title_asc';
    this.searchStatus = this.getStatusText();

    if (data.creditsRemaining !== undefined) {
      this.authService.updateCurrentUserCredits(data.creditsRemaining);
    }

    this.applyLocalFilters();
  }

  private startPolling() {
    if (this.isPolling) return;

    this.isPolling = true;

    this.pollTimeout = setTimeout(() => {
      if (this.isPolling) {
        this.stopPolling();
        this.searchStatus = "La busqueda ha tardado demasiado. Intentalo de nuevo.";
      }
    }, 120000);

    this.pollingInterval = setInterval(async () => {
      if (!this.currentQuery) {
        this.stopPolling();
        return;
      }
      try {
        const response = await this.companiesService.runSearchCompanies(
          this.currentQuery, this.currentOffset, this.itemsPerPage, this.currentSortOrder
        );
        this.processApiResponse(response);
      } catch (error) {
        this.searchError = "Error durante el sondeo: " + error;
        this.stopPolling();
      }
    }, 5000);
  }

  private stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.pollTimeout) {
      clearTimeout(this.pollTimeout);
      this.pollTimeout = null;
    }
    this.isPolling = false;
  }

  private resetSearchState() {
    this.stopPolling();
    this.currentQuery = "";
    this.searchQuery = "";
    this.filteredResults = [];
    this.displayResults = [];
    this.selectedCompanies = [];
    this.currentSearchId = null;
    this.totalResultsInServer = 0;
    this.searchStatusSelect = null;
    this.currentOffset = 0;
    this.searchStatus = "";
    this.searchError = null;
    this.showPlans = false;
    this.isLoading = false;
    this.isAiSearching = false;
  }

  private getStatusText(): string {
    switch (this.searchStatusSelect) {
      case 1: return "Busqueda IA en progreso";
      case 2: return "Busqueda IA completada";
      case 3: return "Busqueda finalizada sin resultados";
      default: return this.isPolling ? "Iniciando busqueda..." : "";
    }
  }

  async goToPage(page: number) {
    if (page < 1 || !this.currentQuery || this.isLoading) return;

    const newOffset = (page - 1) * this.itemsPerPage;
    if (newOffset >= this.totalResultsInServer && this.totalResultsInServer > 0) {
      return;
    }

    this.isLoading = true;
    this.currentPage = page;
    this.currentOffset = newOffset;

    try {
      const response = await this.companiesService.runSearchCompanies(
        this.currentQuery, newOffset, this.itemsPerPage, this.currentSortOrder
      );
      this.processApiResponse(response);
    } catch (error) {
      console.error("Error loading page:", error);
      this.searchError = "Error al cargar la pagina.";
      this.isLoading = false;
    }
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === "Enter") {
      this.onSearch()
    }
  }

  get showSelectionBar(): boolean {
    return this.selectedCompanies.length > 0
  }

  changeView(view: "grid" | "card" | "default") {
    this.currentView = view
    switch (view) {
      case "grid": this.currentViewText = "Grid view"; break;
      case "card": this.currentViewText = "Card view"; break;
      case "default": this.currentViewText = "Default view"; break;
    }
  }

  toggleSelectAll() {
    this.selectAllChecked = !this.selectAllChecked
    this.selectedCompanies = this.selectAllChecked ? this.displayResults.map(c => c.id) : [];
  }

  toggleCompanySelection(companyId: number) {
    const index = this.selectedCompanies.indexOf(companyId)
    if (index > -1) {
      this.selectedCompanies.splice(index, 1)
    } else {
      this.selectedCompanies.push(companyId)
    }
    this.selectAllChecked = this.displayResults.length > 0 && this.selectedCompanies.length === this.displayResults.length;
  }

  async addToMyList() {
    const creditsNeeded = this.selectedCompanies.length;
    if (creditsNeeded === 0) {
      this.notificationService.showError("No hay empresas seleccionadas");
      return;
    }
    if (this.creditsRemaining < creditsNeeded) {
      this.notificationService.showError(`No tienes creditos suficientes. Necesitas ${creditsNeeded} y tienes ${this.creditsRemaining}.`);
      return;
    }
    this.isSaving = true;
    try {
      const result = await this.myListCompanyService.saveCompanyResults(this.selectedCompanies);
      if (result.error) {
        this.notificationService.showError(result.message || "Error al guardar las empresas");
      } else {
        if (result.creditsRemaining !== undefined) {
          this.authService.updateCurrentUserCredits(result.creditsRemaining);
        }
        this.notificationService.showSuccess(`${result.saved} empresas anadidas a tu lista.`);
        this.selectedCompanies = [];
        this.selectAllChecked = false;
        this.onboardingService.completeOnboardingStepByKey('SAVE_LEAD');
      }
    } catch (error) {
      this.notificationService.showError("Error de conexion al guardar las empresas.");
    } finally {
      this.isSaving = false;
    }
  }

  async addAllToMyList() {
    if (!this.currentSearchId || this.totalResultsInServer === 0) {
      this.notificationService.showError("No hay una busqueda activa o la busqueda no arrojo resultados.");
      return;
    }
    const creditsNeeded = this.totalResultsInServer;
    if (this.creditsRemaining < creditsNeeded) {
      this.notificationService.showError(`No tienes creditos suficientes. Necesitas ${creditsNeeded} y tienes ${this.creditsRemaining}.`);
      return;
    }
    this.isSavingAll = true;
    try {
      const result = await this.myListCompanyService.saveAllCompanyResults(this.currentSearchId);
      if (result && result.error === false && typeof result.saved === 'number') {
        if (result.creditsRemaining !== undefined) {
          this.authService.updateCurrentUserCredits(result.creditsRemaining);
        }
        this.notificationService.showSuccess(`${result.saved} nuevas empresas anadidas a tu lista.`);
        this.selectedCompanies = [];
        this.selectAllChecked = false;
      } else {
        const errorMessage = result?.message || "Ocurrio un error en el servidor. Por favor, intentalo de nuevo.";
        this.notificationService.showError(errorMessage);
      }
    } catch (error) {
      this.notificationService.showError("Error de conexion al guardar todas las empresas.");
    } finally {
      this.isSavingAll = false;
    }
  }

  downloadSelected() {
    this.notificationService.showError(`Downloading ${this.selectedCompanies.length} selected companies`)
  }

  viewSelected() {
    this.notificationService.showError(`Viewing ${this.selectedCompanies.length} selected companies`)
  }

  closeSelectionBar() {
    this.selectedCompanies = []
    this.selectAllChecked = false
  }

  get totalPages(): number {
    return Math.ceil(this.totalResultsInServer / this.itemsPerPage)
  }

  getStartIndex(): number {
    return this.displayResults.length > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.totalResultsInServer);
  }

  getFormattedTotal(): string {
    return this.totalResultsInServer.toLocaleString()
  }

  toggleDropdown(dropdownName: string) {
    this.showViewDropdown = dropdownName === 'view' ? !this.showViewDropdown : false;
    this.showImportDropdown = dropdownName === 'import' ? !this.showImportDropdown : false;
    this.showWorkflowDropdown = dropdownName === 'workflow' ? !this.showWorkflowDropdown : false;
    this.showSortDropdown = dropdownName === 'sort' ? !this.showSortDropdown : false;
  }

  closeAllDropdowns() {
    this.showViewDropdown = false
    this.showImportDropdown = false
    this.showWorkflowDropdown = false
    this.showSortDropdown = false
  }

  getStatusClass(status: number): string {
    switch (status) {
      case 1: return 'status-orange';
      case 2: return 'status-green';
      case 3: return 'status-red';
      default: return '';
    }
  }

  goToUpgradePlan(): void {
    this.router.navigate(['/upgrade-plan']);
  }

  public applyLocalFilters(): void {
    let results = [...this.filteredResults];
    if (this.localFilters.title) {
      results = results.filter(c => c.title && c.title.toLowerCase().includes(this.localFilters.title.toLowerCase()));
    }
    if (this.localFilters.categoryName) {
      results = results.filter(c => c.categoryName && c.categoryName.toLowerCase().includes(this.localFilters.categoryName.toLowerCase()));
    }
    if (this.localFilters.city) {
      results = results.filter(c => c.city && c.city.toLowerCase().includes(this.localFilters.city.toLowerCase()));
    }
    if (this.localFilters.state) {
      results = results.filter(c => c.state && c.state.toLowerCase().includes(this.localFilters.state.toLowerCase()));
    }
    if (this.localFilters.countryCode) {
      results = results.filter(c => c.countryCode && c.countryCode.toLowerCase().includes(this.localFilters.countryCode.toLowerCase()));
    }
    this.displayResults = results;
  }

  public onFilterChange(): void {
    this.currentPage = 1;
    this.applyLocalFilters();
  }

  public toggleFilters(): void {
    this.showFilters = !this.showFilters;
    if (!this.showFilters) {
      this.currentPage = 1;
      this.localFilters = { title: '', categoryName: '', city: '', state: '', countryCode: '' };
      this.applyLocalFilters();
    }
  }

  public onSortChange(sortBy: string): void {
    this.currentSortOrder = sortBy;
    this.goToPage(1);
    this.closeAllDropdowns();
  }
}
