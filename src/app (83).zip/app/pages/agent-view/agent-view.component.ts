import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AgentService, Agent } from '../../services/agent.service';
import { ApiConfigService } from '../../services/api-config.service';

export interface AlertMessage {
  type: "success" | "error"
  text: string
}

@Component({
  selector: 'app-agent-view',
  standalone: true,
  imports: [CommonModule, FormsModule], 
  templateUrl: './agent-view.component.html',
  styleUrl: './agent-view.component.css'
})
export class AgentViewComponent implements OnInit {
  private agentService = inject(AgentService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private apiConfig = inject(ApiConfigService); 

  agent: Agent | null = null;
  alertMessage: AlertMessage | null = null;
  errorMessage: string | null = null; 
  isLoading: boolean = true;

  isTestCallModalVisible: boolean = false;
  testCallAgentId: number | null = null;
  testCallContactPhone: string = '';
  testCallContactName: string = '';
  testCallContactEmail: string = '';
  isTestCallLoading: boolean = false;
  showTestCallValidationErrors: boolean = false;

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const agentId = params.get('id');
      if (agentId) {
        this.loadAgentDetails(+agentId);
      } else {
        this.showAlert('error', 'ID de agente no proporcionado.');
        this.router.navigate(['/agents']); 
      }
    });
  }

  async loadAgentDetails(id: number): Promise<void> {
    this.errorMessage = null; 
    this.isLoading = true; 
    this.agent = null; 

    try {
      const responseData = await this.agentService.getAgentById(id);
      if (responseData && responseData.error) {
        this.errorMessage = `Ha ocurrido un error: ${ (responseData as any).message || 'Error desconocido del backend.'}`;
        this.agent = null; 
      } else if (!responseData || !responseData.agent) { 
        this.errorMessage = 'Agente no encontrado o datos vacíos.';
        this.router.navigate(['/agents']); 
      } else {
        this.agent = responseData.agent; 
      }
    } catch (err: any) {
      console.error('Error loading agent details (caught exception):', err);
      const backendErrorMessage = err.message || 'Error desconocido del backend.';
      this.errorMessage = `Ha ocurrido un error: ${backendErrorMessage}`;
      this.agent = null; 
    } finally {
      this.isLoading = false; 
    }
  }

  goBack(): void {
    this.router.navigate(['/agents']);
  }

  showAlert(type: "success" | "error", text: string): void {
    this.alertMessage = { type, text };
    setTimeout(() => {
      this.alertMessage = null;
    }, 5000);
  }

  openTestCallModal(agentId: number): void {
    this.testCallAgentId = agentId;
    this.testCallContactPhone = '';
    this.testCallContactName = '';
    this.testCallContactEmail = '';
    this.isTestCallLoading = false;
    this.showTestCallValidationErrors = false;
    this.isTestCallModalVisible = true;
  }

  closeTestCallModal(): void {
    this.isTestCallModalVisible = false;
    this.testCallAgentId = null;
    this.testCallContactPhone = '';
    this.testCallContactName = '';
    this.testCallContactEmail = '';
    this.isTestCallLoading = false;
    this.showTestCallValidationErrors = false;
  }

  isTestCallFormValid(): boolean {
    return !!this.testCallContactPhone && !!this.testCallContactName;
  }

  async triggerTestCall(): Promise<void> {
    if (!this.isTestCallFormValid()) {
      this.showTestCallValidationErrors = true;
      this.showAlert("error", "Por favor, complete el número y nombre de contacto.");
      return;
    }

    this.isTestCallLoading = true;
    this.showTestCallValidationErrors = false;

    const payload = {
      agentId: this.testCallAgentId!,
      contactPhone: this.testCallContactPhone,
      contactName: this.testCallContactName,
      contactEmail: this.testCallContactEmail || undefined
    };

    try {
      const response = await this.agentService.triggerTestCallWebhook(payload).toPromise();

      if (response && response.success) {
        this.showAlert("success", response.success);
      } else if (response && response.error) {
        this.showAlert("error", response.error);
      } else {
        this.showAlert("error", "Respuesta inesperada del webhook de prueba de llamada.");
      }
    } catch (error: any) {
      console.error('Error al realizar la llamada de prueba:', error);
      const errorMessage = error.error?.error || error.message || 'Error desconocido al intentar la llamada de prueba.';
      this.showAlert("error", `Error en la llamada de prueba: ${errorMessage}`);
    } finally {
      this.isTestCallLoading = false;
      this.closeTestCallModal();
    }
  }
}
