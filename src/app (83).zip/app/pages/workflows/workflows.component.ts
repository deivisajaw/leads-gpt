import { Component } from '@angular/core';

@Component({
  selector: 'app-workflows',
  standalone: true,
  imports: [],
  templateUrl: './workflows.component.html',
  styleUrl: './workflows.component.css'
})
export class WorkflowsComponent {

}
