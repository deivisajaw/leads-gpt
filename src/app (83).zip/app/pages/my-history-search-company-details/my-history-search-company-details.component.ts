import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { CompaniesService, Company, CompanySearchResult } from '../../services/companies.service';
import { MyListCompanyService } from '../../services/my-list-company.service'; // Import MyListCompanyService
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';
import { OnboardingService } from "../../services/onboarding.service"; // NEW IMPORT

@Component({
  selector: 'app-my-history-search-company-details',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, TranslateModule],
  templateUrl: './my-history-search-company-details.component.html',
  styleUrl: './my-history-search-company-details.component.css'
})
export class MyHistorySearchCompanyDetailsComponent implements OnInit, OnDestroy {
  searchId: number = 0;
  searchDetails: CompanySearchResult | null = null;
  isLoading = false;
  currentPage = 1;
  itemsPerPage = 25;
  totalResultsInServer = 0;
  currentSortOrder = 'title_asc';
  currentQuery = ''; // To display the search string

  showSortDropdown = false;

  private pollingInterval: any;
  private pollTimeout: any;
  public isPolling: boolean = false;

  private routeSubscription!: Subscription;

  selectedCompanies: number[] = []; // Added property
  selectAllChecked = false; // Added property

  public creditsRemaining: number = 0;
  private userProfileSubscription!: Subscription;
  public isSaving: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private companiesService: CompaniesService,
    private myListCompanyService: MyListCompanyService,
    private authService: AuthService,
    private notificationService: NotificationService,
    private onboardingService: OnboardingService // NEW INJECTION
  ) {
    document.addEventListener('click', (event) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.dropdown-wrapper')) {
        this.closeAllDropdowns();
      }
    });
  }

  ngOnInit() {
    this.routeSubscription = this.route.params.subscribe(params => {
      this.searchId = +params['id'];
      this.loadSearchDetails();
    });

    this.userProfileSubscription = this.authService.userProfile$.subscribe(profile => {
      if (profile && profile.companyProfile) {
        this.creditsRemaining = profile.companyProfile.creditsAllocated ?? 0;
      }
    });
  }

  ngOnDestroy(): void {
    if (this.routeSubscription) {
      this.routeSubscription.unsubscribe();
    }
    this.stopPolling();

    if (this.userProfileSubscription) {
      this.userProfileSubscription.unsubscribe();
    }
  }

  async loadSearchDetails(page: number = this.currentPage, sortBy: string = this.currentSortOrder) {
    this.isLoading = true; // Start loading
    this.currentPage = page;
    this.currentSortOrder = sortBy;
    const offset = (this.currentPage - 1) * this.itemsPerPage;

    try {
      const result: CompanySearchResult = await this.companiesService.getMySearchHistoryCompanyDetails(
        this.searchId,
        offset,
        this.itemsPerPage,
        this.currentSortOrder
      );

      if (result.error) {
        console.error('Error loading company search details:', result.message);
        this.searchDetails = null;
        this.totalResultsInServer = 0;
        this.isLoading = false; // Stop loading on error
        this.stopPolling(); // Ensure polling is stopped
      } else {
        this.searchDetails = result;
        this.currentQuery = result.searchString; // Set the query for display
        this.totalResultsInServer = result.resultsNumber || 0;

        // Handle polling based on search status
        if (result.statusSelect === 1) {
          this.startPolling(); // Polling starts, isLoading remains true
        } else {
          this.stopPolling(); // Stop polling if not in process
          this.isLoading = false; // Stop loading if no polling
        }
      }
    } catch (error) {
      console.error('Error loading company search details:', error);
      this.searchDetails = null;
      this.totalResultsInServer = 0;
      this.isLoading = false; // Stop loading on error
      this.stopPolling(); // Ensure polling is stopped
    }
  }

  private stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.pollTimeout) {
      clearTimeout(this.pollTimeout);
      this.pollTimeout = null;
    }
    this.isPolling = false;
    this.isLoading = false; // Ensure isLoading is reset
  }

  private startPolling() {
    this.stopPolling(); // Ensure any previous poll is stopped

    this.isPolling = true; // Indicate that background polling is active

    // Set a timeout to prevent infinite polling
    this.pollTimeout = setTimeout(() => {
      this.stopPolling();
      // Optionally update a status message here if needed
    }, 120000); // 2-minute timeout

    this.pollingInterval = setInterval(async () => {
      // Set isLoading to true for THIS polling request
      this.isLoading = true; 
      try {
        // Call the details method with current pagination/sort
        const result: CompanySearchResult = await this.companiesService.getMySearchHistoryCompanyDetails(
          this.searchId,
          (this.currentPage - 1) * this.itemsPerPage,
          this.itemsPerPage,
          this.currentSortOrder
        );

        if (result.error) {
          console.error('Error during polling for company search details:', result.message);
          this.stopPolling();
        } else {
          this.searchDetails = result;
          this.currentQuery = result.searchString;
          this.totalResultsInServer = result.resultsNumber || 0;

          // If status is no longer 'in process', stop polling
          if (result.statusSelect !== 1) {
            this.stopPolling();
          }
        }
      } catch (error) {
        console.error("Error during polling for company search details:", error);
        this.stopPolling();
      } finally {
        this.isLoading = false; // Always set isLoading to false after this polling request returns
      }
    }, 5000); // Poll every 5 seconds
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.loadSearchDetails(page);
    }
  }

  onSortChange(sortBy: string) {
    this.currentSortOrder = sortBy;
    this.loadSearchDetails(1, sortBy); // Reload details from page 1 with new sort order
    this.closeAllDropdowns();
  }

  goBack() {
    this.router.navigate(['/my-search-history-companies']);
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  }

  toggleDropdown(dropdownName: string) {
    if (dropdownName === 'sort') {
      this.showSortDropdown = !this.showSortDropdown;
    }
  }

  closeAllDropdowns() {
    this.showSortDropdown = false;
  }

  get totalPages(): number {
    return Math.ceil(this.totalResultsInServer / this.itemsPerPage);
  }

  getStartIndex(): number {
    return this.searchDetails && this.searchDetails.results.length > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.totalResultsInServer);
  }

  getFormattedTotal(): string {
    return this.totalResultsInServer.toLocaleString();
  }

  getStatusClass(status: number | undefined): string {
    switch (status) {
      case 1:
        return 'status-orange';
      case 2:
        return 'status-green';
      case 3:
        return 'status-red';
      default:
        return '';
    }
  }

  getStatusText(status: number | undefined): string {
    switch (status) {
      case 1:
        return 'In process';
      case 2:
        return 'Completed';
      case 3:
        return 'No results';
      default:
        return 'Unknown';
    }
  }

  getFormattedOpeningHours(hoursJson: string): string {
    try {
      const parsed = JSON.parse(hoursJson);
      return parsed.map((entry: any) => `${entry.day.slice(0, 3)}: ${entry.hours}`).join(' | ');
    } catch (e) {
      return 'Invalid format';
    }
  }

  get showSelectionBar(): boolean {
    return this.selectedCompanies.length > 0;
  }

  toggleSelectAll() {
    this.selectAllChecked = !this.selectAllChecked;
    if (this.searchDetails && this.searchDetails.results) {
      if (this.selectAllChecked) {
        this.selectedCompanies = this.searchDetails.results.map(company => company.id);
      } else {
        this.selectedCompanies = [];
      }
    }
  }

  toggleCompanySelection(companyId: number) {
    const index = this.selectedCompanies.indexOf(companyId);
    if (index > -1) {
      this.selectedCompanies.splice(index, 1);
    } else {
      this.selectedCompanies.push(companyId);
    }
    if (this.searchDetails && this.searchDetails.results) {
      this.selectAllChecked = this.selectedCompanies.length === this.searchDetails.results.length;
    }
  }

  async addToMyList() {
    const creditsNeeded = this.selectedCompanies.length; // 1 crédito por empresa

    if (creditsNeeded === 0) {
      this.notificationService.showError("No hay empresas seleccionadas");
      return;
    }

    if (this.creditsRemaining < creditsNeeded) {
      this.notificationService.showError(`No tienes créditos suficientes. Necesitas ${creditsNeeded} y tienes ${this.creditsRemaining}.`);
      return;
    }

    this.isSaving = true;

    try {
      const result = await this.myListCompanyService.saveCompanyResults(this.selectedCompanies);

      if (result.error) {
        this.notificationService.showError(result.message || "Ocurrió un error al guardar.");
      } else {
        this.notificationService.showSuccess(`${result.saved} empresas añadidas a tu lista.`);
        
        if (result.creditsRemaining !== undefined) {
          this.authService.updateCurrentUserCredits(result.creditsRemaining);
        }

        this.selectedCompanies = [];
        this.selectAllChecked = false;
        this.onboardingService.completeOnboardingStepByKey('SAVE_LEAD'); // NEW: Complete step on successful save
      }
    } catch (error) {
      console.error("Error adding companies to list:", error);
      this.notificationService.showError("Ocurrió un error de conexión al intentar guardar.");
    } finally {
      this.isSaving = false;
    }
  }

  closeSelectionBar() {
    this.selectedCompanies = [];
    this.selectAllChecked = false;
  }
}