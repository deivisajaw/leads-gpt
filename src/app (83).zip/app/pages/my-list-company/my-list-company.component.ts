import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { MyListCompanyService, SavedCompany } from '../../services/my-list-company.service';
import { ExportService } from '../../services/export.service';

@Component({
  selector: 'app-my-list-company',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, TranslateModule],
  templateUrl: './my-list-company.component.html',
  styleUrl: './my-list-company.component.css'
})
export class MyListCompanyComponent implements OnInit {
  companies: SavedCompany[] = [];
  filteredCompanies: SavedCompany[] = [];
  searchQuery = '';
  isLoading = false;
  currentView: 'grid' | 'card' = 'grid';
  currentViewText = 'Grid view';
  currentPage = 1;
  itemsPerPage = 25;

  showViewDropdown = false;
  showExportDropdown = false;

  constructor(
    private myListCompanyService: MyListCompanyService,
    private router: Router,
    private exportService: ExportService 
  ) {
    document.addEventListener('click', (event) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.dropdown-wrapper')) {
        this.closeAllDropdowns();
      }
    });
  }

  ngOnInit() {
    this.loadCompanies();
  }

  async loadCompanies() {
    this.isLoading = true;
    try {
      const result = await this.myListCompanyService.getMyCompanies();
      if (result.error) {
        console.error('Error loading companies:', result.message);
      } else {
        this.companies = result.companies;
        this.filteredCompanies = [...this.companies];
      }
    } catch (error) {
      console.error('Error loading companies:', error);
    } finally {
      this.isLoading = false;
    }
  }

  onSearch() {
    if (!this.searchQuery.trim()) {
      this.filteredCompanies = [...this.companies];
    } else {
      const query = this.searchQuery.toLowerCase();
      this.filteredCompanies = this.companies.filter(company =>
        company.title.toLowerCase().includes(query) ||
        company.categoryName.toLowerCase().includes(query) ||
        company.city.toLowerCase().includes(query) ||
        company.state.toLowerCase().includes(query)
      );
    }
    this.currentPage = 1;
  }

  changeView(view: 'grid' | 'card') {
    this.currentView = view;
    this.currentViewText = view === 'grid' ? 'Grid view' : 'Card view';
  }

  viewCompanyDetails(companyId: number) {
    this.router.navigate(['/company-details', companyId]);
  }

  refreshList() {
    this.loadCompanies();
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  }

  toggleDropdown(dropdownName: string) {
    this.showViewDropdown = false;
    this.showExportDropdown = false;

    switch (dropdownName) {
      case 'view':
        this.showViewDropdown = true;
        break;
      case 'export':
        this.showExportDropdown = true;
        break;
    }
  }

  closeAllDropdowns() {
    this.showViewDropdown = false;
    this.showExportDropdown = false;
  }

  get paginatedCompanies(): SavedCompany[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredCompanies.slice(start, end);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredCompanies.length / this.itemsPerPage);
  }

  getStartIndex(): number {
    return this.filteredCompanies.length > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.filteredCompanies.length);
  }

  exportToCSV(): void {
   
    const dataToExport = this.filteredCompanies.map(({ additionalInfo, address, categoryName, city, countryCode, description, descriptionMd, error, errorDescription, id, neighborhood, openingHours, permanentlyClosed, phoneUnformatted, postalCode, savedOn, state, street, title, website }
      ) => ({
          id,
          title,
          categoryName,
          countryCode,
          city,
          state,
          street,
          address,
          postalCode,
          phoneUnformatted,
          openingHours,
          permanentlyClosed,
          website,
          description,
          descriptionMd,
          error,
          errorDescription,
          neighborhood,
          additionalInfo,
          savedOn: this.formatDate(savedOn)
    }));
    this.exportService.exportToCsv(dataToExport, 'my-company-list');
  }
  
  exportToExcel(): void {
    const dataToExport = this.filteredCompanies.map(({ additionalInfo, address, categoryName, city, countryCode, description, descriptionMd, error, errorDescription, id, neighborhood, openingHours, permanentlyClosed, phoneUnformatted, postalCode, savedOn, state, street, title, website }
      ) => ({
          id,
          title,
          categoryName,
          countryCode,
          city,
          state,
          street,
          address,
          postalCode,
          phoneUnformatted,
          openingHours,
          permanentlyClosed,
          website,
          description,
          descriptionMd,
          error,
          errorDescription,
          neighborhood,
          additionalInfo,
          savedOn: this.formatDate(savedOn) 
    }));
    this.exportService.exportToExcel(dataToExport, 'my-company-list');
  }
}