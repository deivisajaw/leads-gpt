import {
  Component, Input, Output, EventEmitter,
  OnInit, ViewChild, ElementRef, AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface ChatMessage {
  role: 'assistant' | 'user';
  text: string;
}

export interface QuickPrompt {
  label: string;
  query: string;
}

export type SearchChatMode = 'people' | 'companies';

@Component({
  selector: 'app-search-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-chat.component.html',
  styleUrl: './search-chat.component.css',
})
export class SearchChatComponent implements OnInit, AfterViewChecked {
  @Input() mode: SearchChatMode = 'people';
  @Output() searchReady = new EventEmitter<string>();
  // Se emite una sola vez, justo cuando el usuario envía su primer mensaje — el componente
  // padre lo usa para ocultar el resto del contenido (globo, stats, sugeridos) y dejar la
  // pantalla en blanco con solo el header arriba, como pide el diseño.
  @Output() chatStarted = new EventEmitter<void>();

  @ViewChild('messagesEnd') messagesEnd!: ElementRef;

  messages: ChatMessage[] = [];
  userInput = '';
  isLoading = false;
  hasStarted = false;

  private shouldScroll = false;

  greeting = '';
  title = '¿A quién quieres encontrar hoy?';
  subtitle = 'Encuentra al tomador de decisión correcto en cualquier empresa de Latinoamérica — cada búsqueda llena tu mapa de leads.';
  inputPlaceholder = 'Busca por nombre, cargo o empresa…';
  // IMPORTANTE: quickPrompts se calcula UNA sola vez (ngOnInit) y se guarda como propiedad
  // estable, no como getter. Un getter usado en *ngFor crea un array (y objetos) nuevos en
  // cada ciclo de change detection —Angular no puede saber que son "los mismos" chips porque
  // cambian de identidad todo el tiempo, así que destruye y vuelve a crear ese DOM en cada
  // ciclo. Como Angular dispara change detection en cada evento (incluido mousemove), eso
  // termina congelando la pestaña con solo mover el mouse. Con una propiedad fija esto no pasa.
  quickPrompts: QuickPrompt[] = [];

  ngOnInit(): void {
    this.title = this.mode === 'companies'
      ? '¿Qué empresa quieres encontrar hoy?'
      : '¿A quién quieres encontrar hoy?';
    this.greeting = this.computeGreeting();
    this.quickPrompts = this.buildQuickPrompts();
    this.startConversation();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll) {
      this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
      this.shouldScroll = false;
    }
  }

  private computeGreeting(): string {
    const hour = new Date().getHours();
    const label = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches';
    return `${label} 👋`;
  }

  private buildQuickPrompts(): QuickPrompt[] {
    return this.mode === 'people'
      ? [
        { label: 'CEOs · Bogotá', query: 'CEOs y dueños de empresas en Bogotá' },
        { label: 'Gerentes de ventas', query: 'Gerentes de ventas en Colombia' },
        { label: 'Fundadores · Medellín', query: 'Fundadores de empresas en Medellín' },
        { label: 'Directores de marketing', query: 'Directores de marketing en Colombia con anuncios activos' },
      ]
      : [
        { label: 'Startups · fintech MX', query: 'Startups fintech en México' },
        { label: 'SaaS B2B · Colombia', query: 'Empresas SaaS B2B en Colombia con más de 50 empleados' },
        { label: 'Logística en crecimiento', query: 'Compañías logísticas en crecimiento en Latinoamérica' },
        { label: 'Salud · Medellín', query: 'Clínicas y centros de salud en Medellín' },
      ];
  }

  // Mensaje de bienvenida fijo y local — ya no se llama a ningún webhook/agente para esto.
  private startConversation(): void {
    const greeting = this.mode === 'companies'
      ? 'Cuéntame qué tipo de empresa buscas y lo busco tal cual lo escribas.'
      : 'Cuéntame a quién buscas y lo busco tal cual lo escribas.';

    this.messages = [{ role: 'assistant', text: greeting }];
  }

  // Ya no hay agente de por medio: lo que el usuario escribe ES la búsqueda, tal cual —
  // sin interpretación, sin ida y vuelta de conversación.
  async send(prefill?: string): Promise<void> {
    const text = (prefill ?? this.userInput).trim();
    if (!text || this.isLoading) return;

    if (!this.hasStarted) {
      this.chatStarted.emit();
    }
    this.hasStarted = true;
    this.userInput = '';

    this.pushMsg('user', text);

    this.isLoading = true;
    // Pequeña pausa solo para que la transición del chat se sienta natural (el mensaje del
    // usuario alcanza a pintarse) antes de disparar la búsqueda real.
    await new Promise(resolve => setTimeout(resolve, 300));
    this.isLoading = false;

    this.pushMsg('assistant', 'Perfecto, buscando eso ahora mismo.');

    setTimeout(() => this.searchReady.emit(text), 500);
  }

  usePrompt(prompt: QuickPrompt): void {
    this.send(prompt.query);
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.send();
    }
  }

  trackByIndex(index: number): number {
    return index;
  }

  private pushMsg(role: 'assistant' | 'user', text: string): void {
    this.messages.push({ role, text });
    this.shouldScroll = true;
  }
}