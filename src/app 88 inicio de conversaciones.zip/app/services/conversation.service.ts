import { Injectable, inject } from '@angular/core';
import { ApiConfigService } from './api-config.service';

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACES — Agentes locales
// ─────────────────────────────────────────────────────────────────────────────

export interface ChatwootAgent {
  id: number;
  name: string;
  agentType: string;
  agentDirection: string;
  companyData: number;
  language: string;
  agentSystemName: string;
  statusSelect: string;
  processed: boolean;
  whatsappNumber: string;
  chatwootApiKey: string;
  chatwootAccountId?: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACES — Chatwoot
// ─────────────────────────────────────────────────────────────────────────────

export interface ChatwootContact {
  id: number;
  name: string;
  email: string | null;
  phone_number: string | null;
  avatar_url: string;
  additional_attributes: Record<string, any>;
}

export interface ChatwootMessage {
  id: number;
  content: string;
  message_type: number; // 0=incoming, 1=outgoing, 2=activity
  created_at: number;
  sender: { name: string; avatar_url: string } | null;
  conversation_id?: number;
}

export interface ChatwootConversation {
  id: number;
  inbox_id: number;
  status: 'open' | 'resolved' | 'pending' | 'snoozed';
  created_at: number;
  updated_at: number;
  unread_count: number;
  contact: ChatwootContact;
  last_message: ChatwootMessage | null;
}

export interface ContactConversationGroup {
  contact: ChatwootContact;
  conversations: ChatwootConversation[];
  lastActivity: number;
  totalUnread: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACES — legacy
// ─────────────────────────────────────────────────────────────────────────────

export interface ConversationParticipant {
  name: string;
  email?: string;
  speakingPercent?: number;
  speakingMinutes?: number;
}

export interface TranscriptSegment {
  speakerName: string;
  text: string;
  timestampSeconds: number;
}

export interface NextStep {
  ownerName: string;
  items: string[];
}

export interface Conversation {
  id: string;
  title: string;
  date: string;
  durationSeconds: number;
  status: 'completed' | 'processing' | 'failed';
  participants: ConversationParticipant[];
  recordingUrl?: string;
  thumbnailUrl?: string;
  hostName?: string;
  agentName?: string;
  summary?: string;
  nextSteps?: NextStep[];
  transcript?: TranscriptSegment[];
  tags?: string[];
  meetProvider?: 'google_meet' | 'zoom' | 'other';
  meetUrl?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// SERVICE
// ─────────────────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class ConversationService {

  private apiConfig = inject(ApiConfigService);

  // ── Legacy ────────────────────────────────────────────────────────────────
  async getConversationById(id: string): Promise<Conversation | null> {
    return null;
  }

  // ── Agents ────────────────────────────────────────────────────────────────

  async getAgentsWithChatwoot(): Promise<ChatwootAgent[]> {
    const raw = await this.fetchData(
      'com.ajawmrp3.apps.prospectingai.web.ConversationController:getAgentsForConversations',
      {}
    );
    const agents: ChatwootAgent[] = (raw?.agents ?? []) as ChatwootAgent[];
    if (agents.length === 0) return [];

    const enriched = await Promise.allSettled(
      agents.map(agent => this.enrichAgentWithAccountId(agent))
    );

    return enriched
      .filter(r => r.status === 'fulfilled' && r.value !== null)
      .map(r => (r as PromiseFulfilledResult<ChatwootAgent>).value);
  }

  private async enrichAgentWithAccountId(agent: ChatwootAgent): Promise<ChatwootAgent> {
    const resp = await fetch(this.apiConfig.chatwootProfileUrl, {
      method: 'GET',
      headers: { 'api_access_token': agent.chatwootApiKey }
    });
    if (!resp.ok) throw new Error(`Profile HTTP ${resp.status}`);
    const profile = await resp.json();
    const accountId: number | undefined = profile?.accounts?.[0]?.id;
    if (!accountId) throw new Error('accountId not found in profile');
    return { ...agent, chatwootAccountId: accountId };
  }

  // ── Conversations grouped by contact ─────────────────────────────────────

  async getConversationsGroupedByContact(
    agent: ChatwootAgent,
    status: 'open' | 'resolved' | 'pending' | 'all' = 'all',
    page = 1
  ): Promise<ContactConversationGroup[]> {
    if (!agent.chatwootAccountId) return [];

    const url = `${this.apiConfig.chatwootBaseUrl}/api/v1/accounts/${agent.chatwootAccountId}/conversations`
      + `?status=${status}&page=${page}`;

    const resp = await fetch(url, {
      method: 'GET',
      headers: { 'api_access_token': agent.chatwootApiKey }
    });

    if (!resp.ok) throw new Error(`Chatwoot conversations HTTP ${resp.status}`);
    const data = await resp.json();

    // Chatwoot retorna data.data.payload para listados paginados
    const payload: any[] = data?.data?.payload ?? [];

    const conversations: ChatwootConversation[] = payload.map((c: any) => ({
      id:           c.id,
      inbox_id:     c.inbox_id,
      status:       c.status,
      created_at:   c.created_at,
      updated_at:   c.updated_at,
      unread_count: c.unread_count ?? 0,
      contact: {
        id:                    c.meta?.sender?.id ?? 0,
        name:                  c.meta?.sender?.name ?? 'Unknown',
        email:                 c.meta?.sender?.email ?? null,
        phone_number:          c.meta?.sender?.phone_number ?? null,
        avatar_url:            c.meta?.sender?.avatar ?? '',
        additional_attributes: c.meta?.sender?.additional_attributes ?? {}
      },
      last_message: c.last_non_activity_message
        ? {
            id:           c.last_non_activity_message.id,
            content:      c.last_non_activity_message.content ?? '',
            message_type: c.last_non_activity_message.message_type,
            created_at:   c.last_non_activity_message.created_at,
            sender:       c.last_non_activity_message.sender
              ? { name: c.last_non_activity_message.sender.name, avatar_url: c.last_non_activity_message.sender.avatar_url ?? '' }
              : null
          }
        : null
    }));

    return this.groupByContact(conversations);
  }

  // ── Messages for a contact (todas sus conversaciones concatenadas) ────────

  async getMessagesForContact(
    agent: ChatwootAgent,
    group: ContactConversationGroup
  ): Promise<ChatwootMessage[]> {
    if (!agent.chatwootAccountId) return [];

    // Fetch messages for each conversation in parallel
    const results = await Promise.allSettled(
      group.conversations.map(conv =>
        this.fetchConversationMessages(agent, conv.id)
      )
    );

    // Flatten all messages, tag with conversation_id, sort by created_at asc
    const allMessages: ChatwootMessage[] = [];
    results.forEach((r, i) => {
      if (r.status === 'fulfilled') {
        const tagged = r.value.map(m => ({ ...m, conversation_id: group.conversations[i].id }));
        allMessages.push(...tagged);
      }
    });

    return allMessages.sort((a, b) => a.created_at - b.created_at);
  }

  private async fetchConversationMessages(
    agent: ChatwootAgent,
    conversationId: number
  ): Promise<ChatwootMessage[]> {
    const url = `${this.apiConfig.chatwootBaseUrl}/api/v1/accounts/${agent.chatwootAccountId}/conversations/${conversationId}/messages`;
    const resp = await fetch(url, {
      method: 'GET',
      headers: { 'api_access_token': agent.chatwootApiKey }
    });
    if (!resp.ok) throw new Error(`Messages HTTP ${resp.status}`);
    const data = await resp.json();
    return (data?.payload ?? []).map((m: any) => ({
      id:           m.id,
      content:      m.content ?? '',
      message_type: m.message_type,
      created_at:   m.created_at,
      sender: m.sender ? { name: m.sender.name, avatar_url: m.sender.avatar_url ?? '' } : null
    }));
  }

  private groupByContact(conversations: ChatwootConversation[]): ContactConversationGroup[] {
    const map = new Map<number, ContactConversationGroup>();

    for (const conv of conversations) {
      const cid = conv.contact.id;
      if (!map.has(cid)) {
        map.set(cid, { contact: conv.contact, conversations: [], lastActivity: 0, totalUnread: 0 });
      }
      const group = map.get(cid)!;
      group.conversations.push(conv);
      if (conv.updated_at > group.lastActivity) group.lastActivity = conv.updated_at;
      group.totalUnread += conv.unread_count;
    }

    return Array.from(map.values())
      .sort((a, b) => b.lastActivity - a.lastActivity);
  }

  // ── Formatters ────────────────────────────────────────────────────────────

  formatDate(iso: string): string {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    });
  }

  formatUnix(unixTs: number): string {
    return this.formatDate(new Date(unixTs * 1000).toISOString());
  }

  formatUnixShort(unixTs: number): string {
    const d = new Date(unixTs * 1000);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - d.getTime()) / 86400000);
    if (diffDays === 0) return d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true });
    if (diffDays === 1) return 'Ayer';
    if (diffDays < 7)  return d.toLocaleDateString('es-CO', { weekday: 'short' });
    return d.toLocaleDateString('es-CO', { day: '2-digit', month: 'short' });
  }

  formatDuration(seconds: number): string {
    if (!seconds || seconds <= 0) return '—';
    const m = Math.floor(seconds / 60);
    const h = Math.floor(m / 60);
    return h > 0 ? `${h}h ${m % 60}m` : `${m}m`;
  }

  formatTimestamp(seconds: number): string {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  getInitials(name: string): string {
    return name.split(' ').slice(0, 2).map(n => n[0] ?? '').join('').toUpperCase();
  }

  avatarColor(name: string): string {
    const palette = ['#5b4fe5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return palette[Math.abs(hash) % palette.length];
  }

  statusLabel(status: string): string {
    const map: Record<string, string> = {
      open: 'Abierta', resolved: 'Resuelta', pending: 'Pendiente', snoozed: 'Pospuesta'
    };
    return map[status] ?? status;
  }

  statusClass(status: string): string {
    const map: Record<string, string> = {
      open: 'status-open', resolved: 'status-resolved',
      pending: 'status-pending', snoozed: 'status-snoozed'
    };
    return map[status] ?? '';
  }

  private async fetchData(action: string, data: any): Promise<any> {
    const token = localStorage.getItem('csrfToken');
    if (!token) throw new Error('No authentication token found');
    const response = await fetch(`${this.apiConfig.baseUrl}/ws/action`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
      body: JSON.stringify({ action, data }),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const result = await response.json();
    if (result.error) throw new Error(result.error.message || 'Unknown error');
    return result.data;
  }
}
